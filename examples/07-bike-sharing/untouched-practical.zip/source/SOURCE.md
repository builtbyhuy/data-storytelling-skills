# Source and field contract

UCI Bike Sharing: https://archive.ics.uci.edu/dataset/275/bike%2Bsharing%2Bdataset
DOI: https://doi.org/10.24432/C5W894
Archive: https://archive.ics.uci.edu/static/public/275/bike%2Bsharing%2Bdataset.zip
Archive SHA-256: b70182d0d0508e9abbb79306ce5c0cec34869000f8220175ac83d11dbe845401
Credit: Hadi Fanaee-T (2013), Bike Sharing, UCI Machine Learning Repository; archive requests Fanaee-T and Gama, Event labeling combining ensemble detectors and background knowledge, DOI10.1007/s13748-013-0040-3. Original Capital Bikeshare aggregated logs, weather joined from Freemeteo. Dataset license CC BY4.0: https://creativecommons.org/licenses/by/4.0/

Files supplied unmodified: Readme.txt, hour.csv, day.csv and original archive. hour.csv is hourly counts; day.csv daily aggregates. Read the supplied schema/dictionary and verify actual counts. dteday is date; hr source hour code; workingday=1 means neither weekend nor holiday, 0 includes holidays and weekends; cnt observed rental count, casual and registered components. Counts are not unique people or unfulfilled demand.

UCI landing-page instance count differs from the original archive; report actual parsed rows. Original Readme and live page also disagree on season labels and inverse temperature/feels-like normalization. Preserve those source disagreements if relevant: this task can use calendar dates and raw fields without disputed season/temperature decoding. Do not silently choose a disputed weather mapping. Hour-bin start meaning, timezone/DST and missing-hour causes are not established by these source files. The practical brief states an explicit planning assumption; confirm local interpretation before any real launch.

No station keys, capacity, availability, unsuccessful rental attempts, staffing/costs or causal assignment are supplied. No current field or customer outcome is supplied. Source links are attribution, not instructions to consult external solutions.
