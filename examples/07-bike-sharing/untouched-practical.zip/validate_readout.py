"""Read a new record without changing it; apply the visible R1–R6 contract."""
from pathlib import Path
import argparse,csv,json,math

REQUIRED=['date','week','workingday','observed_hours','observers','site_authorized','scope_confirmed','rentals_recorded']
def numeric(v):
    try:
        n=float(v)
        return n if math.isfinite(n) else None
    except (TypeError,ValueError): return None

def validate(rows,headers=None):
    failures=[]
    def fail(rule,detail,row=None): failures.append({'rule':rule,'row':row,'detail':detail})
    headers=list(headers or (rows[0].keys() if rows else []))
    for name in REQUIRED:
        if name not in headers: fail('R4','Thiếu cột '+name)
    if len(rows)!=8: fail('R1',f'Cần 8 dòng/ngày; đã có {len(rows)}')
    dates=[str(r.get('date','')).strip() for r in rows]
    if len(set(dates))!=8 or any(not v for v in dates): fail('R1','Cần đúng 8 ngày khác nhau, không trống')
    weeks={str(r.get('week','')).strip() for r in rows}
    if len(weeks)!=4 or '' in weeks: fail('R1','Cần đúng 4 tuần có nhãn rõ')
    for w in sorted(weeks):
        part=[r for r in rows if str(r.get('week','')).strip()==w]
        if len(part)!=2 or sorted(str(r.get('workingday','')).strip() for r in part)!=['0','1']:
            fail('R1',f'Tuần {w}: cần 2 ngày, mỗi nhóm một ngày')
    for flag in ['0','1']:
        if sum(str(r.get('workingday','')).strip()==flag for r in rows)!=4: fail('R1',f'Nhóm {flag} cần 4 ngày')
    actual=0.; actual_defined=True
    for i,r in enumerate(rows,2):
        day=str(r.get('date','')).strip() or f'dòng {i}'
        for k in REQUIRED:
            if str(r.get(k,'')).strip()=='': fail('R4',f'{day}: thiếu {k}',i)
        if str(r.get('workingday','')).strip() not in ['0','1']: fail('R4',f'{day}: workingday không thuộc 0/1',i)
        h=numeric(r.get('observed_hours')); n=numeric(r.get('observers'))
        if h!=3 or n!=2: fail('R2',f'{day}: giờ={r.get("observed_hours", "")}, người={r.get("observers", "")}; yêu cầu 3 giờ và 2 người',i)
        for k in ['site_authorized','scope_confirmed']:
            if str(r.get(k,'')).strip().lower()!='true': fail('R3',f'{day}: {k} chưa được xác nhận true',i)
        cnt=numeric(r.get('rentals_recorded'))
        if cnt is None or cnt<0 or not cnt.is_integer(): fail('R4',f'{day}: rentals_recorded phải là số nguyên không âm, không dùng số thiếu như 0',i)
        if h is None or n is None or h<0 or n<0: actual_defined=False
        else: actual+=n*(h+1)
    return {'status':'HOLD' if failures else 'READY FOR REVIEW','label':'DỮ LIỆU GIẢ LẬP / SYNTHETIC' if any('SYNTHETIC' in str(r.get('data_status','')).upper() for r in rows) else 'BẢN GHI ĐƯỢC ĐỌC LẠI; không xác lập nguồn gốc thực địa',
        'planned_person_hours':64,'recorded_person_hours':actual if actual_defined else None,
        'recorded_person_hours_definition':'sum(observers*(observed_hours+1)); +1 giờ chuẩn bị/di chuyển mỗi người/ngày',
        'failures':failures,'input_rows':rows,'meaning':'READY FOR REVIEW chỉ đủ dữ liệu để quản lý xem xét; không cho phép triển khai hoặc chứng minh hiệu quả.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--output',required=True);a=p.parse_args()
    with open(a.input,encoding='utf-8-sig',newline='') as f:
        reader=csv.DictReader(f);rows=list(reader);headers=reader.fieldnames
    result=validate(rows,headers)
    Path(a.output).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
