# Gói lập kế hoạch quan sát lịch sử

Mở `report.html` bằng Chrome hoặc trình duyệt hỗ trợ SVG. Không cần mạng, tài khoản hay phông từ xa. Khi đọc trên điện thoại, biểu đồ và bảng số có vùng cuộn ngang; nội dung văn bản tự xuống dòng. Hai SVG độc lập giữ chữ dưới dạng `<text>` để chỉnh sửa.

## Dữ liệu và kết quả

- `source/hour.csv`, `source/day.csv`: bản sao nguyên trạng từ bộ nguồn được cấp.
- `source/Readme.txt`, `source/SOURCE.md`: từ điển, hợp đồng nguồn và ghi công/giấy phép.
- `facts.csv`: 6 dòng kết quả, theo năm/nhóm/khối. Tử số và mẫu số là số lượt thuê, tỷ lệ là phần trăm; `delta_vs_fixed_pp` là điểm phần trăm năm 2012, chỉ có nghĩa trên dòng selected. Trống ở dòng không áp dụng không phải là 0.
- `candidate-blocks-2011.csv`: cả 14 khối cho mỗi nhóm, chỉ dùng năm 2011.
- `eligibility-by-date.csv`: từng ngày, số dòng trong cửa sổ và cả ngày, lý do loại.
- `analysis.json`: kiểm tra nguồn, hàm băm SHA-256 và số liệu chưa làm tròn.
- `schedule.csv`: 8 vị trí lịch chưa có ngày/địa điểm thật. Nhóm 0: 12–15; nhóm 1: 17–20; giờ là giả định ô bắt đầu. Tất cả còn HOLD.
- `readout.csv`: mẫu trống 8 dòng; các trường thực ghi vẫn trống, không điền sẵn giờ/người kế hoạch vào dữ liệu đã quan sát.
- `readout-example.csv`: bản minh họa có nhãn DỮ LIỆU GIẢ LẬP / SYNTHETIC. Các ngày SYN-W… là mã giả lập phân biệt được, không phải lịch thật. Kết quả kiểm tra ở `readout-example-result.json`: HOLD theo R3, 64 giờ công kế hoạch và 64 giờ công theo mẫu. Lượt thuê minh họa không phải kết quả thực địa.

CSV là UTF-8 có BOM và hàng tiêu đề, đọc được bằng Excel hoặc pandas. Báo cáo dùng chấm cho hàng nghìn, phẩy cho số thập phân; CSV dùng dấu chấm thập phân để máy đọc. Tỷ lệ và chênh lệch trong HTML/SVG làm tròn 1 chữ số sau dấu phẩy từ các tổng chưa làm tròn.

## Dựng lại chính xác trên môi trường Windows đã có

Không cài gói mới. Python được chọn bằng bộ chạy có sẵn. pandas 3.0.1 đã có; bộ dựng HTML/SVG không cần Matplotlib.

Thư mục chạy:

```powershell
Set-Location -LiteralPath 'C:/Users/user/Documents/Codex/Du-an/Data-Storytelling/evidence/forward-v3.4-20261015/runs/L26/first-handoff/practical'
```

Dựng vào thư mục mới để không ghi đè bản báo cáo hay bản ghi đã điền:

```powershell
& 'C:/Users/user/.codex/workbenches/codex-local/Invoke-CodexPython.ps1' -B .\build.py --out .\rebuilt
```

Hoặc chạy `./Rebuild.ps1` từ thư mục gói; mặc định cũng ghi vào `rebuilt`. Đầu vào luôn là thư mục `source` cạnh `build.py`. Tệp kết quả: HTML, 2 SVG, 6 CSV, 2 JSON cùng các bản nguồn và công cụ dựng lại. Khi chuyển cả gói sang đường dẫn khác, chạy `Rebuild.ps1` ngay trong gói mới; đường dẫn dữ liệu được lấy tương đối, không phải sửa mã. Bộ chạy Python hiện tại là phụ thuộc môi trường Windows được ghi rõ ở trên.

Mở `rebuilt/report.html` để xem kết quả. Không dùng lệnh dựng lại để nhập dữ liệu hiện trường: bộ dựng lại tạo mẫu trống, không hợp nhất bản ghi.

## Đọc lại bản ghi mới, giữ nguyên dữ liệu gốc

Sao chép mẫu thành một tên mới, giữ các trường bắt buộc: `date`, `week`, `workingday`, `observed_hours`, `observers`, `site_authorized`, `scope_confirmed`, `rentals_recorded`. Cột `week` là nhãn tuần đã cung cấp; không suy lại nhóm/tuần từ ngày giả lập. Cột `data_status` giữ nhãn SYNTHETIC khi dùng giả lập. Có thể thêm ghi chú, slot và bằng chứng.

Nhập nguyên giá trị nhận được; không sửa 2 giờ thành 3, không thay lượt thuê thiếu bằng 0. Trên HTML, chọn CSV ở phần Ghi nhận & đọc lại rồi nhấn Kiểm tra R1–R6. Kết quả chỉ được tạo trong bộ nhớ; nút lưu tải một JSON riêng. Công cụ không gửi đi hoặc sửa tệp gốc.

Cách chạy độc lập có thể lặp lại, ví dụ với mẫu giả lập đã bàn giao:

```powershell
& 'C:/Users/user/.codex/workbenches/codex-local/Invoke-CodexPython.ps1' -B .\validate_readout.py .\readout-example.csv --output .\readout-example-recheck.json
```

R1: đúng 8 ngày khác nhau/4 tuần, mỗi tuần 2 ngày và một ngày/nhóm. R2: đúng 3 giờ, 2 người/dòng. R3: hai xác nhận phải true. R4: đủ trường và lượt thuê nguyên không âm. R5: kế hoạch 64 giờ công; thực ghi là tổng observers × (observed_hours + 1), không đọc được giờ/người thì tổng chưa xác định. R6: chỉ toàn bộ đạt mới READY FOR REVIEW, còn lại HOLD kèm quy tắc và ngày/dòng. Kết quả READY FOR REVIEW không phải cho phép triển khai hoặc chứng minh hiệu quả.

## Nguồn và giới hạn

Hadi Fanaee-T (2013), Bike Sharing, UCI Machine Learning Repository, DOI 10.24432/C5W894. Giấy phép CC BY 4.0. Ghi công Fanaee-T & Gama, Event labeling combining ensemble detectors and background knowledge, DOI 10.1007/s13748-013-0040-3. Nguồn gốc Capital Bikeshare, Washington D.C., 2011–2012; thời tiết ghép từ Freemeteo. Chi tiết và liên kết trong `source/SOURCE.md` và HTML.

Dữ liệu không có trạm, xe sẵn có, nhu cầu thất bại, công suất, nhân sự/chi phí hay phép gán can thiệp. Không phải tình hình hiện tại, dự báo hoặc tác động kinh doanh. Múi giờ/DST và ý nghĩa bắt đầu ô giờ chưa được nguồn xác nhận. Nhân sự, địa điểm và quyền thực hiện chưa được xác nhận. Tất cả phải được quản lý ghi nhận trước khi bắt đầu.
