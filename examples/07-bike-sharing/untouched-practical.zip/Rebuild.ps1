param([string]$OutputDirectory = (Join-Path $PSScriptRoot 'rebuilt'))
$ErrorActionPreference = 'Stop'
& 'C:/Users/user/.codex/workbenches/codex-local/Invoke-CodexPython.ps1' -B (Join-Path $PSScriptRoot 'build.py') --out $OutputDirectory
if ($LASTEXITCODE -ne 0) { throw 'Rebuild failed.' }
