# Independent method and release-package audit — 3.5

Audit scope: current `skill-suite` versus published commit `8b1da0a`, frozen `methods/candidate-3.5`, optional complements, all five complete practical archives, candidate example 08 and public README/forward claims. Started 2026-10-15 05:31:58 UTC. This is a read-only review apart from these audit files. No authored program was executed; only the specifically authorized package validator and independent read/hash/static-parse checks ran. Reader and visual answers were not inspected.

## Assessment

The method revision is substantive and general. Package integrity passes. One additional distribution-notice gap was found, corrected by the owner and independently rechecked; no open method/package finding remains in this scope. Final performance/release conclusions remain outside this audit until the separately owned result integration and release steps finish.

## Method checks

- All six current entrypoints were read and compared with `8b1da0a` using a diff that ignores end-of-line differences. Three entrypoints have substantive body changes (`data-storytelling`, `business-chart-communication`, `evidence-to-narrative`); the other three change version metadata and receive the applicable synchronized shared-reference changes. This is not six independently rewritten workflows.
- `shared/visual-delivery.md:15-37` adds content-specific direction, a difficult representative real-content view, actual complementary method loading for substantial HTML, one primary comparison, narrow-screen value identity/captions/rules, unaided retrieval and a recipient task, requested counts/rates, and explicit protection against optimizing a parser instead of the reader.
- `shared/evidence-contract.md:11` adds source-defined eligible populations, unmatched keys, multiplicity and reconciled totals, while preserving absent values as missing. This applies to ordinary joins, not the Wine schema.
- No Wine dataset name, condition alias, decisive Wine count or dataset-specific recipe appears in the revised entrypoints/shared methods checked. The rules use category counts, dates, long identities, joins and operational tasks; they do not hardcode the Wine result, threshold or worklist.
- Actual composition is explicit in `skills/data-storytelling/SKILL.md` (Reuse the installed stack) and `shared/visual-delivery.md:21`: read the actual available Frontend/art-direction instructions; art direction establishes the reading task, frontend realizes it, and evidence/quantities stay authoritative. Frozen complements contain those actual full methods, rather than a score-oriented paraphrase. The sealed author working notes also identify their use; this is supporting author documentation, not proof of every internal reasoning step.
- The standalone fallback is a real internal direction/render/task procedure, with other complements optional. README and optional-complement notes correctly say the fallback was not separately measured in this Wine comparison. Installer source still selects only the six core names and requires deliberate replacement/backup for existing matches.

## Exact-file and portability checks

Independent SHA-256 and ZIP-member checks are recorded in `CHECKS.json`.

| Check | Result |
|---|---|
| Candidate frozen snapshot | Exactly 76 files; all hashes match CANDIDATE-FROZEN.json |
| Current core versus frozen at first check | All 66 match exactly |
| Shared evidence / visual copies | Six copies each; all match canonical bytes |
| N17 complete practical ZIP | 17/17 members, all manifest and original-seal hashes match |
| N42 complete practical ZIP | 51/51 members, all manifest and original-seal hashes match |
| N68 complete practical ZIP | 47/47 members, all manifest and original-seal hashes match |
| N91 complete practical ZIP | 16/16 members, all manifest and original-seal hashes match |
| N35 complete practical ZIP | 39/39 members, all manifest and original-seal hashes match |
| All five ZIP file sets | Exactly every sealed `practical/` file; no missing, extra, duplicate or unsafe entries |
| Candidate example | All 16 originals match N91 seal; only disclosed PACKAGE/PUBLICATION wrappers and two previews are additional |
| Candidate preview hashes | Both match their publication receipt |
| Exact optional complement snapshot | Ten members; archive/member hashes match publication and frozen manifest |
| Static local HTML references | No unresolved file reference in any of the five practical packages |
| Build source imports | Every detected build.py import belongs to Python's standard library; no author code run |
| Personal Windows paths | Only N35's two disclosed optional QA scripts in the practical ZIPs; other four have none |
| Package validator | `Package structural checks passed (6 skills).` |

The wrapper correctly explains two retained local-environment references in Frontend's original instructions, the K-Dense optional QA paths, and the difference between source rebuild and optional browser inspection. These original environment references are preserved receipts, not portable mandatory setup commands. Static imports/references do not prove runtime success; relocated execution is independently owned and is not repeated here.

## Finding R1 — P2, packaging: standalone complement download lacks project MIT notice

Observed: `optional-complements/README.md:7` and PUBLICATION.json designate original artifact-art-direction work as project MIT. The exact ten-file archive contains seven artifact method files and the Frontend Apache license, but no project MIT copyright/permission notice. Root `LICENSE:3-14` supplies the project copyright and full grant and asks that notice accompany copies. The root repository provides it, but extracting only the downloadable optional snapshot does not carry it with that folder.

Practical fix: retain the tested ten-file ZIP and all frozen hashes, and make a recommended outer distribution ZIP with the project LICENSE, a short packaging README and the unchanged inner snapshot. Distinguish wrapper files from the ten measured method files in its receipt. This is a self-contained distribution-notice issue, not an analytic/design method defect or a recommendation to alter original outputs. Owner applied this fix during review. Independently verified at 2026-10-15 05:36:41 UTC: the outer archive contains exactly LICENSE, README.md and the original snapshot; all three member hashes and the outer hash match the publication receipt. LICENSE is identical to root LICENSE. The enclosed snapshot is byte-identical to the original, SHA-256 `30c27caace71816d6b1673dbce14781a975e5daf61e7df022455d22005a53d80`. Finding R1 is resolved.

## Public claims and acknowledged pending work

Current README and forward record distinguish first completed recovery handoffs, interrupted original attempts, mechanical capture repair, exact output preservation, one new source, shared model/catalog confounding, model proxies, no human/business outcome, and no new official VisEval score. The 3.4 negative/official record remains explicitly separate. The known mobile table panning limitation is disclosed instead of being silently repaired. No overall winner/causal effect is asserted in the current 3.5 working results paragraph.

The root NOTICE and six copied NOTICE updates were explicitly pending when assigned and are now verified complete as packaging-only. Independently recomputed exactly six NOTICE-only changes, all matching corrected root NOTICE, with the other 60 core files still byte-identical. PACKAGING-DELTA.json matches the actual old/new hashes; TESTED-NOTICE.md restores all six tested hashes. The working reader/visual result paragraph and final installer/commit/push/release ZIP remain separately owned steps. These pending states are not undisclosed completed-release claims.

## Limits

This audit does not grade visual beauty, reader answers, practical SYN scoring or actual browser behavior; it preserves those independent reviews. It does not run any author build, install skills, make source/output edits, use CUA, publish or push. No legal determination, arbitrary-machine compatibility, new-source knowledge proof or isolated causal improvement is established. The project history registry was consulted only for scope continuity; all substantive findings above come from the current local evidence.

Audit completed 2026-10-15 05:36:41 UTC, within the original eight-minute cap.

