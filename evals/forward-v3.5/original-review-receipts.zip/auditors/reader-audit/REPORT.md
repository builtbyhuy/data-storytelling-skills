# Independent audit of the ten sealed reader deliveries

All ten reader deliveries contain actual populated record files and one logical linked SYN-C coordination action. The four asked manager questions are correct in **40/40 answers**. All **400/400 raw fixture values** survive exactly, including empty strings, `unknown` and `not done`. Actual template statuses match the frozen expectations in **37/40 decisions**. **8/10 action records** meet every frozen action check; all ten retain the requested identity, coordinator, confirmation task and missing reviewer/availability.

These are separate ledgers. No method winner, aesthetic judgment, causal method effect, human-comprehension result or real operational outcome follows from them.

The detailed evidence, per-question judgments, every raw-cell comparison, every status decision, action checks, clocks and both seal snapshots are in [RESULT.json](RESULT.json). [checker.ps1](checker.ps1) reproduces the mechanical comparisons and retains the manual manager judgments tied to the sealed bytes. It aborts on a pre-comparison hash mismatch. The reliable-delivery skill was applied to the numeric handoff; the frozen trial rubric supplied the actual obligations.

## Scope and access

The audit began at **2026-10-15 05:30:27 UTC**, with a 20-minute cap. Readers 01–09 were inspected first. Reader 10 was accessed only after the owner notified this auditor that its FINAL and both seals existed, sealed at **05:31:14 UTC**. No child agent was used.

Allowed source truth was [the private oracle](../private/wine-source-oracle.json), supported by [the independent source audit](../source-independent/REPORT.md). The frozen [assertions](../eval-plan/PRIVATE_ASSERTIONS.md), [protocol](../eval-plan/PROTOCOL.md), [recipient expectations](../eval-plan/PRIVATE_RECIPIENT_EXPECTED.md), manager questions, recipient task and SYN fixtures were read. Actual sealed manager/recipient answers and their populated records were graded. Supplied visible-text report captures and the relevant original handoff instructions/templates were used for evidence and ambiguity checks. No method body or identity, visual-review answer, root aggregate result, author analysis/build/source code, or peer judgment was inspected. No original answer, fixture, report or seal was edited, and no external action was taken.

Reader assignments stayed fixed: 01/02→R01, 03/04→R02, 05/06→R03, 07/08→R04, 09/10→R05. These neutral aliases remain blinded.

## Four manager questions

Only RM1–RM4 were scored. M01–M14 remain artifact obligations and were not expanded into reader requirements. Exact percentage-point difference, every bin, one predetermined contrast, unasked row identity and a nonrandom-selection recital were not mandatory. Volunteered numbers were checked rather than ignored.

Every reader correctly gives red 744/1,599 = 46.53% and white 1,640/4,898 = 33.48%, with the task-defined hypothetical threshold. Volunteered differences of 13.0 at one decimal or 13.05 at two decimals are correct. Each supplies a supported distribution caution; rejects unique-bottle, universal-superiority and chemical-causation inferences with reasons; and describes the proposed desktop check, 120 staff-minutes, conditional parallel hour and relevant confirmations. The source-correct reports support these answers. No incorrect, missing or justified-abstention answer was found, and no material omission of asked content was found.

| Alias | Readers | RM1 | RM2 | RM3 | RM4 | Correct / asked |
|---|---|---|---|---|---|---:|
| R01 | 01, 02 | correct | correct | correct | correct | 8/8 |
| R02 | 03, 04 | correct | correct | correct | correct | 8/8 |
| R03 | 05, 06 | correct | correct | correct | correct | 8/8 |
| R04 | 07, 08 | correct | correct | correct | correct | 8/8 |
| R05 | 09, 10 | correct | correct | correct | correct | 8/8 |

Each individual answer, its original cited locations, audit evidence paths, label and extraction cause are retained in RESULT.json. The cause is `faithful to source-correct report` for all 40. Static visible text supplements the cited captures; this audit did not repeat every image view or award visual scores.

## Actual recipient records

The denominator is **4 fixtures × 10 supplied columns × 10 readers = 400 values**, including `fixture_id`. Readers 01/02 store a lossless ten-field card as JSON in the original template's `original_value` cell; the other readers retain all ten raw columns directly. Nested and manual representations were accepted. Four records per reader were actually parsed and matched by fixture ID; reader claims of self-verification were not used as proof.

The 40 status summaries in recipient.json agree with the actual populated records. Another 84 comparisons check reader 06's nested JSON records and reader 08's redundant raw-card JSON; all agree. Those consistency checks are supplemental and do not inflate the 400-value or 40-decision denominators.

| Reader | Alias | Raw values exact | Actual A / B / C / D status | Frozen status matches | Full action checks | Full recipient rubric |
|---|---|---:|---|---:|---:|---|
| 01 | R01 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | pass | pass |
| 02 | R01 | 40/40 | HOLD / HOLD / HOLD / HOLD | 3/4 | pass | fail: A status |
| 03 | R02 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | pass | pass |
| 04 | R02 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | pass | pass |
| 05 | R03 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | pass | pass |
| 06 | R03 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | pass | pass |
| 07 | R04 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | pass | pass |
| 08 | R04 | 40/40 | READY FOR REVIEW / HOLD / HOLD / HOLD | 4/4 | fail: action HOLD gate absent | fail: action gate |
| 09 | R05 | 40/40 | HOLD / HOLD / HOLD / HOLD | 3/4 | pass | fail: A status |
| 10 | R05 | 40/40 | HOLD / HOLD / HOLD / HOLD | 3/4 | fail: action HOLD gate absent | fail: A status and action gate |

All B/C/D decisions stay HOLD with the required blockers: B retains empty source snapshot, unknown provenance and not-done record check; C retains an empty reviewer and unknown availability; D retains unknown scope and not-done permission. No READY FOR REVIEW is presented as approval to start, a real audit completion or a wine-quality pass.

### Three SYN-A status mismatches and their cause

The frozen expectation is READY FOR REVIEW for A. The actual delivered template states in [reader 02](../final-readers/reader-02/filled-records.csv), [reader 09](../final-readers/reader-09/filled-records.csv) and [reader 10](../final-readers/reader-10/filled-records.csv) are HOLD. These three decisions remain failures against the frozen expectation.

The reasoning has a real template basis. R01's [FORM-GUIDE](../review-input/final-content/R01/handoff/FORM-GUIDE.md), step 3, asks for scope content and permission evidence/contact; its [visible form](../review-input/final-content/R01/disclosures/appendix-1-960-visible.txt) explicitly lists missing scope content and permission evidence as HOLD conditions. R05's [REVIEW-GUIDE](../review-input/final-content/R05/handoff/REVIEW-GUIDE.md), steps 4–5, requires named/time-stamped supporting evidence, snapshot identity and scope details. Its [visible form](../review-input/final-content/R05/disclosures/appendix-1-960-visible.txt) has these separate fields. The synthetic cards supply confirmed labels, but no scope narrative, hash, confirmer or detailed evidence. These readers decline to invent those details and apply a stricter full-template readiness reading.

That ambiguity limits interpretation: these are conservative fixture-versus-template mismatches, rather than evidence of invented authorization or failure to preserve missing values. It does not change the frozen answer. Reader 09 also supplies `fixture_flags_only_status=READY FOR REVIEW` for A; that alternate was recorded and was **not substituted** for its actual `record_status=HOLD`. Reader 10's condition-only prose was likewise not substituted.

## The ten saved linked actions

All ten actions exist as usable saved CSV/JSON rows, link SYN-C to SYN-red.csv / data row 2, assign the confirmation task to SYN Coordinator, and request both a reviewer identity and the time that reviewer can work. Original reviewer stays empty and original availability stays unknown. Coordinator ownership is distinct from the missing audit reviewer. Each has a direct or clearly linked explanation.

| Reader | Actual action record | Observed action gate | Frozen result |
|---|---|---|---|
| 01 | [SYN-C-new-action.csv](../final-readers/reader-01/SYN-C-new-action.csv) | HOLD | pass |
| 02 | [SYN-C-confirmation-action.csv](../final-readers/reader-02/SYN-C-confirmation-action.csv) | HOLD | pass |
| 03 | [new-action-SYN-C.csv](../final-readers/reader-03/new-action-SYN-C.csv) | HOLD | pass |
| 04 | [new-action-record.csv](../final-readers/reader-04/new-action-record.csv) | HOLD | pass |
| 05 | [SYN-C-action-record.json](../final-readers/reader-05/SYN-C-action-record.json) | HOLD | pass |
| 06 | [action-SYN-C.json](../final-readers/reader-06/action-SYN-C.json) | HOLD | pass |
| 07 | [new-action-record.csv](../final-readers/reader-07/new-action-record.csv) | HOLD | pass |
| 08 | [linked-action-record.csv](../final-readers/reader-08/linked-action-record.csv) | DRAFT - NOT SENT; parent HOLD | fail: no action HOLD |
| 09 | [SYN-C-action.csv](../final-readers/reader-09/SYN-C-action.csv) | execution_gate=HOLD; separate draft delivery state | pass |
| 10 | [SYN-C-action.csv](../final-readers/reader-10/SYN-C-action.csv) | not done; permission not granted; parent linked/HOLD | fail: no action HOLD |

Reader 08 explicitly preserves source-record HOLD and its reason, uses NOT STARTED, and provides a confirmation trigger. Reader 10 uses not-done progress, no permission and an unchanged linked parent. These retain conservative no-start boundaries and are not missing or fabricated action records. However, neither explicitly records the **action's HOLD-until-confirmation gate** required by the frozen mechanics. Parent HOLD or draft/not-done progress was not silently converted to an action HOLD. This is why there are ten usable core action records but eight full frozen action passes.

Reader 06's JSON and CSV action copies share one action ID and represent **one logical action**, not two. Its four nested record JSON files supplement the four CSV fixture rows; they are not four additional fixture decisions.

## Integrity and clocks

Every sealed file was hashed before content inspection, with reader 10 delayed until permission. The retained checker then verified all sealed files before parsing and again afterward: **45 distinct raw files; 55 seal-file checks in each snapshot; all match; zero missing or unsealed files**. Manager bytes agree with both phase-one and final seals. These receipts are fully retained in RESULT.json.

| Reader | Final sealed, UTC | Supplied combined deadline, UTC | Within deadline |
|---|---|---|---|
| 01 | 05:04:48 | 05:17:41 | yes |
| 02 | 05:04:48 | 05:17:46 | yes |
| 03 | 05:12:12 | 05:25:05 | yes |
| 04 | 05:12:39 | 05:25:16 | yes |
| 05 | 05:18:13 | 05:32:00 | yes |
| 06 | 05:19:08 | 05:32:39 | yes |
| 07 | 05:23:55 | 05:38:13 | yes |
| 08 | 05:25:06 | 05:39:08 | yes |
| 09 | 05:29:54 | 05:43:55 | yes |
| 10 | 05:31:14 | 05:45:06 | yes |

Clocks and dispatch/deadline declarations are retained metadata, not an independently observed dispatch trace. Reader 06's phase-one clock used first observation to show 05:32:55; its recipient record applies the earlier owner deadline 05:32:39 without modifying manager.json. Its delivery precedes both. Exact backend model/version, hidden sampling and token use are unavailable.

There are **six complete reader deliveries against every frozen recipient check** (01, 03, 04, 05, 06, 07), while all ten have actual saved records and preserve every raw fixture value. This is a bounded model-reader trial. It does not establish actual staff availability, approval, completed source review, human comprehension, or a method's real-world effectiveness. No answer repair was performed.
