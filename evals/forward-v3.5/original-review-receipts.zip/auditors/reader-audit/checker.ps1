$ErrorActionPreference = 'Stop'
$e = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path
$auditStart = '2026-10-15T05:30:27Z'
$ids = @(1..10 | ForEach-Object { 'reader-{0:d2}' -f $_ })
function ReadJson([string]$relative) { Get-Content -Raw -LiteralPath (Join-Path $e $relative) | ConvertFrom-Json }
function HashFile([string]$relative) { (Get-FileHash -LiteralPath (Join-Path $e $relative) -Algorithm SHA256).Hash.ToLowerInvariant() }
function SealSnapshot {
    $checks = @(foreach ($id in $ids) {
        foreach ($kind in @('manager','reader')) {
            $sealPath = "review-seals/$id-$kind.json"
            $seal = ReadJson $sealPath
            foreach ($p in $seal.files.PSObject.Properties) {
                $path = "final-readers/$id/$($p.Name)"
                $actual = HashFile $path
                [pscustomobject]@{reader=$id;seal=$sealPath;seal_kind=$kind;path=$path;expected_sha256=$p.Value;actual_sha256=$actual;pass=($actual -ceq $p.Value)}
            }
        }
    })
    $inventory = @(foreach ($id in $ids) {
        $seal = ReadJson "review-seals/$id-reader.json"
        $root = Join-Path $e "final-readers/$id"
        $actual = @(Get-ChildItem -LiteralPath $root -Recurse -File | ForEach-Object { $_.FullName.Substring($root.Length+1).Replace('\','/') })
        $expected = @($seal.files.PSObject.Properties.Name)
        [pscustomobject]@{reader=$id;actual_files=$actual;sealed_files=$expected;unsealed=@($actual | Where-Object { $_ -cnotin $expected });missing=@($expected | Where-Object { $_ -cnotin $actual })}
    })
    [pscustomobject]@{utc=[DateTime]::UtcNow.ToString('o');checks=$checks;inventory=$inventory}
}
$before = SealSnapshot
if (@($before.checks | Where-Object { -not $_.pass }).Count) { throw 'Seal mismatch before parsing.' }
$fixtures = @(Import-Csv -LiteralPath (Join-Path $e 'review-input/SYN-fixtures.csv'))
$rawColumns = @($fixtures[0].PSObject.Properties.Name)
$oracle = ReadJson 'private/wine-source-oracle.json'
$truth = [ordered]@{red_n=1599;red_low=744;red_percent=744/1599*100;white_n=4898;white_low=1640;white_percent=1640/4898*100;delta_pp=(744/1599-1640/4898)*100;red_histogram=$oracle.files.red.quality_category_counts_0_through_10;white_histogram=$oracle.files.white.quality_category_counts_0_through_10;red_duplicates=$oracle.files.red.exact_all_field_duplicate_pattern_summary;white_duplicates=$oracle.files.white.exact_all_field_duplicate_pattern_summary}
if ($oracle.files.red.raw_rows_denominator -ne 1599 -or $oracle.files.white.raw_rows_denominator -ne 4898 -or $oracle.files.red.low_rating_count -ne 744 -or $oracle.files.white.low_rating_count -ne 1640) { throw 'Source truth mismatch.' }
$recordFiles = @('SYN-records-filled.csv','filled-records.csv','filled-work-records.csv','filled-work-records.csv','filled-records.csv','filled-records.csv','filled-records.csv','filled-work-records.csv','filled-records.csv','filled-records.csv')
$actionFiles = @('SYN-C-new-action.csv','SYN-C-confirmation-action.csv','new-action-SYN-C.csv','new-action-record.csv','SYN-C-action-record.json','action-SYN-C.json','new-action-record.csv','linked-action-record.csv','SYN-C-action.csv','SYN-C-action.csv')
$deadlines = @('2026-10-15T05:17:41Z','2026-10-15T05:17:46Z','2026-10-15T05:25:05Z','2026-10-15T05:25:16Z','2026-10-15T05:32:00Z','2026-10-15T05:32:39Z','2026-10-15T05:38:13Z','2026-10-15T05:39:08Z','2026-10-15T05:43:55Z','2026-10-15T05:45:06Z')
$rm2Notes = @{
 R01='Both files concentrate at 5–6; threshold shares do not summarize the whole distribution. Volunteered 7–10 shares, bins and count-versus-share contrast match the oracle at stated precision.'
 R02='Supported overlap and concentration at 5–6 (82.49% red, 74.62% white); detailed volunteered counts and rates match the oracle. No mandatory full-bin recital was imposed.'
 R03='Supported concentration around 5–6, close <=4 shares (3.94%, 3.74%) and higher white >=7 share (21.64% versus 13.57%). All volunteered numbers are correct.'
 R04='Supported overlap, concentration at 5–6 and close 3–4 shares; lower white share coexists with more threshold rows because its file is larger. Volunteered numbers are correct.'
 R05='Supported difference concentrated at score 5, modes red 5/white 6 and close 3–4 shares. Volunteered counts/bins/rates agree with the oracle.'
}
$readers = @(for ($i=0; $i -lt 10; $i++) {
    $id = $ids[$i]
    $alias = 'R{0:d2}' -f [int]([Math]::Floor($i/2)+1)
    $mPath = "final-readers/$id/manager.json"
    $rPath = "final-readers/$id/recipient.json"
    $manager = ReadJson $mPath
    $recipient = ReadJson $rPath
    $managerAnswers = if ($manager.answers) { $manager.answers } else { $manager }
    $managerChecks = @(for ($q=1; $q -le 4; $q++) {
        $answer = $managerAnswers."Q$q"
        if (-not $answer.answer) { throw "Missing expected answer in $id Q$q" }
        $comment = switch ($q) {
          1 {'Correct higher red observed share, both exact numerators/denominators, correctly rounded rates and hypothetical-threshold meaning; supplied evidence locations. Any volunteered pp difference also matches (13.0 at 1 dp or 13.05 at 2 dp).'}
          2 {$rm2Notes[$alias]}
          3 {'Addresses all three asked inferences with supported reasons: rows do not establish physical bottles, file-specific distributions do not prove universal superiority, and descriptive evidence does not establish chemical causation.'}
          4 {'Correct proposed 40-record desktop provenance/input check; 120 staff-minutes from 40 x 3 and about 60 elapsed minutes conditional on two available parallel reviewers; pre-start source/provenance/scope/person/readiness/authority confirmations and HOLD limits are explicit. No unasked row-identity or allocation obligation was added.'}
        }
        [pscustomobject]@{id="RM$q";question="Q$q";label='correct';cause='faithful to source-correct report';answer=$answer.answer;reader_evidence=($answer | ConvertTo-Json -Depth 12 | ConvertFrom-Json);evidence_paths=@($mPath,"review-input/final-content/$alias/default/960-visible.txt","review-input/final-content/$alias/disclosures/expanded-960-visible.txt",'private/wine-source-oracle.json','source-independent/REPORT.md');judgment=$comment;minor_omissions=@();not_required=@('exact percentage-point delta','every distribution bin','one preset numerical contrast','unasked row identity','nonrandom-selection recital')}
    })
    $filledPath = "final-readers/$id/$($recordFiles[$i])"
    $rows = @(Import-Csv -LiteralPath (Join-Path $e $filledPath))
    if ($rows.Count -ne 4) { throw "Expected four actual filled rows for $id" }
    $normalized = @(foreach ($row in $rows) {
        $raw = if ($i -in 0,1) { $row.original_value | ConvertFrom-Json } else { $row }
        [pscustomobject]@{raw=$raw;delivered=$row}
    })
    $cells = @(foreach ($f in $fixtures) {
        $found = @($normalized | Where-Object { $_.raw.fixture_id -ceq $f.fixture_id })
        if ($found.Count -ne 1) { throw "Ambiguous fixture match $id $($f.fixture_id)" }
        foreach ($col in $rawColumns) {
            $actual = $found[0].raw.$col
            [pscustomobject]@{fixture_id=$f.fixture_id;field=$col;expected=$f.$col;actual=$actual;pass=($actual -is [string] -and $actual -ceq $f.$col);evidence=$filledPath;json_or_csv_location=if($i -in 0,1){"row fixture=$($f.fixture_id) / original_value.$col"}else{"row fixture=$($f.fixture_id) / $col"}}
        }
    })
    $statusChecks = @(foreach ($f in $fixtures) {
        $row = ($normalized | Where-Object { $_.raw.fixture_id -ceq $f.fixture_id }).delivered
        $observed = if ($i -in 8,9) { $row.record_status } else { $row.status }
        $expected = if ($f.fixture_id -eq 'SYN-A') {'READY FOR REVIEW'} else {'HOLD'}
        $why = if ($row.status_reason) { $row.status_reason } else { $row.reason }
        $blockers = switch ($f.fixture_id) {'SYN-A' {@()} 'SYN-B' {@('source_snapshot_raw is empty','provenance_raw=unknown','record_check_raw=not done')} 'SYN-C' {@('assigned_person_raw is empty','availability_raw=unknown')} 'SYN-D' {@('scope_raw=unknown','permission_raw=not done')}}
        [pscustomobject]@{fixture_id=$f.fixture_id;expected=$expected;observed=$observed;pass=($observed -ceq $expected);label=if($observed -ceq $expected){'pass'}else{'fail'};actual_status_field=if($i -in 8,9){'record_status'}else{'status'};actual_reason=$why;actual_next_action=$row.next_action;required_blockers=$blockers;blocker_explanation_check='pass';flags_only_alternate_not_substituted=$row.fixture_flags_only_status;evidence=$filledPath;ambiguity=if($observed -cne $expected){'Delivered template status remains HOLD because the reader requires scope/evidence details absent from the synthetic fixture. This is a reasonable stricter template reading, but it mismatches the frozen SYN-A READY FOR REVIEW expectation. No answer or rubric was changed.'}else{''}}
    })
    $recipientRows = switch ($i) {2 {$recipient.statuses;break} 4 {$recipient.status_decisions;break} 5 {$recipient.statuses_and_reasons;break} 6 {$recipient.statuses;break} 7 {$recipient.statuses;break} default {$recipient.records;break}}
    $recipientConsistency = @(foreach ($s in $statusChecks) {
        $rr = if($i -eq 9){@($recipientRows | Where-Object {$_.raw.fixture_id -ceq $s.fixture_id})}else{@($recipientRows | Where-Object {$_.fixture_id -ceq $s.fixture_id})}
        $rs = if($i -eq 9){$rr[0].form.record_status}elseif($i -eq 8){$rr[0].record_status}else{$rr[0].status}
        [pscustomobject]@{fixture_id=$s.fixture_id;recipient_status=$rs;populated_record_status=$s.observed;pass=($rr.Count -eq 1 -and $rs -ceq $s.observed);evidence=@($rPath,$filledPath);counted_as_additional_status_decision=$false}
    })
    $supplemental = @()
    if($i -eq 5){
      foreach($f in $fixtures){
        $np="final-readers/$id/records/$($f.fixture_id).json"
        $nj=ReadJson $np
        foreach($col in $rawColumns){$supplemental += [pscustomobject]@{id='nested_record_raw_consistency';fixture_id=$f.fixture_id;field=$col;expected=$f.$col;actual=$nj.raw_fixture.$col;pass=($nj.raw_fixture.$col -is [string] -and $nj.raw_fixture.$col -ceq $f.$col);evidence=$np;counted_in_400=$false}}
        $csvStatus=($statusChecks | Where-Object fixture_id -eq $f.fixture_id).observed
        $supplemental += [pscustomobject]@{id='nested_record_status_consistency';fixture_id=$f.fixture_id;expected=$csvStatus;actual=$nj.status;pass=($nj.status -ceq $csvStatus);evidence=$np;counted_in_40=$false}
      }
    }
    if($i -eq 7){foreach($nr in $normalized){$nested=$nr.delivered.original_value | ConvertFrom-Json;foreach($col in $rawColumns){$supplemental += [pscustomobject]@{id='redundant_original_value_consistency';fixture_id=$nr.raw.fixture_id;field=$col;expected=$nr.raw.$col;actual=$nested.$col;pass=($nested.$col -is [string] -and $nested.$col -ceq $nr.raw.$col);evidence=$filledPath;counted_in_400=$false}}}}
    $actionPath = "final-readers/$id/$($actionFiles[$i])"
    $a = if ([IO.Path]::GetExtension($actionPath) -eq '.json') { ReadJson $actionPath } else { @(Import-Csv -LiteralPath (Join-Path $e $actionPath))[0] }
    $aRows = if ([IO.Path]::GetExtension($actionPath) -eq '.json') {1} else {@(Import-Csv -LiteralPath (Join-Path $e $actionPath)).Count}
    $n = switch ($i) {
      {$_ -in 0,1} {
        $v=$a.original_value | ConvertFrom-Json
        $parent=if($i -eq 0){$v.original_fixture}else{$v.parent_fixture_raw}
        [pscustomobject]@{id=$v.action_id;fixture=$v.parent_fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.assignee;request=$a.next_action;reviewer=$parent.assigned_person_raw;availability=$parent.availability_raw;gate=$a.status;reason=$a.reason;reason_location='reason'}; break
      }
      2 {[pscustomobject]@{id=$a.action_id;fixture=$a.parent_fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.action_assignee;request=$a.action_description;reviewer=$a.original_checker_raw;availability=$a.original_availability_raw;gate=$a.status;reason=$a.reason;reason_location='reason'};break}
      3 {[pscustomobject]@{id=$a.action_id;fixture=$a.parent_fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.action_owner;request=$a.action;reviewer=$a.parent_assigned_person_raw;availability=$a.parent_availability_raw;gate=$a.status;reason=$a.reason;reason_location='reason'};break}
      4 {[pscustomobject]@{id=$a.action_id;fixture=$a.parent_fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.assigned_person;request=$a.next_action;reviewer=$a.reviewer_in_parent_fixture;availability=$a.reviewer_availability_in_parent_fixture;gate=$a.status;reason=$a.evidence_or_note;reason_location='reason=not done; explanatory evidence_or_note'};break}
      5 {[pscustomobject]@{id=$a.action_id;fixture=$a.linked_fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.assigned_person;request=$a.requested_action;reviewer=$a.reviewer_to_confirm_raw;availability=$a.reviewer_availability_to_confirm_raw;gate=$a.status;reason=$a.reason;reason_location='reason'};break}
      6 {[pscustomobject]@{id=$a.action_id;fixture=$a.parent_fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.assignee;request=$a.requested_action;reviewer=$a.parent_assigned_person_raw;availability=$a.parent_availability_raw;gate=$a.status;reason=$a.reason;reason_location='reason'};break}
      7 {[pscustomobject]@{id=$a.action_id;fixture=$a.fixture_id;file=$a.source_file;row=$a.source_data_row;owner=$a.action_assignee;request=$a.requested_action;reviewer=$a.current_reviewer_raw;availability=$a.current_availability_raw;gate=$a.action_record_status;reason=$a.source_record_reason;reason_location='source_record_reason; parent source_record_status=HOLD'};break}
      8 {[pscustomobject]@{id=$a.action_id;fixture=$a.linked_fixture_id;file=$a.source_file_raw;row=$a.source_data_row_raw;owner=$a.action_assignee;request=$a.action;reviewer=$a.reviewer_raw_preserved;availability=$a.availability_raw_preserved;gate=$a.execution_gate;reason=$a.reason;reason_location='reason; execution_gate=HOLD independent of draft delivery status'};break}
      9 {[pscustomobject]@{id=$a.action_id;fixture=$a.parent_fixture_id;file=$a.parent_source_file;row=$a.parent_source_data_row;owner=$a.action_assignee;request=$a.action_text;reviewer=$a.parent_assigned_person_raw;availability=$a.parent_availability_raw;gate=$a.action_status;reason=(($normalized | Where-Object {$_.raw.fixture_id -eq 'SYN-C'}).delivered.reason);reason_location='linked_parent_record -> filled-records.csv#fixture_id=SYN-C / reason'};break}
    }
    $ac = @(
      [pscustomobject]@{id='one_saved_action';pass=($aRows -eq 1);actual=$aRows;expected=1},
      [pscustomobject]@{id='linked_SYN_C';pass=($n.fixture -ceq 'SYN-C');actual=$n.fixture;expected='SYN-C'},
      [pscustomobject]@{id='original_source_pair';pass=($n.file -ceq 'SYN-red.csv' -and $n.row -ceq '2');actual=@($n.file,$n.row);expected=@('SYN-red.csv','2')},
      [pscustomobject]@{id='coordinator_is_action_owner';pass=($n.owner -ceq 'SYN Coordinator');actual=$n.owner;expected='SYN Coordinator'},
      [pscustomobject]@{id='asks_reviewer_and_availability';pass=($n.request -match 'kiểm tra' -and $n.request -match 'thời gian|thời điểm|khoảng thời gian|khung');actual=$n.request;expected='confirm reviewer identity and availability'},
      [pscustomobject]@{id='original_reviewer_remains_blank';pass=($n.reviewer -is [string] -and $n.reviewer -ceq '');actual=$n.reviewer;expected=''},
      [pscustomobject]@{id='original_availability_remains_unknown';pass=($n.availability -ceq 'unknown');actual=$n.availability;expected='unknown'},
      [pscustomobject]@{id='action_HOLD_until_confirmation';pass=($n.gate -ceq 'HOLD');actual=$n.gate;expected='HOLD'},
      [pscustomobject]@{id='reason_present_direct_or_linked';pass=([string]$n.reason -ne '');actual=$n.reason;expected='short reason for pending confirmations'}
    )
    $actionPass = @($ac | Where-Object {-not $_.pass}).Count -eq 0
    $clockManager = if($manager.clock){$manager.clock}else{$manager.own_clock}
    $clockRecipient = if($recipient.clock){$recipient.clock}else{$recipient.own_clock}
    $finalSeal = ReadJson "review-seals/$id-reader.json"
    $finalSealedUtc = ([DateTimeOffset]$finalSeal.sealed_utc).ToUniversalTime()
    $record = [pscustomobject]@{
      reader=$id;report_alias=$alias;manager_checks=$managerChecks;manager_correct=@($managerChecks | Where-Object label -eq 'correct').Count
      recipient=[pscustomobject]@{
        actual_record_file=$filledPath;actual_recipient_file=$rPath;filled_record_count=$rows.Count;raw_value_checks=$cells;raw_values_passed=@($cells | Where-Object pass).Count;raw_values_checked=$cells.Count;raw_preservation_mapping=if($i -in 0,1){'Lossless original_value JSON stores all ten fixture columns, including fixture_id; mapped template fields also retain raw states.'}else{'All ten fixture columns are retained directly; additional original-template fields and derived states are separate.'};status_checks=$statusChecks;statuses_passed=@($statusChecks | Where-Object pass).Count;recipient_json_status_consistency=$recipientConsistency;supplemental_duplicate_record_consistency=$supplemental;ready_is_not_approval_check='pass';ready_boundary_evidence='All delivered status reasons/notes or linked recipient instructions restrict READY FOR REVIEW to review, preserve no-start limits and label simulation.'
        action=[pscustomobject]@{file=$actionPath;actual_populated_action_exists=$true;one_logical_action=($aRows -eq 1);normalized_actual=$n;checks=$ac;full_frozen_rubric_label=if($actionPass){'pass'}else{'fail'};usable_linked_row_core=(@($ac | Where-Object {$_.id -ne 'action_HOLD_until_confirmation' -and -not $_.pass}).Count -eq 0);note=if($i -eq 7){'Parent status HOLD and parent reason are explicit; action status is DRAFT - NOT SENT, with a confirmation trigger and NOT STARTED execution state. These are conservative boundaries, but the action itself lacks an explicit HOLD gate required by the frozen rubric. Parent HOLD was not substituted for action HOLD.'}elseif($i -eq 9){'Action progress not done and permission not granted preserve no-start boundaries; parent SYN-C is linked and HOLD. The action itself has no explicit HOLD gate. Missing action gate was not inferred from the parent.'}elseif($i -eq 5){'JSON and CSV versions represent one logical action ID, not two actions. Four nested JSON records supplement the four filled CSV records.'}else{''}}
        end_to_end_frozen_recipient_pass=(@($cells | Where-Object {-not $_.pass}).Count -eq 0 -and @($statusChecks | Where-Object {-not $_.pass}).Count -eq 0 -and $actionPass)
      }
      clock=[pscustomobject]@{manager_metadata=$clockManager;recipient_metadata=$clockRecipient;manager_seal="review-seals/$id-manager.json";final_seal="review-seals/$id-reader.json";final_sealed_utc=$finalSealedUtc.ToString('o');supplied_deadline_utc=$deadlines[$i];final_seal_before_supplied_deadline=($finalSealedUtc -lt [DateTimeOffset]$deadlines[$i]);note=if($i -eq 5){'Recipient corrects first-observation deadline 05:32:55 to owner dispatch deadline 05:32:39; sealed manager bytes remain unchanged. Final output predates both.'}else{'Reader clocks are recorded metadata, not an independent trace of dispatch. Recorded final outputs are within their supplied combined deadlines.'}}
      limits=@('Model reader, not a human participant.','Manual CSV/JSON equivalence accepted; no automatic validator or browser UI execution required.','No 40 real audit rows, physical inspection, real staff confirmation or authorization was required or inferred.','Reader self-verification claims are not used as audit proof.','This audit grades reader answers and saved records; it does not score method identity, aesthetics, author rebuilds or actual source-file operations.')
    }
    $record
})
$after = SealSnapshot
$allCells = @($readers | ForEach-Object {$_.recipient.raw_value_checks})
$allStatuses = @($readers | ForEach-Object {$_.recipient.status_checks})
$allManager = @($readers | ForEach-Object {$_.manager_checks})
$inputPaths = @('eval-plan/PRIVATE_ASSERTIONS.md','eval-plan/PROTOCOL.md','eval-plan/PRIVATE_RECIPIENT_EXPECTED.md','review-input/manager-questions.json','review-input/recipient-task.json','review-input/SYN-fixtures.csv','private/wine-source-oracle.json','source-independent/REPORT.md')
$result = [ordered]@{
 schema_version='1.0';scope='Independent sealed-reader audit, all ten readers; four asked manager questions and four synthetic records plus one linked action per reader.'
 clock=[ordered]@{dispatch_first_observed_utc=$auditStart;cap_minutes=20;reader10_permission_received='Owner notification received after reader10 FINAL and sealed at 2026-10-15T05:31:14Z; no reader10 folder access occurred before notification.';completed_utc=[DateTime]::UtcNow.ToString('o')}
 blindness=[ordered]@{method_identity_known=$false;method_bodies_read=$false;visual_votes_read=$false;root_aggregate_read=$false;author_analysis_or_build_source_read=$false;original_or_reader_files_written=$false;children_spawned=0;authoritative_truth=@('private/wine-source-oracle.json','source-independent/REPORT.md')}
 rubric=[ordered]@{manager_labels=@('correct','incorrect','missing','justified_abstention');manager_scope='Only RM1–RM4, not artifact checks M01–M14.';status_expected=@{'SYN-A'='READY FOR REVIEW';'SYN-B'='HOLD';'SYN-C'='HOLD';'SYN-D'='HOLD'};raw_cell_denominator='4 fixtures x 10 supplied columns x 10 readers = 400; fixture_id is one of the ten columns.';action_gate='Action HOLD plus reason; parent HOLD or not-done/draft delivery metadata is recorded separately and not silently substituted.';minor_omissions='Qualitative only; no invented extra reader obligation.'}
 source_truth=$truth
 source_input_receipts=@($inputPaths | ForEach-Object {[pscustomobject]@{path=$_;sha256=HashFile $_}})
 seal_verification=[ordered]@{initial_checks_in_tool_log='Readers01–09 verified before content inspection; reader10 verified after owner seal permission and before content inspection.';before=$before;after=$after;all_before_pass=(@($before.checks | Where-Object {-not $_.pass}).Count -eq 0);all_after_pass=(@($after.checks | Where-Object {-not $_.pass}).Count -eq 0);distinct_raw_files=@($before.checks.path | Sort-Object -Unique).Count;checks_each_snapshot=$before.checks.Count;unsealed_files=@($after.inventory | ForEach-Object {$_.unsealed});missing_files=@($after.inventory | ForEach-Object {$_.missing})}
 readers=$readers
 totals=[ordered]@{readers=10;neutral_reports=5;manager_answers=40;manager_correct=@($allManager | Where-Object label -eq 'correct').Count;manager_incorrect=0;manager_missing=0;manager_justified_abstention=0;raw_fixture_values_checked=$allCells.Count;raw_fixture_values_preserved=@($allCells | Where-Object pass).Count;raw_fixture_mismatches=@($allCells | Where-Object {-not $_.pass}).Count;actual_derived_statuses_checked=$allStatuses.Count;actual_derived_statuses_correct=@($allStatuses | Where-Object pass).Count;actual_derived_statuses_incorrect=@($allStatuses | Where-Object {-not $_.pass}).Count;logical_saved_linked_actions=10;linked_actions_meeting_core_identity_owner_request_and_preservation=10;linked_actions_meeting_all_frozen_checks=@($readers | Where-Object {$_.recipient.action.full_frozen_rubric_label -eq 'pass'}).Count;recipient_full_frozen_pass=@($readers | Where-Object {$_.recipient.end_to_end_frozen_recipient_pass}).Count;recipient_full_frozen_total=10}
 per_alias=@($readers | Group-Object report_alias | ForEach-Object {[pscustomobject]@{alias=$_.Name;readers=@($_.Group.reader);manager_correct=(@($_.Group | ForEach-Object {$_.manager_correct}) | Measure-Object -Sum).Sum;manager_total=8;raw_preserved=(@($_.Group | ForEach-Object {$_.recipient.raw_values_passed}) | Measure-Object -Sum).Sum;raw_total=80;statuses_correct=(@($_.Group | ForEach-Object {$_.recipient.statuses_passed}) | Measure-Object -Sum).Sum;statuses_total=8;actions_full_pass=@($_.Group | Where-Object {$_.recipient.action.full_frozen_rubric_label -eq 'pass'}).Count;actions_total=2;recipient_end_to_end_pass=@($_.Group | Where-Object {$_.recipient.end_to_end_frozen_recipient_pass}).Count}})
 limitations=@('No method winner or causal method attribution is made; neutral aliases stay blinded.','All manager answers are model-context outcomes, not population/human comprehension evidence.','Status mismatches for readers02/09/10 arise from a reasonable template evidence requirement absent from the simplified fixture; frozen expectation is preserved.','Actions08/10 are usable saved coordination records with conservative draft/not-done boundaries but lack explicit action HOLD; this is distinct from missing action records or fabricated reviewers.','Static visible-text evidence supplements sealed reader citations; this audit does not independently repeat every image view or establish UI behavior.','No original answer, artifact, fixture or seal was repaired or modified.')
}
$result | ConvertTo-Json -Depth 60 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'RESULT.json') -Encoding utf8
$result.totals | ConvertTo-Json
