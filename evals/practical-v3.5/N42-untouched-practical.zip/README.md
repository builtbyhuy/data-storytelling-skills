# Bàn giao · Đọc dữ liệu Wine Quality

Mở `report.html` bằng trình duyệt. Toàn bộ nội dung, biểu đồ và phiếu đọc được ngoại tuyến; không cần mạng, đăng nhập, cài gói hay dịch vụ ngoài. Giữ nguyên cấu trúc thư mục khi sao chép gói. Các liên kết UCI/DOI/giấy phép chỉ là tham khảo, không cần truy cập để sử dụng báo cáo.

## Người nhận làm gì tiếp theo?

1. Đọc kết luận và tỷ lệ của từng tệp; xem phân bố đầy đủ 0–10, dòng trùng và giới hạn trong chính trang báo cáo.
2. Nếu muốn chuẩn bị công việc: mở `review-40-records.csv`. Đây là 20 dòng dữ liệu đầu của mỗi tệp; A/B chỉ là hai vị trí đề xuất, chưa có người nhận việc thật. Mọi dòng đang HOLD.
3. Mở `work-form.html` hoặc sao chép `work-record-blank.csv` thành phiếu mới. Một phiếu ghi một hồ sơ, một người và bước tiếp theo. Định danh là `source_file + source_data_row`, vị trí bắt đầu từ 1 sau tiêu đề. `work-record-example.csv` minh họa một dòng nguồn thật nhưng mọi xác nhận vẫn unknown và trạng thái HOLD; không phải kiểm tra đã thực hiện.
4. Giữ nguyên giá trị gốc trống / `unknown` / `not done`. Xác nhận bản chụp, xuất xứ, phạm vi, người thật, sự sẵn sàng và quyền thực hiện bằng bằng chứng. Thiếu bất cứ điều kiện cần nào: HOLD và ghi lý do. Đủ trên hồ sơ: chỉ READY FOR REVIEW; vẫn chưa cho phép bắt đầu. Chuyển người có thẩm quyền duyệt và cho phép riêng.
5. Trang phiếu không tự lưu và không tự xác minh. Nút tải JSON giữ nguyên mọi trường hiện tại. Ghi một tên tệp mới để giữ mỗi hồ sơ. CSV có UTF-8 BOM để hỗ trợ phần mềm bảng tính; HTML và mã dùng UTF-8.

## Mã nguồn, môi trường và công thức dựng lại

Yêu cầu: Python 3.10 trở lên (đã chạy thực tế bằng Python 3.12.14), chỉ thư viện chuẩn. Trình duyệt hiện đại để đọc HTML/SVG; không cần Node hoặc Playwright để dựng lại báo cáo.

Từ thư mục `practical` của gói, dùng lệnh nguyên văn:

    python -B build.py

`python` phải trỏ tới một Python 3 đã cài dùng được, không phải lối tắt Windows Store. Trên máy thử, cùng mã và đối số được chạy thông qua bộ khởi chạy Python có sẵn của môi trường; gói không dùng đường dẫn cá nhân trong mã hoặc lệnh portable. Không tải dữ liệu hoặc thư viện. Có thể dùng đường dẫn tuyệt đối tới Python của người nhận thay tên `python` nếu cần thiết lập cục bộ.

Đầu vào tương đối được giữ: `source/winequality-red.csv`, `source/winequality-white.csv`, từ điển, giấy phép, ZIP gốc và `report.template.html`. `build.py` xác minh SHA-256 trước khi tính. Nếu bản chụp khác, nó dừng; không tự tải hoặc âm thầm chấp nhận nguồn khác. Muốn phân tích bản chụp khác phải chủ động cập nhật xuất xứ và quy tắc xác nhận, không chỉ ghi đè CSV.

Đầu ra tái tạo: `report.html`, `facts.csv`, `source-manifest.json`, `review-40-records.csv`, `work-record-blank.csv`, `work-record-example.csv`. `work-form.html`, README, biên bản tự kiểm tra và ảnh kiểm tra là phần giữ sẵn trong gói; không cần sinh lại để đọc hoặc sửa chúng. **Dựng lại ghi đè các đầu ra liệt kê; hãy lưu hồ sơ đã điền sang tên mới trước đó.** Ảnh QA mô tả lần kiểm tra đã ghi, không tự cập nhật khi sửa trang.

## Quy tắc phân tích

- Dấu phân cách `;`, phần thập phân `.`, tên cột có ngoặc kép. Đúng 12 cột, không nối hoặc lọc dữ liệu. Loại rượu lấy từ tên tệp.
- Hạt là bản ghi của tệp. Mẫu số gồm toàn bộ bản ghi, bỏ duy nhất tiêu đề. Tử số đếm `quality` hợp lệ nguyên 0–10 và ≤5. Điểm trống/không hợp lệ được đếm riêng nhưng vẫn trong mẫu số.
- Giữ mọi dòng trùng. So khớp tổ hợp chuỗi giá trị của cả 12 cột trong từng tệp; không chuẩn hóa số trước khi xác định trùng. “Dòng lặp thêm” = số dòng gốc − số tổ hợp khác nhau. Không suy từ trùng bản ghi sang trùng chai hoặc lỗi.
- Đếm phân bố đầy đủ 0–10, kể cả mức có 0 dòng. Tỷ lệ là số dòng / số dòng tệp ×100. Phần trăm hiển thị 2 chữ số; dữ kiện giữ số đếm và tỷ lệ Decimal 28 chữ số có nghĩa. Nguồn số đếm là căn cứ chính để tính lại tỷ lệ chính xác.
- Kiểm tra ô trống và số không hữu hạn/không phải số riêng cho từng trường. Không gán kiểm tra này thành bằng chứng phép đo đúng hoặc giới hạn hóa học hợp lệ.
- Chênh lệch điểm phần trăm = tỷ lệ đỏ − tỷ lệ trắng, không phải thay đổi tương đối. Không tính trung bình thang thứ bậc, không kiểm định nhân quả, không suy rộng ra chai riêng biệt, thị trường, giá, chi phí hoặc thời gian chưa có.
- Lịch sử trong nguồn không có ngày từng phép đo. Ngày 15.10.2026 là ngày lưu bản chụp được cung cấp, không phải kỳ đo dữ liệu.

## Tài liệu và trạng thái

- `facts.csv`: chỉ tiêu, tệp/nhóm, giá trị, mẫu số, đơn vị, ghi chú. Các hàng phân bố giữ cả số đếm và tỷ lệ; các giả định 40 hồ sơ, 2 người đề xuất, 20 mỗi người, 3 phút/hồ sơ, 120 phút công và 60 phút song song được tách rõ.
- `source/`: hai CSV nguyên byte, ZIP chính thức, từ điển gốc, CC BY 4.0 và hồ sơ xuất xứ được cung cấp.
- `source-manifest.json`: kích thước và SHA-256 của các đầu vào gốc.
- `qa/`: ảnh trình duyệt ngoại tuyến và biên nhận kiểm tra cơ học. `self-review.md`: phạm vi tự kiểm tra, thời gian và giới hạn.

Nguồn: Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009). *Wine Quality* [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56S3T. CC BY 4.0, theo hồ sơ nguồn đã cung cấp. CSV không thay đổi; mã, dữ kiện tổng hợp và trang là phân tích dẫn xuất.

Báo cáo đã được chuẩn bị và tự kiểm tra. Không có người dùng thử, chấp thuận, thực thi, kết quả kinh doanh hoặc cải thiện chất lượng rượu nào được xác nhận từ gói này.
