#!/usr/bin/env python3
"""Offline, deterministic Wine Quality report. Python >=3.10, standard library only."""
from pathlib import Path
import csv, hashlib, json, html, collections, decimal, sys
ROOT = Path(__file__).resolve().parent
D = decimal.Decimal
EXPECTED = {
 'winequality-red.csv': '4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e',
 'winequality-white.csv': '76c3f809815c17c07212622f776311faeb31e87610d52c26d87d6e361b169836',
 'winequality.names': '15d215e73b39105952380fd487e4ce1bf5a6b83a425abb285c2ec55193d3ca92',
 'LICENSE-CC-BY-4.0.txt': '9ba9550ad48438d0836ddab3da480b3b69ffa0aac7b7878b5a0039e7ab429411',
 'wine+quality.zip': '3ed56667f4b828242bd732d7d1dd7f2861e54432239d7fa63877014cbb0304d4'
}
HEADER = ['fixed acidity','volatile acidity','citric acid','residual sugar','chlorides','free sulfur dioxide','total sulfur dioxide','density','pH','sulphates','alcohol','quality']
def integer(n): return f'{n:,}'.replace(',', '.')
def number(n, digits=2): return f'{float(n):.{digits}f}'.replace('.', ',')
def pct(a,b): return D(a)*100/D(b)
def write_csv(path, columns, rows):
 with path.open('w', encoding='utf-8-sig', newline='') as f:
  w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
facts=[]; stats={}; all_records=[]; manifest=[]
def fact(metric, group, value, denominator='', unit='rows', note=''):
 facts.append(dict(metric=metric,source_file=group,value=str(value),denominator=str(denominator),unit=unit,note=note))
for filename,sha in EXPECTED.items():
 b=(ROOT/'source'/filename).read_bytes(); actual=hashlib.sha256(b).hexdigest()
 if actual!=sha: raise ValueError(f'Snapshot mismatch: {filename}')
 manifest.append(dict(file='source/'+filename,bytes=len(b),sha256=actual))
for kind in ['red','white']:
 filename=f'winequality-{kind}.csv'
 with (ROOT/'source'/filename).open(encoding='utf-8',newline='') as f:
  reader=csv.DictReader(f,delimiter=';'); assert reader.fieldnames==HEADER
  rows=list(reader)
 counter=collections.Counter(tuple(r[c] for c in HEADER) for r in rows)
 dist=collections.Counter(); missing=invalid=0; missing_fields=collections.Counter(); invalid_fields=collections.Counter()
 for idx,row in enumerate(rows,1):
  if None in row or any(row[c] is None for c in HEADER): raise ValueError(f'Malformed row {filename}:{idx}')
  for c in HEADER:
   if row[c].strip()=='': missing_fields[c]+=1
   else:
    try:
     if not D(row[c]).is_finite(): invalid_fields[c]+=1
    except decimal.InvalidOperation: invalid_fields[c]+=1
  raw=row['quality'].strip()
  if not raw: missing+=1;continue
  try:
   q=D(raw)
   if not q.is_finite() or q!=q.to_integral_value() or not 0<=q<=10: raise ValueError()
   dist[int(q)]+=1
  except (ValueError,decimal.InvalidOperation): invalid+=1
 n=len(rows); le5=sum(dist[q] for q in range(6)); extras=n-len(counter)
 s=dict(filename=filename,n=n,le5=le5,rate=pct(le5,n),dist=dist,missing=missing,invalid=invalid,unique=len(counter),extras=extras,clusters=sum(c>1 for c in counter.values()),in_clusters=sum(c for c in counter.values() if c>1),max_multiplicity=max(counter.values()),rows=rows)
 stats[kind]=s
 for m,v in [('source_rows',n),('quality_le5_rows',le5),('quality_missing_rows',missing),('quality_invalid_rows',invalid),('distinct_full_records',len(counter)),('duplicate_excess_rows',extras),('duplicate_groups',s['clusters']),('rows_in_duplicate_groups',s['in_clusters']),('max_duplicate_multiplicity',s['max_multiplicity'])]:fact(m,filename,v,n)
 fact('quality_le5_percent',filename,s['rate'],n,'percent','100 * quality_le5_rows / source_rows; no deduplication')
 fact('quality_5_or_6_rows',filename,dist[5]+dist[6],n)
 fact('quality_5_or_6_percent',filename,pct(dist[5]+dist[6],n),n,'percent')
 for q in range(11):
  fact(f'quality_{q}_rows',filename,dist[q],n)
  fact(f'quality_{q}_percent',filename,pct(dist[q],n),n,'percent')
 for c in HEADER:
  fact('missing_field_'+c,filename,missing_fields[c],n)
  fact('nonnumeric_or_nonfinite_field_'+c,filename,invalid_fields[c],n)
 assert sum(dist.values())+missing+invalid==n
 assert le5+sum(dist[q] for q in range(6,11))+missing+invalid==n
 for idx,row in enumerate(rows[:20],1):
  all_records.append(dict(source_file=filename,source_data_row=idx,record_id=f'{filename}+{idx}',proposed_assignment_slot='A (proposed; unassigned)' if kind=='red' else 'B (proposed; unassigned)',review_status='HOLD',**row))
r,w=stats['red'],stats['white']; diff=r['rate']-w['rate']
fact('red_minus_white_quality_le5_pp','red - white',diff,'','percentage_points','difference of two original-file rates; no population inference')
fact('planned_records','proposed desktop check',40,'','records','20 first data rows per file; convenience selection')
fact('planned_people','proposed desktop check',2,'','people','unassigned proposed roles; availability unknown')
fact('planned_records_per_file','proposed desktop check',20,'','records','first data rows')
fact('planned_records_per_person','proposed desktop check',20,'','records','proposed allocation')
fact('planned_minutes_per_record','proposed desktop check',3,'','person_minutes','assumption')
fact('planned_total_person_minutes','proposed desktop check',120,'','person_minutes','40 * 3')
fact('planned_parallel_elapsed_minutes','proposed desktop check',60,'','minutes','only with 2 actually available people, 20 records each, at assumed pace')
write_csv(ROOT/'facts.csv',['metric','source_file','value','denominator','unit','note'],facts)
write_csv(ROOT/'review-40-records.csv',list(all_records[0]),all_records)
blank=dict(record_id='',source_file='',source_data_row='',source_snapshot_sha256='',raw_value='',source_snapshot_confirmed='unknown',provenance_confirmed='unknown',scope='',scope_confirmed='unknown',assigned_person='',person_available='unknown',authority_reference='',authority_confirmed='unknown',status='HOLD',reason='not done',next_action='',reviewer='',reviewed_at='',actual_minutes='',outcome='not done')
write_csv(ROOT/'work-record-blank.csv',list(blank),[blank])
(ROOT/'source-manifest.json').write_text(json.dumps(dict(snapshot_acquired_utc='2026-10-15; supplied provenance',files=manifest,derived_analysis='Original CSV bytes unchanged; parsing and report are derived work.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rate_chart(mobile=False):
 width=320 if mobile else 900; height=310 if mobile else 300
 x0=4 if mobile else 120; x1=316 if mobile else 830; plot=x1-x0
 ys=[75,215] if mobile else [85,190]
 prefix='rate-mobile' if mobile else 'rate-desktop'
 out=[f'<svg class="chart {"mobile-chart" if mobile else "desktop-chart"}" viewBox="0 0 {width} {height}" role="img" aria-labelledby="{prefix}-title {prefix}-desc"><title id="{prefix}-title">Tỷ lệ dòng có quality ≤ 5 theo tệp gốc</title><desc id="{prefix}-desc">Đỏ {number(r["rate"])} phần trăm, trắng {number(w["rate"])} phần trăm. Chênh {number(diff)} điểm phần trăm. Cùng thang từ 0 đến 100 phần trăm; giữ dòng trùng. Đây là ngưỡng giả định.</desc>']
 for value in [0,25,50,75,100]:
  x=x0+plot*value/100
  out.append(f'<line x1="{x}" y1="{ys[0]}" x2="{x}" y2="{ys[1]+30}" stroke="#d6d8d1"/>')
  anchor='start' if value==0 else 'end' if value==100 else 'middle'
  out.append(f'<text x="{x}" y="{height-9}" text-anchor="{anchor}" font-size="{16 if mobile else 18}" fill="#4d5752">{value}%</text>')
 for s,y,color,label in [(r,ys[0],'#8c3048','Đỏ'),(w,ys[1],'#28675d','Trắng')]:
  bw=plot*float(s['rate'])/100
  out.append(f'<rect x="{x0}" y="{y}" width="{plot}" height="30" fill="#eeeee8"/><rect x="{x0}" y="{y}" width="{bw}" height="30" fill="{color}"/>')
  if mobile:
   out.append(f'<text x="4" y="{y-33}" font-size="19" fill="#202923" font-weight="700">{label}</text><text x="316" y="{y-33}" text-anchor="end" font-size="24" font-weight="700" fill="{color}">{number(s["rate"])}%</text><text x="4" y="{y+57}" font-size="17" fill="#4d5752">{integer(s["le5"])} / {integer(s["n"])} dòng gốc</text>')
  else:
   out.append(f'<text x="4" y="{y+22}" font-size="22" font-weight="700" fill="#202923">{label}</text><text x="{x0+bw+15}" y="{y+24}" font-size="26" font-weight="700" fill="{color}">{number(s["rate"])}%</text><text x="{x0}" y="{y+59}" font-size="19" fill="#4d5752">{integer(s["le5"])} / {integer(s["n"])} dòng gốc</text>')
 out.append('</svg>');return ''.join(out)
dist_rows=[]
for q in range(11):
 cells=[]
 for kind,s,color in [('red',r,'#8c3048'),('white',w,'#28675d')]:
  p=pct(s['dist'][q],s['n'])
  cells.append(f'<td><div class="dist-value"><b>{integer(s["dist"][q])}</b><span>{number(p)}%</span></div><svg viewBox="0 0 200 8" class="spark" aria-hidden="true"><rect width="200" height="8" fill="#e9eae3"/><rect width="{float(p)*4:.5f}" height="8" fill="{color}"/></svg></td>')
 dist_rows.append(f'<tr class="{"threshold" if q==5 else ""}"><th scope="row">{q}{"<small>ngưỡng</small>" if q==5 else ""}</th>{"".join(cells)}</tr>')
summary_rows=[]
for s,label in [(r,'Đỏ'),(w,'Trắng')]:
 summary_rows.append(f'<tr><th scope="row">{label}<small>{s["filename"]}</small></th><td>{integer(s["n"])}</td><td>{integer(s["le5"])}</td><td>{number(s["rate"])}%</td></tr>')
vars=dict(diff=number(diff),red_rate=number(r['rate']),white_rate=number(w['rate']),red_n=integer(r['n']),white_n=integer(w['n']),red_le5=integer(r['le5']),white_le5=integer(w['le5']),rate_charts=rate_chart()+rate_chart(True),dist_rows=''.join(dist_rows),summary_rows=''.join(summary_rows),red_unique=integer(r['unique']),white_unique=integer(w['unique']),red_extra=integer(r['extras']),white_extra=integer(w['extras']),red_clusters=integer(r['clusters']),white_clusters=integer(w['clusters']),red_in_clusters=integer(r['in_clusters']),white_in_clusters=integer(w['in_clusters']),red_max=str(r['max_multiplicity']),white_max=str(w['max_multiplicity']),red_56=number(pct(r['dist'][5]+r['dist'][6],r['n'])),white_56=number(pct(w['dist'][5]+w['dist'][6],w['n'])))
template=(ROOT/'report.template.html').read_text(encoding='utf-8')
for key,value in vars.items():template=template.replace('{{'+key+'}}',value)
assert '{{' not in template
(ROOT/'report.html').write_text(template,encoding='utf-8')
# Keep an original source-row example separate from the genuinely blank new record.
example=dict(blank,record_id='winequality-red.csv+1',source_file='winequality-red.csv',source_data_row='1',raw_value=r['rows'][0]['quality'],source_snapshot_sha256=EXPECTED['winequality-red.csv'],scope='Kiểm tra hồ sơ trên máy tính; nhập dữ liệu và xuất xứ',reason='Ví dụ minh họa: chưa xác nhận nguồn, phạm vi, người, sự sẵn sàng hoặc quyền.',next_action='Người phụ trách dữ liệu được đề xuất xác nhận các điều kiện trước khi chuyển hồ sơ đi duyệt.')
write_csv(ROOT/'work-record-example.csv',list(blank),[example])
print(json.dumps(dict(rows={k:s['n'] for k,s in stats.items()},le5={k:s['le5'] for k,s in stats.items()},rates={k:str(s['rate']) for k,s in stats.items()},difference_pp=str(diff),duplicates={k:s['extras'] for k,s in stats.items()},quality_missing={k:s['missing'] for k,s in stats.items()},quality_invalid={k:s['invalid'] for k,s in stats.items()},all_field_missing=sum(int(x['value']) for x in facts if x['metric'].startswith('missing_field_')),all_field_nonnumeric=sum(int(x['value']) for x in facts if x['metric'].startswith('nonnumeric_or_nonfinite_field_')),selected_records=len(all_records)),indent=2))



