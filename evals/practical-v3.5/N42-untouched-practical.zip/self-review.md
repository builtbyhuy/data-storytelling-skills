# Biên bản tự kiểm tra · N42

- Bắt đầu công việc: **2026-10-15 04:30:18 UTC** (11:30:18, Asia/Bangkok).
- Kết thúc thực hiện và chốt bàn giao: **2026-10-15 04:42:27 UTC** (11:42:27, Asia/Bangkok).
- Thời lượng đến mốc chốt: 12 phút 9 giây; trong giới hạn 25 phút. Thời hạn được ghi từ đầu là 04:55:18 UTC.
- Trạng thái: bản hoàn chỉnh đầu tiên, **FINAL**, không sửa sau tuyên bố FINAL. Số lần sửa bởi người điều phối/chủ sở hữu: **0**. Các tự sửa trước FINAL là của chính tác giả.
- Không biết định danh model chính xác hoặc tham số sampling; không suy luận hay điền thay.

## Phạm vi phương pháp và đầu vào

Đọc cả sáu SKILL.md trong bundle baseline 3.3 được giao: data-storytelling, business-insight-diagnosis, evidence-to-narrative, business-chart-communication, data-story-redteam và analytics-adoption. Áp dụng các tham chiếu liên quan về evidence contract, decision workflow, chart method, visual delivery, story/audience, practice/learning, integrity checks và browser export. Không thay bằng phương pháp khác.

Chỉ sử dụng ba brief/runtime chung, SOURCE.md được cung cấp, dữ liệu gốc được cho phép, hướng dẫn vận hành workspace và runtime đã khai báo. Không web, CUA, dịch vụ ngoài, cài gói, cấu hình chung, agent con, thông điệp ngang hàng, lần chạy khác hoặc tài liệu riêng/evaluator. Đây là việc cá nhân, không có đánh giá người đọc thật.

## Những gì đã đối chiếu

1. **Nguồn và hạt đếm.** Kiểm tra SHA-256 tất cả năm tài nguyên gốc trước dựng; đối chiếu độc lập hai CSV giữ lại với bản đầu vào gốc. Tệp đỏ 1.599 dòng dữ liệu; trắng 4.898. Không tính tiêu đề, không loại dòng trùng, không gộp mẫu số. Nguồn không có mã chai duy nhất.
2. **Phép tính chính.** Đối chiếu riêng bằng PowerShell đọc CSV và chuỗi dòng nguồn, không dùng kết quả Python làm đầu vào tính lại: đỏ 744/1.599 = 46,5290806754…%; trắng 1.640/4.898 = 33,4830543079…%; đỏ trừ trắng = 13,0460263675… điểm phần trăm. Hiển thị 46,53%, 33,48%, 13,05 điểm phần trăm nhất quán giữa lập luận, biểu đồ và bảng.
3. **Phân bố và thiếu dữ liệu.** Đếm độc lập mọi mức 0–10 và đối chiếu tổng về số dòng gốc. Không có quality thiếu/không hợp lệ, không có ô trống hoặc giá trị không phải số/hữu hạn trong 12 trường. Không suy điều này thành xác nhận phép đo đúng. Giữ các mức không có quan sát là 0. Đưa bằng chứng phân bố chồng lấn bên cạnh diễn giải; không chọn nhóm thắng chung hoặc suy nhân quả.
4. **Trùng bản ghi.** So sánh toàn bộ 12 giá trị trong từng tệp; kiểm tra riêng bằng chuỗi dòng nguồn. Đỏ 240 dòng lặp thêm, 220 nhóm trùng, 1.359 tổ hợp khác nhau; trắng 937 dòng lặp thêm, 772 nhóm, 3.961 tổ hợp. Giữ nguyên mọi dòng trong tỷ lệ. Không kết luận lỗi nhập liệu hoặc trùng chai.
5. **Danh sách và kế hoạch.** Kiểm tra đúng 20 vị trí đầu mỗi tệp, 40 định danh khác nhau; cả 12 trường khớp nguồn. Mọi hồ sơ HOLD; A/B chỉ là vị trí đề xuất, không phải người thật được giao. 40 × 3 = 120 phút công; 20 × 3 = 60 phút mỗi người, chỉ thành khoảng một giờ trôi qua khi hai người thực sự sẵn sàng làm song song. Thẩm quyền và việc thực hiện chưa có.
6. **Phiếu mới.** Kiểm tra bản CSV trống và thao tác HTML ở 1280/390 px: điền một định danh nguồn, giữ raw_value trống, reason=unknown, outcome=not done, status=HOLD; tải JSON rồi đọc lại. Giá trị trống, unknown và not done được giữ riêng. Không tạo tài khoản, người thực hiện, phê duyệt hoặc kết quả thực tế. Phiếu có hướng dẫn kiểm tra thủ công; không tự xác minh điều kiện hay tự cho phép bắt đầu.
7. **Dựng lại độc lập vị trí.** Chạy nguyên công thức `python -B build.py` trong thư mục kiểm tra riêng chỉ có các đầu vào và mã/mẫu được giữ. Trong phiên thử, tên python cục bộ chuyển tiếp tới bộ khởi chạy Python đã khai báo, không đổi PATH/cấu hình chung. Sáu đầu ra (HTML, facts, manifest, danh sách 40, phiếu trống, ví dụ) khớp SHA-256 với bản bàn giao. Xóa thư mục kiểm tra tái tạo sau đối chiếu; biên nhận còn tại qa/rebuild-check.json.

Biên nhận đối chiếu độc lập gồm 107 điều kiểm tra đã chạy tại `qa/independent-checks.json`. Số điều kiểm tra chỉ là phạm vi kỹ thuật, không phải điểm chất lượng hay kết quả người dùng.

## Hiển thị và tự sửa

Dùng Chrome 155 headless có sẵn; mở HTML gốc qua file cục bộ và chặn HTTP(S). Kiểm tra báo cáo ở **1280, 960, 390 và 320 CSS px**; phiếu ở 1280 và 390 px. Thực sự xem ảnh render đầy trang và các vùng kết luận, phép so sánh, phân bố, hồ sơ trùng, bước tiếp theo, nguồn/cách tính và phiếu mới. Các ảnh đọc chính được xem riêng ở kích thước thực tế, không chỉ ảnh dài bị thu nhỏ.

Những sửa đổi do chính tác giả trước FINAL:

- Tăng khoảng cách nhãn mẫu số và nhãn trục desktop.
- Tăng cỡ chữ tiêu đề bảng mobile, tách liên kết giao việc thành từng dòng.
- Ghi rõ tệp trắng trong câu so sánh mở đầu.
- Đệm nhãn SVG sát mép và thêm khoảng cách giữa hai nhóm trên điện thoại nhỏ; nâng cỡ chữ SVG ở 320 px.
- Giữ lệnh dựng lại trên một dòng đọc được khi mở phần phương pháp.

Sau sửa: không tràn ngang tài liệu ở bốn độ rộng; không lỗi trang hoặc yêu cầu mạng; không liên kết cục bộ thiếu; không ID trùng; không nhãn SVG tràn khung hoặc đè nhau trong phạm vi đo. Độ dài thanh khớp tỷ lệ tính độc lập từ CSV, cùng gốc 0 và thang 0–100%. Kiểm tra tên biểu đồ được trình duyệt công bố, phím Tab đầu tiên vào liên kết bỏ qua, và phần cách tính mở được trên mobile. Các cặp màu văn bản/đồ thị được đo đều qua ngưỡng tương phản tương ứng; tỷ số nhỏ nhất trong tập màu kiểm tra là 5,491…:1. Nhãn trục nhỏ nhất có kích thước nhìn thấy khoảng 15,8 px ở 960/390 px, và 16,14 px ở 320 px; số liệu chính lớn hơn.

Biên nhận: `qa/browser-checks.json`, `qa/surface-checks.json` và ảnh PNG. SVG giữ chữ chỉnh sửa được; bảng số liệu đầy đủ không phụ thuộc màu. Không dùng ảnh raster thay biểu đồ trong báo cáo.

## Giới hạn còn lại và trạng thái sử dụng

- Đây là tự kiểm tra của tác giả, không phải bằng chứng người dùng hiểu đúng, tốc độ đọc, sự hài lòng, phê duyệt hay lợi ích thực tế.
- Mới kiểm tra Chrome headless và mô phỏng độ rộng; chưa thử thiết bị vật lý, trình duyệt khác hoặc trình đọc màn hình. Kiểm tra ARIA/contrast không xác nhận toàn bộ WCAG.
- Không có PDF được yêu cầu hoặc giao; bố cục in/nhấn nút in chưa được kiểm tra như một đầu ra riêng.
- Phiếu ghi việc lưu thủ công bằng tải JSON hoặc bản CSV. Không tự lưu, không nhập lại JSON, không tự kiểm chứng bằng chứng và không tự tính trạng thái. Kiểm tra thủ công là trách nhiệm người nhận; READY FOR REVIEW không cấp quyền bắt đầu.
- Dựng lại cần Python 3 cục bộ có thể chạy; không có trình cài trong gói. Chỉ thư viện chuẩn, không tải mạng hoặc cần đường dẫn cá nhân trong mã dựng.
- Dữ liệu là lịch sử; không có thiết kế mẫu đủ để suy rộng, không có thời gian từng quan sát, mã chai duy nhất, lô, thương hiệu, giá hoặc chi phí. Không có kiểm tra hồ sơ thực tế, thử nếm, phân tích nguyên nhân hoặc kết quả kinh doanh đã diễn ra.

## Điểm vào và dấu nhận dạng bản hoàn chỉnh

- Điểm vào: `practical/report.html`.
- Từ thư mục `practical`, lệnh dựng lại giữ nguyên: **`python -B build.py`**.
- SHA-256 report.html: `ac84c5ca156a2bc4c2594b25adb1f582ed525b8cbe9f8af5baaede4db038980c`.
- Tệp HTML, facts, nguồn nguyên byte, xuất xứ/giấy phép, mã/mẫu dựng lại, danh sách 40, phiếu mới và hướng dẫn đều đã tồn tại. Không chờ người điều phối sửa.

