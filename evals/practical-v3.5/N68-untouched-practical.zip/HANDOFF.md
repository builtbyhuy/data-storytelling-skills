# Bàn giao kiểm tra hồ sơ — HOLD

Đây là đề xuất chuẩn bị, chưa phải giao việc thực tế. Chưa có người hoặc phê duyệt thật. Chưa kiểm tra hồ sơ nào.

1. Mở report.html, đọc kết quả với giới hạn. Không dùng ngưỡng <=5 như tiêu chuẩn lỗi hoặc quyết định mua/bán.
2. Đối chiếu SOURCE.md, snapshot.json và SHA-256 trước khi dùng danh sách. Xác nhận xuất xứ và phạm vi kiểm tra dữ liệu nhập/hồ sơ trên máy tính.
3. review-list.csv lấy 20 dòng đầu mỗi tệp; không phải mẫu ngẫu nhiên, đại diện hoặc phép đo hiệu quả. Giữ source_file + source_data_row. Dòng đầu dữ liệu là 1 sau tiêu đề.
4. Kế hoạch giả định: 2 người thật, mỗi người 20 hồ sơ; 3 phút/hồ sơ. Tổng 120 phút công. Khoảng 1 giờ trôi qua chỉ khi cả hai sẵn sàng làm đồng thời. Vai trò A/B chỉ là nhãn đề xuất, chưa gán người.
5. Mở work-record.html, điền một hồ sơ, một người được giao, bằng chứng xác nhận nguồn/xuất xứ/phạm vi, sự sẵn sàng, quyền thực hiện, trạng thái, lý do và hành động tiếp. Giữ trống, unknown, not done nguyên trạng khi chưa xác nhận. Không coi chúng là false, 0 hay hoàn tất.
6. Kiểm tra thủ công: thiếu hoặc chưa xác nhận bất kỳ điều kiện nào -> HOLD. Đủ điều kiện trên hồ sơ -> chỉ READY FOR REVIEW. READY FOR REVIEW chưa cho phép bắt đầu; người có trách nhiệm vẫn phải xem xét và có quyền thực hiện phù hợp.
7. Tải JSON hoặc in để lưu; biểu mẫu không tự lưu và không gửi đi. Đặt bản ghi thực tế ở tên riêng để tránh bị dựng lại ghi đè template. Không ghi đã kiểm tra khi chưa làm.

Nếu phát hiện trùng, ghi nhận và truy nguồn; không tự xóa. Không có mã mẫu/chai duy nhất để xác nhận trùng là lỗi nhập liệu.
