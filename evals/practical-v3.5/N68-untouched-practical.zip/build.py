#!/usr/bin/env python3
"""Python 3.12+; standard library only; no network or source edits."""
from pathlib import Path
from collections import Counter
from decimal import Decimal, InvalidOperation
import csv, hashlib, html, json, sys
ROOT=Path(__file__).resolve().parent
HEADER=['fixed acidity','volatile acidity','citric acid','residual sugar','chlorides','free sulfur dioxide','total sulfur dioxide','density','pH','sulphates','alcohol','quality']
EXPECTED={'winequality-red.csv':'4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e','winequality-white.csv':'76c3f809815c17c07212622f776311faeb31e87610d52c26d87d6e361b169836','winequality.names':'15d215e73b39105952380fd487e4ce1bf5a6b83a425abb285c2ec55193d3ca92','LICENSE-CC-BY-4.0.txt':'9ba9550ad48438d0836ddab3da480b3b69ffa0aac7b7878b5a0039e7ab429411'}
def fmt(v,digits=2):
    if digits==0:return f'{v:,}'.replace(',','.')
    return f'{v:,.{digits}f}'.replace(',','_').replace('.',',').replace('_','.')
snapshot=[]
for name,expected in EXPECTED.items():
    raw=(ROOT/'source'/name).read_bytes();digest=hashlib.sha256(raw).hexdigest()
    if digest!=expected:raise ValueError('Source snapshot mismatch: '+name)
    snapshot.append(dict(file=name,bytes=len(raw),sha256=digest))
data={}
for key,label,name in [('red','Rượu đỏ','winequality-red.csv'),('white','Rượu trắng','winequality-white.csv')]:
    with (ROOT/'source'/name).open(encoding='utf-8',newline='') as f:
        reader=csv.reader(f,delimiter=';');header=next(reader);rows=list(reader)
    if header!=HEADER:raise ValueError('Unexpected schema: '+name)
    missing=invalid=bad_width=other_missing=other_invalid=0;scores=Counter()
    for row in rows:
        if len(row)!=12:bad_width+=1;invalid+=1;continue
        for value in row[:-1]:
            if not value.strip():other_missing+=1
            else:
                try:
                    if not Decimal(value).is_finite():other_invalid+=1
                except InvalidOperation:other_invalid+=1
        if not row[-1].strip():missing+=1;continue
        try:
            q=Decimal(row[-1])
            if not q.is_finite() or q!=q.to_integral_value() or not 0<=q<=10:invalid+=1;continue
            scores[int(q)]+=1
        except InvalidOperation:invalid+=1
    n=len(rows);freq=Counter(tuple(row) for row in rows);below=sum(v for q,v in scores.items() if q<=5)
    d=dict(key=key,label=label,file=name,rows=rows,n=n,scores=scores,below=below,rate=100*below/n,missing=missing,invalid=invalid,bad_width=bad_width,other_missing=other_missing,other_invalid=other_invalid,unique=len(freq),duplicate_excess=sum(v-1 for v in freq.values()),duplicate_groups=sum(v>1 for v in freq.values()),duplicate_members=sum(v for v in freq.values() if v>1))
    assert sum(scores.values())+missing+invalid==n
    assert d['unique']+d['duplicate_excess']==n
    data[key]=d
r,w=data.values();gap=r['rate']-w['rate'];facts=[]
def fact(metric,key,value,denominator='',unit='rows',definition=''):
    facts.append(dict(metric=metric,source_file=data[key]['file'] if key in data else '',group=data[key]['label'] if key in data else key,value=value,denominator=denominator,unit=unit,definition=definition))
for key,d in data.items():
    for k in ['n','below','missing','invalid','bad_width','other_missing','other_invalid','unique','duplicate_excess','duplicate_groups','duplicate_members']:
        fact(k,key,d[k],d['n'],unit='cells' if k in ['other_missing','other_invalid'] else 'groups' if k=='duplicate_groups' else 'records' if k=='unique' else 'rows',definition={'n':'All original data records after header; duplicates retained','below':'Valid integer quality <= 5','duplicate_excess':'Occurrences after first identical 12-field parsed record','duplicate_groups':'Distinct parsed records occurring >= 2 times','duplicate_members':'All rows in repeated groups','other_missing':'Missing cells across 11 physicochemical fields; denominator is original rows','other_invalid':'Non-finite or non-numeric cells across 11 physicochemical fields; denominator is original rows'}.get(k,k))
    fact('quality_le_5_percent',key,d['rate'],d['n'],'percent','100 * below / n; original denominator')
    for q in range(11):
        fact(f'quality_{q}_count',key,d['scores'][q],d['n'])
        fact(f'quality_{q}_percent',key,100*d['scores'][q]/d['n'],d['n'],'percent')
    for suffix,points in [('le_4',range(5)),('ge_7',range(7,11))]:
        count=sum(d['scores'][q] for q in points)
        fact('quality_'+suffix+'_count',key,count,d['n']);fact('quality_'+suffix+'_percent',key,100*count/d['n'],d['n'],'percent')
fact('red_minus_white_le_5_percentage_points','comparison',gap,'','percentage_points','100 * (744/1599 - 1640/4898); not relative percent change')
for metric,value,unit,definition in [('routing_threshold',5,'ordered_score','Hypothetical exercise rule; not defect standard'),('quality_scale_min',0,'ordered_score','Source dictionary'),('quality_scale_max',10,'ordered_score','Source dictionary'),('physicochemical_columns',11,'columns','Source schema'),('total_source_columns',12,'columns','11 inputs plus quality'),('minimum_expert_evaluations',3,'evaluations','Source dictionary: median of at least three expert evaluations'),('dataset_publication_year',2009,'year','Dataset citation'),('snapshot_acquired_utc','2026-10-15','date','Supplied SOURCE.md; not sample collection date')]:fact(metric,'source_metadata',value,'',unit,definition)
for s in snapshot:facts.append(dict(metric='source_bytes',source_file=s['file'],group='retained_source',value=s['bytes'],denominator='',unit='bytes',definition='Original retained bytes; SHA-256 in snapshot.json'))
for metric,value,unit in [('planned_records',40,'records'),('planned_records_per_file',20,'records'),('planned_people',2,'people'),('planned_records_per_person',20,'records'),('assumed_minutes_per_record',3,'minutes'),('total_person_minutes',120,'person_minutes'),('conditional_elapsed_minutes',60,'minutes')]:fact(metric,'hypothetical_plan',value,'',unit,'HOLD; elapsed requires two available people working concurrently at assumed speed')
with (ROOT/'facts.csv').open('w',encoding='utf-8-sig',newline='') as f:
    out=csv.DictWriter(f,fieldnames=['metric','source_file','group','value','denominator','unit','definition']);out.writeheader();out.writerows(facts)
with (ROOT/'review-list.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['source_file','source_data_row']+HEADER+['draft_lane','assigned_person','status','source_snapshot_confirmation','provenance_confirmation','scope_confirmation','person_ready','permission_confirmation','reason','next_action']
    out=csv.DictWriter(f,fieldnames=fields);out.writeheader()
    for key,d in data.items():
        if len(d['rows'])<20 or d['bad_width']:raise ValueError('Cannot prepare list')
        for i,row in enumerate(d['rows'][:20],1):
            out.writerow(dict(source_file=d['file'],source_data_row=i,**dict(zip(HEADER,row)),draft_lane='A (unassigned)' if key=='red' else 'B (unassigned)',assigned_person='',status='HOLD',source_snapshot_confirmation='unknown',provenance_confirmation='unknown',scope_confirmation='unknown',person_ready='unknown',permission_confirmation='unknown',reason='not done',next_action='Confirm source, provenance, scope, real assignee readiness and permission'))
manifest=dict(snapshot_acquired_utc='2026-10-15',dataset='Wine Quality; UCI; Cortez et al. (2009)',doi='https://doi.org/10.24432/C56S3T',license='CC BY 4.0',files=snapshot,source_unchanged=True,analysis='Derived counts and presentation; no source edits; no deduplication',grain='One original data record; not a unique bottle or person')
(ROOT/'snapshot.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
panels=''
for key,d in data.items():
    panels+=f'''<div class="rate-panel {key}"><p class="group-label"><span class="swatch" aria-hidden="true"></span>{d['label']}</p><div class="rate">{fmt(d['rate'])}<span>%</span></div><p class="ratio"><b>{fmt(d['below'],0)}</b> dòng ≤ 5 / <b>{fmt(d['n'],0)}</b> dòng gốc</p><div class="ratebar" role="img" aria-label="{d['label']}: {fmt(d['rate'])}% dòng có quality không quá 5, trên thang tỷ lệ 0 đến 100%"><i style="width:{d['rate']:.8f}%"></i></div><div class="axis" aria-hidden="true"><span>0%</span><span>100%</span></div></div>'''
dist='';table=''
for q in range(11):
    tracks=''
    for key,d in data.items():
        n=d['scores'][q];p=100*n/d['n']
        tracks+=f'''<div class="track {key}"><div class="track-bar" aria-hidden="true"><i style="width:{p*2:.8f}%"></i></div><div class="track-value"><span class="sr">{d['label']}: </span><b>{fmt(p)}%</b> · {fmt(n,0)}</div></div>'''
    dist+=f'<div class="score"><div class="score-number">{q}</div><div class="tracks">{tracks}</div></div>'
    table+=f'<tr><th scope="row">{q}</th><td>{fmt(r["scores"][q],0)}</td><td>{fmt(100*r["scores"][q]/r["n"])}%</td><td>{fmt(w["scores"][q],0)}</td><td>{fmt(100*w["scores"][q]/w["n"])}%</td></tr>'
dup=''.join(f'<tr><th scope="row">{d["label"]}</th><td>{fmt(d["n"],0)}</td><td>{fmt(d["unique"],0)}</td><td>{fmt(d["duplicate_groups"],0)}</td><td>{fmt(d["duplicate_members"],0)}</td><td>{fmt(d["duplicate_excess"],0)}</td></tr>' for d in data.values())
hashes=''.join(f'<p><b>{s["file"]}</b> · {fmt(s["bytes"],0)} byte<br><code>{s["sha256"]}</code></p>' for s in snapshot)
def mini_bars(points):
    bars='';labels=[]
    for key,d in data.items():
        value=100*sum(d['scores'][q] for q in points)/d['n']
        labels.append(d['label']+': '+fmt(value)+'%')
        bars+=f'<div class="mini-track {key}"><span>{"Đỏ" if key=="red" else "Trắng"}</span><div class="plot" aria-hidden="true"><i style="width:{value*4:.8f}%"></i></div><b>{fmt(value)}%</b></div>'
    return '<div class="mini-chart" role="img" aria-label="'+html.escape('; '.join(labels),quote=True)+'; cùng thang 0 đến 25%">'+bars+'</div>'
values={'CSS':(ROOT/'style.css').read_text(encoding='utf-8'),'GAP':fmt(gap),'PANELS':panels,'DIST':dist,'TABLE':table,'DUP':dup,'HASHES':hashes,'LOW_BARS':mini_bars(range(5)),'HIGH_BARS':mini_bars(range(7,11))}
report=(ROOT/'report.template.html').read_text(encoding='utf-8')
for key,value in values.items():report=report.replace('{{'+key+'}}',value)
assert '{{' not in report
(ROOT/'report.html').write_text(report,encoding='utf-8')
form=(ROOT/'work-record.template.html').read_text(encoding='utf-8').replace('{{CSS}}',values['CSS'])
(ROOT/'work-record.html').write_text(form,encoding='utf-8')
fields=dict(source_file='',source_data_row='',source_snapshot_confirmation='unknown',provenance_confirmation='unknown',scope_confirmation='unknown',assigned_person='',person_readiness='unknown',permission_confirmation='unknown',status='HOLD',reason='not done',next_action='',evidence_or_note='')
(ROOT/'work-record-template.json').write_text(json.dumps(fields,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
checks=dict(python=sys.version.split()[0],source_hashes_verified=True,headers_verified=True,per_file={},review_list_records=40,source_writes=0,owner_edits=0,gap_percentage_points=gap)
for d in data.values():
    checks['per_file'][d['file']]={k:d[k] for k in ['n','below','rate','missing','invalid','bad_width','other_missing','other_invalid','unique','duplicate_excess','duplicate_groups','duplicate_members']}
    checks['per_file'][d['file']]['distribution_ties_to_n']=sum(d['scores'].values())+d['missing']+d['invalid']==d['n']
    checks['per_file'][d['file']]['duplicate_identity_ties']=d['unique']+d['duplicate_excess']==d['n']
(ROOT/'calculation-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'built','red_percent':r['rate'],'white_percent':w['rate'],'gap_pp':gap,'source_hashes':'verified'},ensure_ascii=False))
