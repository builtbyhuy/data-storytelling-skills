import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const root=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(root,'verification');await fs.mkdir(out,{recursive:true});
const require=createRequire(path.join(process.argv[2],'package.json'));
const {chromium}=require('playwright');
const browser=await chromium.launch({headless:true,executablePath:process.argv[3]});
const receipt={renderer:'Existing headless Chrome via Playwright',views:[],errors:[],networkRequests:[],form:{},limits:['Author browser inspection, not a real mobile device, screen-reader execution or user comprehension study.']};
try{
for(const width of [1280,390]){
 const context=await browser.newContext({viewport:{width,height:900},deviceScaleFactor:1,colorScheme:'light'});
 const page=await context.newPage();page.on('pageerror',e=>receipt.errors.push(e.message));
 await page.route(/^https?:\/\//,async route=>{receipt.networkRequests.push(route.request().url());await route.abort()});
 await page.goto(pathToFileURL(path.join(root,'report.html')).href);await page.evaluate(()=>document.fonts.ready);
 await page.screenshot({path:path.join(out,`report-${width}-top.png`)});
 for(const [selector,name]of [['#phan-bo','distribution'],['#ho-so','plan'],['#nguon','source']]){
   await page.locator(selector).screenshot({path:path.join(out,`report-${width}-${name}.png`)});
 }
 const measure=()=>({width:innerWidth,documentWidth:document.documentElement.scrollWidth,bodyFont:getComputedStyle(document.body).fontSize,
   clipped:[...document.querySelectorAll('h1,h2,h3,p,figcaption,summary,.track-value,.ratio')].filter(e=>{const r=e.getBoundingClientRect();return r.width&&r.height&&(r.left<0||r.right>innerWidth+1)}).map(e=>e.textContent.slice(0,100)),
   duplicateIds:[...document.querySelectorAll('[id]')].map(e=>e.id).filter((id,i,all)=>all.indexOf(id)!==i),
   chartsWithNames:[...document.querySelectorAll('[role=img]')].every(e=>!!e.getAttribute('aria-label')),
   localLinks:[...document.querySelectorAll('a[href]')].map(e=>e.getAttribute('href')).filter(h=>!h.startsWith('http')&&!h.startsWith('#')),
   visibleText:document.body.innerText.length});
 receipt.views.push({page:'report',scheme:'light',...await page.evaluate(measure)});
 for(const selector of ['#phan-bo','#ho-so','#nguon']){
   await page.locator(selector).scrollIntoViewIfNeeded();
   await page.evaluate(s=>{const e=document.querySelector(s);window.scrollTo({top:scrollY+e.getBoundingClientRect().top-85,behavior:'instant'})},selector);
   await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
   await page.screenshot({path:path.join(out,`viewport-${width}-${selector.slice(1)}.png`)});
 }
 await page.locator('details').evaluateAll(all=>all.forEach(e=>e.open=true));
 await page.locator('#phan-bo').screenshot({path:path.join(out,`report-${width}-table-open.png`)});
 receipt.views.push({page:'report-details-open',scheme:'light',...await page.evaluate(measure)});
 await page.emulateMedia({colorScheme:'dark'});await page.goto(pathToFileURL(path.join(root,'report.html')).href);
 await page.screenshot({path:path.join(out,`report-${width}-dark-top.png`)});
 receipt.views.push({page:'report',scheme:'dark',...await page.evaluate(measure)});
 const contrast=await page.evaluate(()=>{
   const s=getComputedStyle(document.documentElement),names=['--text','--text-dim','--accent','--warn','--info'];
   const luminance=hex=>{const parts=hex.trim().replace('#','');const expanded=parts.length===3?[...parts].map(c=>c+c).join(''):parts;const c=[0,2,4].map(i=>parseInt(expanded.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4);return .2126*c[0]+.7152*c[1]+.0722*c[2]};
   return names.flatMap(name=>['--bg','--surface'].map(bg=>{const a=luminance(s.getPropertyValue(name)),b=luminance(s.getPropertyValue(bg));return {color:name,background:bg,ratio:Number(((Math.max(a,b)+.05)/(Math.min(a,b)+.05)).toFixed(2))}}));
 });
 receipt.views.at(-1).tokenContrast=contrast;if(contrast.some(c=>c.ratio<4.5))receipt.errors.push('Dark scheme token text contrast below 4.5');
 await page.emulateMedia({colorScheme:'light'});await page.goto(pathToFileURL(path.join(root,'work-record.html')).href);
 await page.screenshot({path:path.join(out,`form-${width}-top.png`)});
 await page.screenshot({path:path.join(out,`form-${width}-full.png`),fullPage:true});
 receipt.views.push({page:'form',scheme:'light',...await page.evaluate(measure)});
 if(width===390){
   const initial=await page.locator('form').evaluate(f=>Object.fromEntries(new FormData(f)));
   await page.locator('[name=source_file]').fill('winequality-red.csv');await page.locator('[name=source_data_row]').fill('1');
   await page.locator('[name=reason]').fill('not done');await page.locator('[name=evidence_or_note]').fill('unknown; ô trống giữ nguyên');
   const downloadPromise=page.waitForEvent('download');await page.locator('#download').click();const download=await downloadPromise;
   const target=path.join(out,'form-test-download.json');await download.saveAs(target);const downloaded=JSON.parse(await fs.readFile(target,'utf8'));
   receipt.form={initial,downloaded,blankPreserved:downloaded.assigned_person==='',unknownPreserved:downloaded.permission_confirmation==='unknown',notDonePreserved:downloaded.reason==='not done',statusRemainsHold:downloaded.status==='HOLD',downloadWorks:true};
 }
 await context.close();
}
for(const view of receipt.views){if(view.documentWidth>view.width)receipt.errors.push(`${view.page} ${view.width}: horizontal page overflow`);if(view.clipped.length)receipt.errors.push(`${view.page} ${view.width}: text bounds exceed viewport`);if(view.duplicateIds.length)receipt.errors.push('Duplicate IDs')}
if(receipt.networkRequests.length)receipt.errors.push('Unexpected network requests');
await fs.writeFile(path.join(out,'browser-checks.json'),JSON.stringify(receipt,null,2));
console.log(JSON.stringify({views:receipt.views.length,errors:receipt.errors,networkRequests:receipt.networkRequests.length,form:receipt.form}));
}finally{await browser.close()}
