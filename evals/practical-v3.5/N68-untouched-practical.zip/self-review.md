# Tự kiểm tra của tác giả N68 — FINAL

- Bắt đầu ghi đồng hồ: 2026-10-15 04:30:23 UTC (11:30:23 Asia/Bangkok).
- Chốt hoàn tất: 2026-10-15 04:46:45 UTC. Trong giới hạn 25 phút.
- Tác giả làm một mình. Không gọi agent con, không nhắn peer, không dùng web/CUA/dịch vụ ngoài, không cài thư viện hoặc đổi cấu hình.
- Chỉ dùng brief chung, SOURCE.md, nguồn gốc và bundle Visual Explainer được giao, cùng runtime được khai báo và hướng dẫn vận hành workspace.
- Model và sampling chính xác: không được cung cấp; không suy đoán.
- Owner edits: 0. Các sửa trước FINAL là tự sửa của tác giả. Đây là bản hoàn chỉnh đầu tiên; không đề nghị người điều phối sửa tiếp.

## Đã kiểm tra

1. SHA-256 của hai CSV, từ điển và giấy phép khớp bản chụp được cung cấp. CSV được sao nguyên byte, không sửa, không khử trùng.
2. Đỏ: 744 / 1.599 = 46,529080675422136%; trắng: 1.640 / 4.898 = 33,48305430788077%. Chênh lệch 13,046026367541366 điểm phần trăm. Báo cáo hiển thị 46,53%; 33,48%; 13,05 điểm phần trăm.
3. Phân bố đủ điểm 0–10 khớp tổng từng tệp. Quality thiếu/không hợp lệ và bản ghi sai số cột đều bằng 0. Không có ô thiếu hoặc không phải số hữu hạn trong 11 trường lý hóa.
4. Trùng đủ 12 trường: đỏ 220 nhóm / 460 dòng thuộc nhóm / 240 lần lặp sau lần đầu; trắng 772 nhóm / 1.709 dòng thuộc nhóm / 937 lần lặp sau lần đầu. Đếm độc lập từ byte dòng cũng khớp phần lặp. Không gán đây là lỗi hoặc số chai độc lập.
5. 24 kiểm tra trong verification/data-checks.json đều qua: đếm trực tiếp từ dòng byte nguồn, tử số, phân bố, trùng, 20 bản ghi liên tiếp mỗi tệp, mọi liên kết cục bộ và dựng lại byte-identical. Công thức thực tế: `& $Python -B build.py`, chạy từ practical, với $Python trỏ đến launcher Python UTF-8 đã cung cấp. Mã dựng chỉ dùng thư viện chuẩn Python 3.12+; đường dẫn đầu vào tương đối với build.py.
6. Đã xem ảnh render thật của Chrome headless: desktop 1280 × 900 và mobile 390 × 900, nền sáng/tối; phần mở đầu, phân bố, bảng mở, kế hoạch, nguồn và biểu mẫu. Các ảnh trong verification/ là bằng chứng tác giả đã xem. Ảnh toàn phần có thể chứa thanh điều hướng sticky ở vị trí cuộn khi chụp; các ảnh viewport-* cho thấy trạng thái cuộn thực tế.
7. Tám trạng thái trình duyệt được đo không có lỗi JavaScript hoặc tràn trang ngang; không phát sinh yêu cầu mạng. Kiểm tra token chữ của nền tối đạt tối thiểu 6,76:1 trên các nền được đo. Đây không phải kiểm toán tiếp cận toàn diện.
8. Biểu mẫu thử tải JSON thành công. Giữ nguyên người được giao trống, unknown, not done và HOLD; không tự nâng trạng thái, tự lưu hoặc gửi mạng. Bản ghi trong verification/form-test-download.json là dữ liệu thử kỹ thuật, không phải kiểm tra hồ sơ đã diễn ra.
9. Danh sách 40 dòng giữ đầy đủ source_file + source_data_row một-based sau tiêu đề. Cả 40 ở HOLD; vai trò A/B chưa gán người. Phép tính 2 người × 20 hồ sơ × 3 phút = 120 phút công; khoảng 1 giờ chỉ có điều kiện làm song song như đã nêu.

## Tự sửa trước khi chốt

Đặt hai tỷ lệ cạnh nhau trên điện thoại; giữ “≤ 5” cùng dòng; dùng font fallback cục bộ hỗ trợ tiếng Việt; bỏ nét thừa ở thanh có giá trị 0; thêm hai hình nhỏ để làm rõ tỷ lệ điểm ≤4 và ≥7; giữ bảng đầy đủ và nguồn đọc được trên điện thoại. Không cho điểm thẩm mỹ hoặc suy ra hiệu quả từ những kiểm tra này.

## Giới hạn thực tế

Chỉ kiểm tra Chrome headless với kích thước mô phỏng, chưa thử thiết bị di động vật lý, trình đọc màn hình hoặc người đọc thật. Không xác lập tính đại diện, độc lập của mẫu hay nguồn gốc dòng trùng. Không có kiểm tra hồ sơ, thử nếm, phê duyệt, nhân sự thật hoặc kết quả kinh doanh. Kế hoạch tiếp tục HOLD. Đây không phải lượt chấm chính thức VisEval. Font hiển thị có thể khác trên máy khác; không cần tải font để đọc.

## Dấu nhận dạng bàn giao

Entry: practical/report.html

SHA-256 report.html: dd0d97fb69cb4b56e9c6e147511501a3a78c42dbf0e9d28bb00ba6b2058d59f3

Gói giữ báo cáo, facts.csv, nguồn nguyên byte, xuất xứ/giấy phép/bản chụp, build.py + template/CSS, danh sách 40 dòng, biểu mẫu + mẫu JSON, README và HANDOFF. Không có công việc cần người điều phối sửa để hoàn chỉnh gói.
