from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
import csv, hashlib, json, subprocess, sys
p=Path(__file__).resolve().parent
facts=list(csv.DictReader((p/'facts.csv').open(encoding='utf-8-sig',newline='')))
review=list(csv.DictReader((p/'review-list.csv').open(encoding='utf-8-sig',newline='')))
results={'checks':[],'errors':[]}
def check(label,result):
    results['checks'].append({'check':label,'pass':bool(result)})
    if not result:results['errors'].append(label)
for name in ['winequality-red.csv','winequality-white.csv']:
    lines=(p/'source'/name).read_bytes().splitlines()[1:]
    direct=Counter(int(line.rsplit(b';',1)[1]) for line in lines)
    records=list(csv.DictReader((p/'source'/name).open(encoding='utf-8',newline=''),delimiter=';'))
    ff={x['metric']:x for x in facts if x['source_file']==name}
    check(name+': n from raw byte lines',int(ff['n']['value'])==len(lines))
    check(name+': threshold from raw byte lines',int(ff['below']['value'])==sum(v for q,v in direct.items() if q<=5))
    check(name+': distribution from raw byte lines',all(int(ff[f'quality_{q}_count']['value'])==direct[q] for q in range(11)))
    check(name+': duplicate excess from raw line identity',int(ff['duplicate_excess']['value'])==len(lines)-len(set(lines)))
    chosen=[x for x in review if x['source_file']==name]
    check(name+': 20 sequential original records',len(chosen)==20 and all(int(x['source_data_row'])==i and all(x[k]==v for k,v in records[i-1].items()) for i,x in enumerate(chosen,1)))
check('40 HOLD; blank assignees; unknown conditions; not done reasons',len(review)==40 and all(x['status']=='HOLD' and x['assigned_person']=='' and x['permission_confirmation']=='unknown' and x['reason']=='not done' for x in review))
class Links(HTMLParser):
    def handle_starttag(self,tag,attrs):
        for k,v in attrs:
            if k=='href' and v and not v.startswith(('http','data:','#')):check('Local link exists: '+v,(p/v.split('#')[0]).exists())
Links().feed((p/'report.html').read_text(encoding='utf-8'))
targets=['report.html','facts.csv','review-list.csv','work-record.html','work-record-template.json','snapshot.json','calculation-checks.json']
before={x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in targets}
subprocess.run([sys.executable,'-B',str(p/'build.py')],check=True,cwd=p)
after={x:hashlib.sha256((p/x).read_bytes()).hexdigest() for x in targets}
check('Rebuild produces byte-identical outputs',before==after)
results['rebuilt_output_sha256']=after
(p/'verification'/'data-checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':len(results['checks']),'errors':results['errors']},ensure_ascii=False))
