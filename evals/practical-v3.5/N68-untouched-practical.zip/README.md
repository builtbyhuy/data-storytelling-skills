# Gói Wine Quality ngoại tuyến

Mở `report.html` trong trình duyệt. Mọi nội dung chính, biểu đồ, nguồn, biểu mẫu và dữ liệu đều ở trong gói; không cần mạng. Liên kết DOI là tài liệu tham khảo tùy chọn.

## Dựng lại từ đầu vào giữ trong gói

Cần Python 3.12 trở lên, chỉ thư viện chuẩn; không tải hoặc cài thêm gì. Mở PowerShell 7 trong thư mục `practical`, đặt biến `$Python` thành trình thông dịch Python đã có hoặc launcher nhận nguyên đối số Python. Chạy đúng công thức đã dùng:

```powershell
& $Python -B build.py
```

Ở môi trường tác giả, `$Python` là launcher Python UTF-8 được cung cấp trong RUNTIME.md. Trên máy khác, đặt biến theo Python có sẵn; mã và công thức không chứa đường dẫn cá nhân. Tương đương trên shell có Python 3.12 sẵn: `python3 -B build.py`.

Mọi đường dẫn dữ liệu được tính từ vị trí `build.py`. Chương trình kiểm tra SHA-256 của 4 tệp nguồn trước khi đọc. Nếu byte khác bản chụp, dừng báo lỗi. Không sửa nguồn để chạy tiếp.

Các đầu ra được dựng lại: `report.html`, `facts.csv`, `review-list.csv`, `work-record.html`, `work-record-template.json`, `snapshot.json`, `calculation-checks.json`. Mã dựng là `build.py`; đầu vào thiết kế là `style.css`, `report.template.html`, `work-record.template.html`. README, HANDOFF, SOURCE và self-review là tài liệu giữ nguyên trong gói. Dựng lại ghi đè các đầu ra trên; hãy lưu bản ghi công việc thực tế ở tên riêng.

## Quy tắc tính

- Nguồn: 2 CSV nguyên byte trong `source/`; dấu phân cách `;`; UTF-8; tiêu đề đúng 12 cột.
- Hạt: một bản ghi dữ liệu sau tiêu đề; định danh bằng `source_file + source_data_row`, bắt đầu 1. Không suy ra chai hoặc người.
- Tất cả bản ghi trong mẫu số, kể cả trùng. Tử số: quality là số nguyên hữu hạn từ 0–10 và <= 5. Thiếu/không hợp lệ được báo riêng, không âm thầm loại mẫu số.
- Các trường lý hóa được kiểm tra ô thiếu và số hữu hạn. Không thêm đơn vị, chuẩn hóa, điền khuyết hoặc sửa giá trị.
- Trùng là tuple của đủ 12 chuỗi ô sau khi CSV parse; không chuẩn hóa số. `duplicate_excess` = tổng (số lần xuất hiện - 1); `duplicate_groups` = số tuple có >=2 dòng; `duplicate_members` = tất cả dòng thuộc nhóm trùng. Chưa chứng minh đây là lỗi nhập liệu.
- Phân bố đếm đủ điểm 0–10, kể cả mức không xuất hiện. Tỷ lệ = số dòng ở điểm / toàn bộ số dòng gốc * 100.
- Chênh lệch điểm phần trăm = tỷ lệ đỏ - tỷ lệ trắng. Không phải thay đổi tương đối. Hiển thị làm tròn hai chữ số; facts.csv giữ số đếm và tỷ lệ tính chưa làm tròn.
- Không tính khoảng tin cậy hoặc kiểm định suy rộng: chưa có bảo đảm chọn mẫu ngẫu nhiên, độc lập; xuất xứ dòng trùng chưa biết.

## Tệp để dùng

- `facts.csv`: chỉ tiêu, tệp/nhóm, giá trị, mẫu số, đơn vị, định nghĩa. `n` là số dòng gốc; `below` là số dòng thỏa ngưỡng. Các mức 0–10 có số đếm và tỷ lệ riêng.
- `review-list.csv`: đúng 20 dòng đầu mỗi tệp, giữ mọi trường gốc; trạng thái mới HOLD, người được giao trống, xác nhận unknown, lý do not done.
- `work-record.html`: biểu mẫu một hồ sơ, tải JSON cục bộ; không tự lưu, không gửi mạng hoặc tự nâng trạng thái.
- `work-record-template.json`: mẫu dữ liệu giữ trống/unknown/not done nguyên trạng.
- `SOURCE.md`, `snapshot.json`, `source/winequality.names`, `source/LICENSE-CC-BY-4.0.txt`: xuất xứ, dấu nhận dạng, từ điển và giấy phép.
- `self-review.md`, `verification/`: kiểm tra tác giả và ảnh render thực tế. Không phải kiểm thử người dùng hoặc kết quả kinh doanh.

CSV gốc giữ nguyên byte. Phân tích và thiết kế là sản phẩm dẫn xuất. Nguồn: Cortez et al. (2009), Wine Quality, UCI, DOI 10.24432/C56S3T, CC BY 4.0. Bản chụp thu nhận 2026-10-15 UTC theo SOURCE.md.

`SOURCE.md` được giữ nguyên từ tài liệu xuất xứ chung; đường dẫn `input/source/` trong tài liệu đó tương ứng với `source/` trong gói này. Bản ZIP gốc không cần để dựng lại; hai CSV nguyên byte, từ điển và giấy phép đã được giữ.

Phương pháp trình bày: Visual Explainer 0.12.0 của nicobailon, MIT (xem METHOD-LICENSE.txt). Dùng register Editorial, nhấn màu rượu đỏ, thanh so sánh và hình thời lượng. Font được thay bằng fallback cục bộ Cambria/Georgia và Segoe UI để đọc ngoại tuyến; không tải font từ mạng.
