import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const require=createRequire('C:/Users/user/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/package.json');
const {chromium}=require('playwright');
const base=path.dirname(fileURLToPath(import.meta.url));
const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true,args:['--disable-gpu','--no-first-run']});
const receipt={browser:await browser.version(),checks:[],network_requests:[],console_errors:[]};
for (const width of [960,390]){
 const page=await browser.newPage({viewport:{width,height:900},deviceScaleFactor:1.5});
 await page.route(/^https?:/,route=>{receipt.network_requests.push(route.request().url());return route.abort();});
 page.on('pageerror',e=>receipt.console_errors.push(String(e)));
 await page.goto(pathToFileURL(path.join(base,'report.html')).href,{waitUntil:'load'});
 await page.screenshot({path:path.join(base,'checks',`report-${width}.png`),fullPage:true});
 const report=await page.evaluate(()=>({viewport:innerWidth,scrollWidth:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,title:document.title,svgText:document.querySelectorAll('svg text').length,remoteAssets:[...document.querySelectorAll('script[src],img[src],link[rel=stylesheet]')].map(x=>x.src||x.href),smallVisible:[...document.querySelectorAll('p,td,th,summary')].filter(x=>x.getBoundingClientRect().height&&parseFloat(getComputedStyle(x).fontSize)<11).length}));
 await page.locator('details').first().evaluate(e=>e.open=true);
 await page.locator('details').nth(1).evaluate(e=>e.open=true);
 await page.screenshot({path:path.join(base,'checks',`report-expanded-${width}.png`),fullPage:true});
 const expanded=await page.evaluate(()=>({scrollWidth:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,distributionRows:document.querySelector('table').tBodies[0].rows.length}));
 receipt.checks.push({width,report,expanded});
 await page.goto(pathToFileURL(path.join(base,'review-form.html')).href,{waitUntil:'load'});
 await page.locator('#check').click();
 const defaultState=await page.evaluate(()=>({status:document.querySelector('[name=record_status]').value,quality:document.querySelector('[name=quality_original]').value,assignee:document.querySelector('[name=assignee]').value,progress:document.querySelector('[name=work_progress]').value,confirmations:[...document.querySelectorAll('select')].map(x=>[x.name,x.value]),scrollWidth:document.documentElement.scrollWidth}));
 await page.screenshot({path:path.join(base,'checks',`form-${width}.png`),fullPage:true});
 // Save default form to ensure blank/unknown/not done survive serialization.
 const downloadPromise=page.waitForEvent('download');await page.locator('#save').click();const download=await downloadPromise;await download.saveAs(path.join(base,'checks',`blank-record-${width}.json`));
 const blank=JSON.parse(fs.readFileSync(path.join(base,'checks',`blank-record-${width}.json`),'utf8'));
 if(blank.quality_original!==''||blank.assignee!==''||blank.work_progress!=='not done'||blank.record_status!=='HOLD'||blank.permission_confirmation!=='unknown')throw Error('Initial form values not preserved');
 receipt.checks.at(-1).formDefault=defaultState;receipt.checks.at(-1).blankSerialization='passed';
 await page.close();
}
const localLinks=[...fs.readFileSync(path.join(base,'report.html'),'utf8').matchAll(/href="([^"]+)"/g)].map(x=>x[1]).filter(x=>!x.startsWith('#')&&!/^https?:/.test(x));
receipt.missingLocalLinks=localLinks.filter(x=>!fs.existsSync(path.join(base,x)));
fs.writeFileSync(path.join(base,'checks','render-receipt.json'),JSON.stringify(receipt,null,2));
await browser.close();console.log(JSON.stringify(receipt,null,2));
