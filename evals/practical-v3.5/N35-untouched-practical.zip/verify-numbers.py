from pathlib import Path
from collections import Counter
from decimal import Decimal
import csv,hashlib,json
p=Path(__file__).resolve().parent
facts=list(csv.DictReader((p/'facts.csv').open(encoding='utf-8-sig',newline='')))
lookup={(r['metric'],r['group']):r for r in facts}
observations={}
for group,name in [('red','winequality-red.csv'),('white','winequality-white.csv')]:
 raw=(p/'source'/name).read_bytes()
 lines=raw.decode('utf-8').splitlines(); header=lines[0].split(';'); rows=[line.split(';') for line in lines[1:]]
 assert all(len(row)==12 for row in rows)
 scores=[int(row[-1]) for row in rows]; counts=Counter(scores);n=len(rows);k=sum(q<=5 for q in scores)
 assert int(lookup[('source_rows',group)]['value'])==n
 assert int(lookup[('quality_le_5_rows',group)]['value'])==k
 assert abs(Decimal(lookup[('quality_le_5_ratio',group)]['value'])-Decimal(k)/n)<Decimal('1e-27')
 for score in range(11):
  f=lookup[('quality_'+str(score)+'_rows',group)]
  assert int(f['value'])==counts[score] and int(f['denominator'])==n
 dup=Counter(tuple(row) for row in rows)
 for metric,value in [('duplicate_excess_rows',sum(c-1 for c in dup.values())),('duplicate_involved_rows',sum(c for c in dup.values() if c>1)),('duplicate_groups',sum(c>1 for c in dup.values())),('unique_full_records',len(dup))]:assert int(lookup[(metric,group)]['value'])==value
 observations[group]={'n':n,'quality_le_5':k,'all_11_score_counts_tie_out':sum(counts.values())==n,'independent_raw_row_duplicate_check':True,'source_sha256':hashlib.sha256(raw).hexdigest()}
queue=list(csv.DictReader((p/'review-queue.csv').open(encoding='utf-8-sig',newline='')))
assert len(queue)==40
assert Counter(q['source_file'] for q in queue)=={'winequality-red.csv':20,'winequality-white.csv':20}
assert all(q['assignee']=='' and q['work_status']=='HOLD' and q['permission_confirmation']=='unknown' for q in queue)
for name in ['winequality-red.csv','winequality-white.csv']:
 source=list(csv.DictReader((p/'source'/name).open(encoding='utf-8',newline=''),delimiter=';'))
 selected=[q for q in queue if q['source_file']==name]
 assert [int(q['source_data_row']) for q in selected]==list(range(1,21))
 assert all(all(q[col]==source[int(q['source_data_row'])-1][col] for col in source[0]) for q in selected)
# Check actual source hashes against retained manifest, including original dictionary/license/archive.
manifest=json.loads((p/'source-manifest.json').read_text(encoding='utf-8'))
for row in manifest['files']:
 b=(p/row['file']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
# Contrast screen: sRGB ratios, actual foreground/background pairs. Not a conformance certification.
def lum(color):
 a=[int(color[i:i+2],16)/255 for i in (1,3,5)];a=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in a];return .2126*a[0]+.7152*a[1]+.0722*a[2]
def contrast(a,b):
 x,y=sorted([lum(a),lum(b)]);return(y+.05)/(x+.05)
pairs=[('#253330','#f7f5ef'),('#55625b','#f7f5ef'),('#792f4c','#fffdf8'),('#21655d','#fffdf8'),('#52615b','#f4eee7'),('#77500d','#f4ebd4')]
result={'numeric_checks':'passed','method':'Independent raw-line semicolon split, last-field score tally and whole-record tuple count; compared with CSV-generated facts','observations':observations,'facts_rows':len(facts),'queue_records':len(queue),'queue_order_and_original_values':'passed','queue_all_hold_and_unassigned':True,'retained_files_sha256':'passed for all 5 source files','contrast_screen':[{'foreground':a,'background':b,'ratio':round(contrast(a,b),2)}for a,b in pairs],'limits':['Not an end-user comprehension test or full WCAG audit','No external metadata or source URLs checked in this offline run','No real reviewer, permission or business outcome was supplied']}
assert all(contrast(a,b)>=4.5 for a,b in pairs)
(p/'checks'/'numeric-receipt.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
