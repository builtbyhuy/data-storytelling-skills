# Hướng dẫn kiểm tra hồ sơ — kế hoạch giả định đang HOLD

1. Mở `review-queue.csv`: có 40 dòng, 20 bản ghi dữ liệu đầu tiên của mỗi CSV nguồn. Mọi dòng còn HOLD, chưa gán người thật. A/B chỉ là hai vị trí công việc dự kiến, không phải nhân sự đã xác nhận.
2. Dùng cặp `source_file + source_data_row` để mở đúng dòng. Dòng dữ liệu bắt đầu 1 sau tiêu đề. Giữ nguyên 12 giá trị nguồn và thứ tự; không xóa các dòng có giá trị trùng.
3. Mở `review-form.html`, điền một hồ sơ cho một người. Sao chép nguyên giá trị quality và các trường cần đối chiếu. Ô trống, `unknown`, `not done` có ý nghĩa riêng và được giữ nguyên khi tải JSON; không thay bằng 0 hoặc “đã xong”.
4. Xác nhận từng điều kiện bằng bằng chứng thật: tên tệp và SHA-256 bản chụp, xuất xứ hồ sơ, phạm vi được xác nhận, một người được giao và thực sự sẵn sàng, quyền thực hiện. Với từng mục, ghi ai xác nhận, thời điểm và bằng chứng/giới hạn. Chưa biết thì giữ `unknown`; chưa làm thì `not done`.
5. Thiếu hoặc chưa xác nhận bất kỳ điều kiện nào: **HOLD**. Đủ điều kiện trên hồ sơ: chỉ **READY FOR REVIEW**. Đây là trạng thái chuẩn bị để con người xem xét, không phải cho phép bắt đầu. Nút kiểm tra chỉ hỗ trợ rà trường, không xác thực tính đúng của bằng chứng hoặc quyền.
6. Ghi lý do và hành động tiếp theo cụ thể. Tải JSON và kiểm tra tệp tải về. Trang không gửi dữ liệu, không có lưu trữ nền và không tự khởi động kiểm tra. Có thể sửa JSON bằng trình soạn thảo hoặc dùng phiếu mới cho lần ghi tiếp theo; giữ giá trị gốc.

Phạm vi kiểm tra: hồ sơ dữ liệu nhập và xuất xứ trên máy tính, không thử nếm hay xác nhận chất lượng rượu. Đề bài không cung cấp nhân sự hoặc phê duyệt thật.

Khối lượng giả định: 40 hồ sơ × 3 phút = 120 người-phút. Hai người × 20 hồ sơ/người = 60 phút/người. Khoảng một giờ trôi qua chỉ nếu cả hai thật sự sẵn sàng và làm song song theo giả định; chưa tính chờ hoặc xử lý phát sinh.

Danh sách đầu tệp là mẫu thuận tiện tái lập được, không ngẫu nhiên/đại diện và không phải mẫu đánh giá hiệu quả. Nếu bản chụp không khớp hash, dừng và giữ HOLD; không trộn phiên bản.
