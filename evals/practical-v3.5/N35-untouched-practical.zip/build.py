from pathlib import Path
import csv, hashlib, json, html
from collections import Counter
from decimal import Decimal, getcontext
getcontext().prec=32
P=Path(__file__).resolve().parent
EXPECTED={'winequality-red.csv':'4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e','winequality-white.csv':'76c3f809815c17c07212622f776311faeb31e87610d52c26d87d6e361b169836'}
GROUPS=[('red','Rượu đỏ','winequality-red.csv','#792f4c'),('white','Rượu trắng','winequality-white.csv','#21655d')]
D={}; facts=[]; manifest=[]
def fact(metric,g,v,den='',unit='rows',definition=''):
 facts.append({'metric':metric,'group':g,'source_file':D[g]['file'] if g in D else '', 'value':str(v),'denominator':str(den),'unit':unit,'definition':definition})
def vi(n):return f'{n:,}'.replace(',','.')
def pct(n,d,digits=2):return f'{100*n/d:.{digits}f}'.replace('.',',')+'%'
for key,label,name,color in GROUPS:
 b=(P/'source'/name).read_bytes(); digest=hashlib.sha256(b).hexdigest()
 if digest!=EXPECTED[name]: raise ValueError('Source SHA-256 mismatch: '+name)
 reader=csv.DictReader(b.decode('utf-8').splitlines(),delimiter=';'); rows=list(reader)
 if len(reader.fieldnames)!=12 or reader.fieldnames[-1]!='quality':raise ValueError('Unexpected source schema')
 if any(None in row or any(v is None for v in row.values()) for row in rows):raise ValueError('Malformed row')
 vals=[]; missing=invalid=0
 for row in rows:
  raw=row['quality']
  if raw.strip()=='':missing+=1;continue
  try:q=Decimal(raw)
  except Exception:invalid+=1;continue
  if not q.is_finite() or q!=q.to_integral_value() or not 0<=q<=10:invalid+=1;continue
  vals.append(int(q))
 count=Counter(vals); dup=Counter(tuple(row[k] for k in reader.fieldnames) for row in rows)
 n=len(rows); low=sum(count[q] for q in range(6))
 D[key]={'label':label,'file':name,'color':color,'rows':rows,'fields':reader.fieldnames,'n':n,'low':low,'counts':count,'missing':missing,'invalid':invalid,'excess':sum(v-1 for v in dup.values()),'involved':sum(v for v in dup.values() if v>1),'dup_groups':sum(v>1 for v in dup.values()),'unique':len(dup),'hash':digest}
 manifest.append({'file':'source/'+name,'bytes':len(b),'sha256':digest,'unchanged':True})
 fact('source_rows',key,n);fact('quality_le_5_rows',key,low,n);fact('quality_le_5_ratio',key,Decimal(low)/Decimal(n),n,'proportion','Numerator: quality_le_5_rows; denominator: all source data rows')
 fact('quality_missing_rows',key,missing,n);fact('quality_invalid_rows',key,invalid,n)
 for q in range(11):
  fact('quality_'+str(q)+'_rows',key,count[q],n)
  fact('quality_'+str(q)+'_ratio',key,Decimal(count[q])/Decimal(n),n,'proportion')
 for m,k in [('duplicate_excess_rows','excess'),('duplicate_involved_rows','involved'),('duplicate_groups','dup_groups'),('unique_full_records','unique')]:fact(m,key,D[key][k],n if m!='duplicate_groups' else '', 'groups' if m=='duplicate_groups' else 'rows')
 assert sum(count.values())+missing+invalid==n
 assert low==sum(q<=5 for q in vals)
r,w=D['red'],D['white'];gap=(Decimal(r['low'])/r['n']-Decimal(w['low'])/w['n'])*100
fact('red_minus_white_quality_le_5_pp','comparison',gap,'','percentage_points','100 * (744/1599 - 1640/4898); no rounding before subtraction')
for metric,value,unit in [('planned_records_total',40,'records'),('planned_records_per_type',20,'records'),('planned_people',2,'people'),('planned_records_per_person',20,'records'),('assumed_minutes_per_record',3,'minutes'),('planned_total_work_minutes',120,'person_minutes'),('conditional_parallel_elapsed_minutes',60,'minutes')]:fact(metric,'hypothetical_plan',value,'',unit,'Hypothesis only; staff and authorization not supplied')
with (P/'facts.csv').open('w',newline='',encoding='utf-8-sig') as f:
 wr=csv.DictWriter(f,fieldnames=list(facts[0]));wr.writeheader();wr.writerows(facts)
for name in ['winequality.names','LICENSE-CC-BY-4.0.txt','wine+quality.zip']:
 b=(P/'source'/name).read_bytes();manifest.append({'file':'source/'+name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'unchanged':True})
(P/'source-manifest.json').write_text(json.dumps({'source_acquisition_date_utc':'2026-10-15','hash_algorithm':'SHA-256','files':manifest,'source_csv_modified':False,'rules':['Semicolon CSV; UTF-8; quoted header','Data row starts at 1 after header; file order retained','quality valid if finite integer 0..10; blank=missing; all others invalid','All data rows remain in denominator, including missing/invalid; no such quality values found in retained inputs','No deduplication; duplicates are identical parsed values of all 12 source fields within each file','No weighting, statistical inference, imputation, filtering, smoothing or ordinal-score averaging','Percentage = 100 * count / all source data rows; display 2 decimals, use unrounded ratios for gap']},ensure_ascii=False,indent=2),encoding='utf-8')
queue=[]
for key,label,name,color in GROUPS:
 for i,row in enumerate(D[key]['rows'][:20],1):
  queue.append({'source_file':name,'source_data_row':i,'wine_type_derived':key,**row,'proposed_work_slot':('A' if key=='red' else 'B'),'assignee':'','snapshot_confirmation':'unknown','provenance_confirmation':'unknown','scope_confirmation':'unknown','assignee_readiness':'unknown','permission_confirmation':'unknown','work_status':'HOLD','reason':'Chưa có xác nhận điều kiện; chưa được bắt đầu','next_action':'Xác nhận nguồn, xuất xứ, phạm vi, người sẵn sàng và quyền thực hiện'})
assert len(queue)==40 and len({(x['source_file'],x['source_data_row']) for x in queue})==40
with (P/'review-queue.csv').open('w',newline='',encoding='utf-8-sig') as f:
 wr=csv.DictWriter(f,fieldnames=list(queue[0]));wr.writeheader();wr.writerows(queue)
def figure(key):
 d=D[key];c=d['counts'];color=d['color'];n=d['n']
 # Native SVG text, 360 units wide; shared percentage scale 0..50%.
 bits=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 470" role="img" aria-labelledby="title-{key} desc-{key}"><title id="title-{key}">Phân bố điểm: {d["label"]}</title><desc id="desc-{key}">Mỗi thanh là tỷ lệ trên toàn bộ {n} dòng; điểm 0 đến 10 theo thứ tự. Thang ngang chung từ 0 đến 50 phần trăm. Số dòng và tỷ lệ có ở cuối thanh và trong bảng dữ liệu.</desc><style>text{{font-family:Segoe UI,Arial,sans-serif;fill:#253330;font-size:13px}}.score{{font-weight:700}}.axis{{fill:#52615b;font-size:12px}}</style>']
 bits.append('<text x="9" y="17" class="axis">Điểm</text><text x="344" y="17" text-anchor="end" class="axis">Dòng · tỷ lệ</text>')
 bits.append('<rect x="1" y="29" width="358" height="216" rx="4" fill="#f4eee7"/><text x="7" y="263" class="axis">↑ Vùng quy tắc ≤ 5</text>')
 for tick in [0,10,20,30,40,50]:
  x=44+tick/50*170
  bits.append(f'<line x1="{x}" y1="30" x2="{x}" y2="440" stroke="#dedfd6"/><text x="{x}" y="460" class="axis" text-anchor="middle">{tick}%</text>')
 for q in range(11):
  y=44+q*38 if q<=5 else 66+q*38
  amount=c[q];length=(amount/n*100)/50*170
  bits.append(f'<text x="10" y="{y+5}" class="score">{q}</text><rect x="44" y="{y-8}" width="{length:.5f}" height="16" fill="{color}" rx="2"/><text x="346" y="{y+5}" text-anchor="end">{vi(amount)} · {pct(amount,n)}</text>')
 bits.append('</svg>');s=''.join(bits);(P/f'distribution-{key}.svg').write_text(s,encoding='utf-8');return s
figures={key:figure(key) for key,_,_,_ in GROUPS}
rows=''.join(f'<tr><th scope="row">{q}</th><td>{vi(r["counts"][q])}</td><td>{pct(r["counts"][q],r["n"])}</td><td>{vi(w["counts"][q])}</td><td>{pct(w["counts"][q],w["n"])}</td></tr>' for q in range(11))
cards=''
for key,label,name,color in GROUPS:
 d=D[key]
 cards+=f'<article class="rate-card {key}"><div class="card-label"><span class="swatch"></span>{label}<span class="source-short">{name}</span></div><div class="big-rate">{pct(d["low"],d["n"])}</div><p class="fraction"><strong>{vi(d["low"])}</strong> / {vi(d["n"])} dòng gốc</p><div class="rate-bar" aria-hidden="true"><i style="width:{100*d["low"]/d["n"]:.6f}%"></i></div><div class="bar-scale"><span>0%</span><span>quality ≤ 5</span><span>100%</span></div></article>'
values={'RATE_CARDS':cards,'GAP':str(round(gap,2)).replace('.',','),'FIG_RED':figures['red'],'FIG_WHITE':figures['white'],'DIST_ROWS':rows,'RED5':pct(r['counts'][5],r['n']),'WHITE5':pct(w['counts'][5],w['n']),'RED34':pct(r['counts'][3]+r['counts'][4],r['n']),'WHITE34':pct(w['counts'][3]+w['counts'][4],w['n']),'RED6':pct(r['counts'][6],r['n']),'WHITE6':pct(w['counts'][6],w['n'])}
template=(P/'report.template.html').read_text(encoding='utf-8')
for k,v in values.items():template=template.replace('{{'+k+'}}',v)
if '{{' in template:raise ValueError('Unresolved template token')
(P/'report.html').write_text(template,encoding='utf-8')
(P/'analysis.json').write_text(json.dumps({k:{x:y for x,y in v.items() if x not in ['rows','fields','counts']}|{'counts':dict(v['counts'])} for k,v in D.items()},ensure_ascii=False,indent=2),encoding='utf-8')
print('Built report.html, facts.csv, source-manifest.json, review-queue.csv and editable SVGs from retained source bytes.')
print('Threshold counts:',r['low'],'/',r['n'],'and',w['low'],'/',w['n'],'; gap pp:',gap)

