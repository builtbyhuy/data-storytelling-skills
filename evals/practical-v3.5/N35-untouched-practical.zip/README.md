# Wine Quality — gói báo cáo ngoại tuyến

Mở `report.html` bằng trình duyệt để đọc báo cáo tiếng Việt. Không cần mạng, đăng nhập, máy chủ hoặc thư viện ngoài. Liên kết DOI/UCI/giấy phép là tài liệu tham khảo ngoài, không được tải khi đọc báo cáo.

## Dựng lại từ các đầu vào được giữ

Môi trường: Python 3.12 trở lên, chỉ thư viện chuẩn. Không cài thêm gói, không cần mạng. Từ chính thư mục `practical`, chạy nguyên lệnh:

```text
python -B build.py
```

Lệnh này đọc hai CSV trong `source/` và `report.template.html`; kiểm SHA-256 trước khi tính; tạo lại `facts.csv`, `report.html`, `distribution-red.svg`, `distribution-white.svg`, `review-queue.csv`, `analysis.json`, `source-manifest.json`. Các tệp nguồn không bị sửa. Nếu hash khác, chương trình dừng thay vì phân tích phiên bản chưa xác nhận.

Trong môi trường thực hiện thử nghiệm, cùng mã dựng được chạy với bộ thông dịch có sẵn thông qua helper Python bắt buộc của máy; không thay đổi mã hoặc đầu vào. Lệnh trên là công thức dựng lại di động không có đường dẫn cá nhân. Không cần Playwright để tạo lại báo cáo; Playwright/Chrome chỉ phục vụ kiểm tra hiển thị trong lượt này.

`review-form.html` là biểu mẫu nguồn HTML độc lập, `REVIEW-GUIDE.md` là hướng dẫn điền. Chúng được giữ sẵn trong gói, không cần sinh lại. `SOURCE.md` là hồ sơ xuất xứ được cung cấp nguyên nội dung; đường dẫn `input/source/` trong tài liệu đó chỉ vị trí ở bộ đầu vào thử nghiệm. Trong gói bàn giao này, các tệp nguyên byte nằm tại `source/`. `source-manifest.json` ghi đường dẫn thực tế và SHA-256.

## Phương pháp và đối chiếu

- CSV dùng `;`, tiêu đề 12 trường. Phân loại đỏ/trắng theo tên tệp; không có cột loại rượu gốc.
- Hạt đếm là bản ghi dữ liệu theo thứ tự tệp, không tính tiêu đề. `source_file + source_data_row` chỉ định dòng, không phải chai/người.
- Không lọc, khử trùng, bù thiếu, gán trọng số hay lấy trung bình điểm thứ bậc. Không có kiểm định, khoảng tin cậy hoặc kết luận nhân quả.
- Điểm quality hợp lệ nếu là số nguyên hữu hạn từ 0 đến 10; trống = thiếu; còn lại = không hợp lệ. Mọi dòng vẫn nằm trong mẫu số. Hai CSV hiện có 0 thiếu và 0 không hợp lệ.
- Bản ghi trùng là bộ 12 giá trị nguồn đọc từ CSV giống hoàn toàn trong cùng một tệp. Các dòng trùng được giữ. “Dòng lặp sau bản đầu” = tổng (k−1) theo nhóm; “dòng thuộc nhóm trùng” = tổng k trong các nhóm k>1.
- Tỷ lệ = số dòng đạt điều kiện / tổng dòng dữ liệu. Chênh lệch dùng tỷ lệ chưa làm tròn. Hiển thị 2 chữ số thập phân bằng dấu phẩy, hàng nghìn bằng dấu chấm; `facts.csv` dùng số máy đọc được với dấu chấm thập phân.
- Các thanh tỷ lệ chính bắt đầu 0 và kết thúc trục 100%; biểu đồ phân bố dùng cùng thang 0–50% và giữ mọi điểm 0–10. Nhãn số và bảng là lựa chọn đọc ngoài màu sắc. SVG giữ text chỉnh sửa được.
- Kế hoạch 40 hồ sơ còn HOLD. Các trường giao việc không thể hiện nhân sự, phê duyệt hay kết quả thật. 120 người-phút là dự toán giả định; 60 phút trôi qua chỉ có điều kiện làm song song.

## Tệp bàn giao

- `report.html`, `report.template.html`, `build.py`: trang hoàn chỉnh và nguồn dựng.
- `facts.csv`: mọi số đếm phân bố 0–10, tỷ lệ chính xác, mẫu số, chỉ số trùng và giả định công việc.
- `source/`: hai CSV nguyên byte, từ điển nguồn, giấy phép; bản lưu kho ZIP gốc nếu có.
- `SOURCE.md`, `source-manifest.json`: xuất xứ, giấy phép, dấu nhận dạng bản chụp.
- `review-queue.csv`, `review-form.html`, `REVIEW-GUIDE.md`: danh sách 40 hồ sơ, phiếu mới và hướng dẫn ngắn.
- `distribution-*.svg`, `analysis.json`: biểu đồ sửa được và bảng tính máy đọc được.
- `self-review.md`, `checks/`: ghi nhận tự kiểm tra và ảnh hiển thị máy tính/điện thoại.

Bộ phương pháp: Scientific Critical Thinking 1.5 và Scientific Visualization 1.4 của K-Dense, bản thích nghi cục bộ 02/10/2026. Trích dẫn phương pháp đã được đưa vào phần nguồn của báo cáo theo tài liệu được cung cấp; metadata chưa kiểm tra trực tuyến trong lượt ngoại tuyến.
