# Tự kiểm tra — N35, lần bàn giao đầu

- Bắt đầu ghi nhận tại máy: **2026-10-15T11:43:04.0874091+07:00** (mốc đồng hồ đầu tiên ngay sau khi nhận nhiệm vụ).
- Kết thúc công việc / chốt bàn giao: **2026-10-15T11:51:46.7061058+07:00**. Trong giới hạn 25 phút từ nhiệm vụ.
- Trạng thái: hoàn chỉnh, tác giả tự làm và tự sửa trước bàn giao. **Owner edits = 0**. Không gọi tác giả phụ, không đọc lượt trước/điều kiện khác, không dùng web, CUA, dịch vụ ngoài, cài đặt hoặc cấu hình toàn cục.
- Model chính xác và tham số sampling: **không được cung cấp / unknown**; không suy đoán.

## Đã thực hiện và kiểm tra

1. Đọc đề chung, runtime, xuất xứ được cung cấp; áp dụng cả hai SKILL.md được giao cùng quy tắc cục bộ và tài liệu liên quan về sai lệch/suy luận thống kê, tính toàn vẹn trực quan, màu và khả năng đọc. Phân biệt quan sát theo tệp, diễn giải có phạm vi, giả định kế hoạch và điều chưa biết; không gán GRADE/RoB cho bài đếm mô tả. Trích dẫn phương pháp được đưa vào nguồn theo metadata của bundle; chưa kiểm chứng metadata đó qua mạng.
2. Giữ nguyên byte cả hai CSV. SHA-256 khớp bản chụp nguồn. Giữ thêm từ điển, giấy phép và ZIP gốc; 5 tệp trong manifest đều đối chiếu được. Không chỉnh nguồn, khử trùng, bù thiếu hoặc lọc mẫu số.
3. Tính lại độc lập bằng chia dòng thô theo dấu chấm phẩy và đọc trường cuối, so với phép đọc CSV trong mã dựng. Đối chiếu tổng 11 mức điểm, ngưỡng, mẫu số, bản ghi trùng và mọi số đếm phân bố trong facts.csv. Kết quả: đỏ **744/1.599 = 46,53%**; trắng **1.640/4.898 = 33,48%**; chênh chính xác trước làm tròn **13,046026367541371… điểm phần trăm**. Cả hai tệp 0 quality thiếu, 0 quality không hợp lệ.
4. Đối chiếu trùng toàn bản ghi bằng hai cách đọc: đỏ 220 nhóm, 460 dòng liên quan, 240 dòng lặp sau bản đầu; trắng 772 nhóm, 1.709 dòng liên quan, 937 dòng lặp. Giữ chúng trong phép tính. Không đồng nhất trùng dữ liệu với lỗi hoặc chai trùng.
5. Danh sách 40 hồ sơ: đúng 20 dòng dữ liệu đầu mỗi tệp, đúng định danh nguồn + vị trí bắt đầu từ 1, giữ nguyên 12 giá trị gốc. Mọi hồ sơ HOLD, người được giao rỗng và điều kiện quyền unknown. A/B chỉ là vị trí việc giả định. Đối chiếu 40 × 3 = 120 người-phút; điều kiện hai người song song được nêu rõ.
6. Mở tệp HTML trực tiếp bằng Chrome headless **155.0.8059.40** ở **960 × 900** và **390 × 900** CSS pixel, chặn mọi HTTP(S). Có ảnh toàn trang, bản mở chi tiết, ảnh đầu trang, phân bố và bảng. **Đã tự xem ảnh desktop và mobile** ở độ lớn đọc được: tiêu đề/thẻ tỷ lệ, nhãn/thang và vùng ≤ 5 của biểu đồ, bảng 11 điểm, bố cục biểu mẫu. Tự sửa tiêu đề để nói rõ tỷ lệ và tránh từ rơi cuối dòng trên điện thoại. Không thấy cắt nhãn, tràn ngang hoặc chồng chữ trong phần đã xem.
7. Kiểm tra cơ học: scrollWidth bằng viewport cả hai kích thước, kể cả khi mở chi tiết; 62 phần tử SVG text; không có tài nguyên ngoài, yêu cầu mạng hoặc lỗi JavaScript; mọi liên kết cục bộ trong báo cáo có tệp đích. Nội dung nguồn/giới hạn có trong HTML đọc ngoại tuyến.
8. Biểu mẫu mới hiển thị HOLD. Đã bấm kiểm tra và tải JSON trống ở hai kích thước; chất lượng gốc và người giao vẫn là chuỗi rỗng, các xác nhận vẫn unknown, tiến độ vẫn not done. Không tạo người, xác nhận hay kết quả giả. Bản tải thử đã xóa sau khi kiểm tra. READY FOR REVIEW được mô tả là trạng thái để con người xem xét, không phải quyền bắt đầu.
9. Sàng lọc tương phản sRGB trên sáu cặp màu chính: từ **5,66:1 đến 12,08:1**; nhãn và phân tách bổ sung cho màu. Đây không phải chứng nhận WCAG.
10. Dựng lại từ đầu vào giữ trong một thư mục khác trong vùng được phép, không dùng đường dẫn cá nhân trong mã dựng. Cả bảy đầu ra sinh tự động khớp SHA-256/byte: report.html, facts.csv, hai SVG, review-queue.csv, analysis.json và source-manifest.json. Giữ receipt; đã xóa thư mục kiểm tra tạm và script khám phá dùng một lần.

## Công thức dựng lại giữ nguyên

Từ thư mục practical, với Python 3.12+ và chỉ thư viện chuẩn:

    python -B build.py

Trong runtime thử nghiệm, mã này thực sự đã được chạy qua helper Python bắt buộc với đối số **-B build.py**, từ thư mục gói và từ thư mục dựng lại. Không cần cài gói/mạng/đường dẫn cá nhân để dựng; các script kiểm tra hiển thị riêng dùng đường dẫn Chrome/Node được runtime khai báo, không phải phụ thuộc của báo cáo.

## Giới hạn thực tế

Chưa có thử nghiệm đọc hiểu với người dùng, kiểm toán WCAG đầy đủ, kiểm tra trình duyệt Safari/Firefox hoặc bản in trên giấy. Ảnh/render và sàng lọc cơ học chỉ chứng minh những gì đã kiểm tra. Báo cáo điện thoại khá dài do giữ phân bố và giới hạn; chi tiết công thức thu gọn bằng disclosure bản địa. Đọc báo cáo không cần JavaScript, nhưng nút kiểm tra/lưu JSON của biểu mẫu cần JavaScript; có hướng dẫn thủ công đi kèm. Biểu mẫu không xác minh tính thật của bằng chứng hoặc thẩm quyền, không tự lưu nền hay nhập lại JSON. Kế hoạch vẫn HOLD; không có người thật, phê duyệt hoặc kiểm tra hồ sơ nào được thực hiện. Không ngoại suy thị trường hay số chai độc lập.

Ảnh và receipts trong checks/ là bằng chứng tự kiểm tra của tác giả, không phải người đánh giá độc lập hoặc chứng nhận chất lượng.
