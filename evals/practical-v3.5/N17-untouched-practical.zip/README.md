# Wine Quality — gói báo cáo ngoại tuyến

Mở `report.html` bằng trình duyệt. Nội dung, biểu đồ, bảng, nguồn và biểu mẫu không cần mạng. Liên kết DOI/UCI/CC chỉ là dẫn nguồn tùy chọn. Ngôn ngữ: tiếng Việt. Chữ dùng font hệ thống, không gọi font/CDN ngoài.

## Dựng lại từ đầu vào đã giữ

Yêu cầu: Python 3.12 trở lên, chỉ thư viện chuẩn; không cần cài gói hoặc tải mạng. Từ chính thư mục `practical`, chạy nguyên công thức:

```text
python -B build.py
```

`python` là lệnh trỏ tới Python có sẵn của người nhận. Trong môi trường bài thử Windows, cùng mã và đối số `-B build.py` được thực thi bằng launcher Python UTF-8 đã được cấp trong RUNTIME.md; launcher không là phụ thuộc của gói. Chạy từ bất kỳ vị trí nào cũng được vì mã lấy thư mục theo vị trí build.py; công thức ở trên được thiết kế cho thư mục gói. Không dùng đường dẫn cá nhân trong mã dựng, không có cài đặt hoặc mạng. Build sẽ dừng nếu thiếu tệp nguồn hoặc SHA-256 khác bản chụp được giao.

Đầu ra dựng lại: report.html, facts.csv, source-manifest.json, review-worklist-40.csv, record-template.csv, record-form.html, distribution.svg, FORM-GUIDE.md và README.md. Nguồn trong source/ và SOURCE.md được giữ nguyên, không sửa bởi build. `distribution.svg` là hình vector có chữ chỉnh sửa được; report.html dùng bố cục thanh HTML đáp ứng để chữ không co nhỏ trên điện thoại.

## Tệp và cách đọc

- facts.csv: mỗi dòng một chỉ tiêu/tệp; value giữ giá trị chưa làm tròn, denominator là số dòng gốc khi có ý nghĩa. quality_score_0…10 có số dòng và tỷ lệ cho đủ thang, kể cả điểm không xuất hiện. Tỷ lệ tính theo %; chênh lệch tính theo điểm phần trăm. Các dòng hypothetical_plan được ghi là giả định.
- source/: hai CSV gốc, từ điển, archive gốc và giấy phép nguyên byte. SOURCE.md ghi nguồn/DOI/giấy phép; source-manifest.json có byte và SHA-256. Tên tệp xác định loại rượu; tệp không có cột wine type.
- review-worklist-40.csv: 20 dòng đầu mỗi tệp, nhận dạng source_file + source_data_row, mọi giá trị nguồn giữ nguyên; chưa có phân công và phê duyệt. Không phải mẫu đại diện.
- record-form.html + record-template.csv + FORM-GUIDE.md: phiếu mới cho một hồ sơ/một người, giữ giá trị trống/unknown/not done; xuất JSON cục bộ. Không có lưu tự động hoặc gửi mạng.

## Quy tắc ảnh hưởng kết quả

Đọc UTF-8, CSV chấm phẩy; một record do trình đọc CSV trả về là một dòng dữ liệu, tiêu đề không tính. Kiểm tra đúng 12 cột. Giữ thứ tự và mọi dòng trùng. quality hợp lệ là số nguyên hữu hạn 0–10; rỗng là thiếu, khác quy tắc là không hợp lệ. Mẫu số luôn là tất cả bản ghi trong tệp, không loại thiếu/không hợp lệ. Bản chụp này có 0 thiếu/0 không hợp lệ ở từng tệp. Tử số chỉ gồm điểm hợp lệ ≤5. Dòng trùng so sánh toàn bộ 12 giá trị đã đọc theo dạng chuỗi; không chuyển số rồi hợp nhất. Kiểm tra tổng phân bố và missing/invalid bằng mẫu số; unique+duplicate_excess bằng số dòng gốc. Không khử trùng, không gán mã chai, không suy ra nhân quả.

Hai tỷ lệ mô tả trọn bản chụp nguồn, không là ước lượng có thiết kế lấy mẫu cho quần thể. Không giả định độc lập của dòng hay dùng khoảng tin cậy để ngụ ý đại diện. quality là thứ bậc; không dùng trung bình như thước đo khoảng cách chất lượng. Ngưỡng ≤5 là giả định bài tập, không là giới hạn lỗi hay tiêu chuẩn thương mại. Không có cơ sở từ tệp để suy ra thời gian, nhà sản xuất/lô, giá, chi phí hoặc tư vấn mua/bán.

## Ghi công

Cortez, P., Cerdeira, A., Almeida, F., Matos, T., Reis, J. (2009). Wine Quality [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56S3T . CC BY 4.0 theo hồ sơ nguồn, giấy phép lưu cục bộ. Bài báo: Modeling wine preferences by data mining from physicochemical properties, Decision Support Systems 47(4), 547–553, https://doi.org/10.1016/j.dss.2009.05.016 . CSV nguyên trạng; HTML, facts, worklist và SVG là sản phẩm dẫn xuất, không được tác giả nguồn chứng thực.
