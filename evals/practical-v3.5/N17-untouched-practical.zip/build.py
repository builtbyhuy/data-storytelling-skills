#!/usr/bin/env python3
"""Portable Wine Quality report builder. Python 3.12+, standard library only.
Run from this directory: python -B build.py
Source files are read as retained bytes; they are never rewritten.
"""
from pathlib import Path
from collections import Counter
from decimal import Decimal, InvalidOperation
import csv, hashlib, html, json

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source'
FILES = [('red', 'Rượu đỏ', 'winequality-red.csv'), ('white', 'Rượu trắng', 'winequality-white.csv')]
EXPECTED = {
 'winequality-red.csv': '4a402cf041b025d4566d954c3b9ba8635a3a8a01e039005d97d6a710278cf05e',
 'winequality-white.csv': '76c3f809815c17c07212622f776311faeb31e87610d52c26d87d6e361b169836',
 'winequality.names': '15d215e73b39105952380fd487e4ce1bf5a6b83a425abb285c2ec55193d3ca92',
 'LICENSE-CC-BY-4.0.txt': '9ba9550ad48438d0836ddab3da480b3b69ffa0aac7b7878b5a0039e7ab429411',
 'wine+quality.zip': '3ed56667f4b828242bd732d7d1dd7f2861e54432239d7fa63877014cbb0304d4'
}
HEADER = ['fixed acidity','volatile acidity','citric acid','residual sugar','chlorides','free sulfur dioxide','total sulfur dioxide','density','pH','sulphates','alcohol','quality']
def fmt(n, places=1):
    return f'{n:,.{places}f}'.replace(',', '_').replace('.', ',').replace('_', '.')
def integer(n): return f'{n:,}'.replace(',', '.')
def esc(s): return html.escape(str(s), quote=True)

manifest = []
for name, expected in EXPECTED.items():
    raw = (SOURCE / name).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != expected: raise ValueError(f'Source snapshot mismatch: {name}')
    manifest.append({'file':name, 'bytes':len(raw), 'sha256':actual})
(ROOT/'source-manifest.json').write_text(json.dumps({'source_acquired_utc':'2026-10-15','hash_algorithm':'SHA-256','retained_unmodified':True,'files':manifest}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

stats, facts, worklist = {}, [], []
def fact(metric, group, value, denominator='', unit='rows', note=''):
    facts.append({'metric':metric,'source_file':group,'value':value,'denominator':denominator,'unit':unit,'note':note})
for key,label,name in FILES:
    with (SOURCE/name).open(encoding='utf-8', newline='') as f:
        reader=csv.reader(f, delimiter=';')
        header=next(reader)
        if header != HEADER: raise ValueError(f'Unexpected header: {name}')
        rows=list(reader)
    if any(len(r)!=12 for r in rows): raise ValueError(f'Malformed record width: {name}')
    counts=Counter(); missing=invalid=0
    for r in rows:
        q=r[-1]
        if q=='': missing+=1; continue
        try:
            d=Decimal(q)
            if not d.is_finite() or d!=d.to_integral_value() or not 0<=d<=10: raise ValueError()
            counts[int(d)]+=1
        except (InvalidOperation, ValueError): invalid+=1
    duplicates=Counter(tuple(r) for r in rows)
    n=len(rows); low=sum(counts[q] for q in range(6)); excess=sum(v-1 for v in duplicates.values())
    stats[key]={'label':label,'file':name,'n':n,'low':low,'rate':low/n*100,'counts':counts,
                'missing':missing,'invalid':invalid,'unique':len(duplicates),'excess':excess,
                'duplicate_groups':sum(v>1 for v in duplicates.values()),'rows':rows}
    assert sum(counts.values())+missing+invalid==n
    assert len(duplicates)+excess==n
    for metric,value in [('original_records',n),('quality_le_5_records',low),('quality_missing_records',missing),('quality_invalid_records',invalid),('unique_full_records',len(duplicates)),('duplicate_excess_records',excess),('duplicate_groups',sum(v>1 for v in duplicates.values())),('records_in_duplicate_groups',sum(v for v in duplicates.values() if v>1))]:
        fact(metric,name,value,n,'rows' if metric!='duplicate_groups' else 'groups')
    fact('quality_le_5_rate',name,repr(low/n*100),n,'percent','Numerator: quality_le_5_records; original records retained')
    fact('quality_ge_7_records',name,sum(counts[q] for q in range(7,11)),n)
    fact('quality_ge_7_rate',name,repr(sum(counts[q] for q in range(7,11))/n*100),n,'percent')
    for q in range(11):
        fact(f'quality_score_{q}_records',name,counts[q],n)
        fact(f'quality_score_{q}_rate',name,repr(counts[q]/n*100),n,'percent')
    for i,row in enumerate(rows[:20],1):
        worklist.append({'source_file':name,'source_data_row':i,**dict(zip(header,row)),
                         'assignee':'','source_snapshot_confirmation':'unknown','provenance_confirmation':'unknown',
                         'scope_confirmation':'unknown','assignee_readiness':'unknown','permission_confirmation':'unknown',
                         'status':'HOLD','reason':'Chưa có xác nhận điều kiện; danh sách thuận tiện, chưa bắt đầu kiểm tra',
                         'next_action':'Xác nhận điều kiện và người được giao trước khi chuẩn bị rà soát'})
r,w=stats['red'],stats['white']
gap=r['rate']-w['rate']
fact('red_minus_white_quality_le_5_rate','red minus white',repr(gap),'','percentage_points','Difference of original-file rates; descriptive only')
for metric,value,unit in [('proposed_records_total',40,'records'),('proposed_records_each_type',20,'records'),('assumed_reviewers',2,'people'),('assumed_records_each_reviewer',20,'records'),('assumed_minutes_each_record',3,'minutes'),('assumed_total_work',120,'person_minutes'),('conditional_parallel_elapsed',60,'minutes')]:
    fact(metric,'hypothetical_plan',value,'',unit,'Assumption, not actual staffing or permission')
with (ROOT/'facts.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(facts[0]));writer.writeheader();writer.writerows(facts)
with (ROOT/'review-worklist-40.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(worklist[0]));writer.writeheader();writer.writerows(worklist)
with (ROOT/'record-template.csv').open('w',encoding='utf-8-sig',newline='') as f:
    fields=['source_file','source_data_row','original_value','source_snapshot_confirmation','provenance_confirmation','scope','scope_confirmation','assignee','assignee_readiness','permission_confirmation','review_execution','status','reason','next_action']
    writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerow({**dict.fromkeys(fields,''),'review_execution':'not done'})

CSS='''
:root{--ink:#222538;--muted:#5b6173;--paper:#fff;--canvas:#f2f2f8;--line:#d5d6e3;--red:#74395f;--white:#956000;--hold:#654a12;--holdbg:#fff1cb}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--canvas);color:var(--ink);font:17px/1.58 "Segoe UI",Arial,sans-serif}a{color:#51419a;text-underline-offset:4px}a:hover{text-decoration-thickness:2px}a:focus-visible,summary:focus-visible,button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:3px solid #4833a6;outline-offset:4px}p{margin:.7em 0 1em;max-width:74ch}h1,h2,h3{line-height:1.16;margin:0 0 .7em}h1{font:400 clamp(32px,4vw,48px)/1.15 Georgia,"Times New Roman",serif;max-width:24ch;letter-spacing:-.025em}h2{font-size:27px;font-weight:650}h3{font-size:20px;font-weight:650}main{max-width:1120px;margin:0 auto;padding:30px 36px 65px}.topline{display:flex;justify-content:space-between;gap:16px;align-items:center;padding:8px 0 22px;border-bottom:1px solid var(--line);font-size:16px}.topline strong{font-weight:650}.topline a{white-space:nowrap}.hero{padding:37px 0 31px;display:grid;grid-template-columns:1.2fr 1fr;gap:46px;align-items:center}.lede{font-size:19px}.tag{display:inline-block;border:1px solid var(--line);padding:3px 10px;border-radius:4px;color:var(--muted);font-size:16px;margin-bottom:18px}.comparison{background:var(--paper);padding:25px 26px 21px;border-radius:12px;box-shadow:0 5px 20px #22253808}.comparison h2{font-size:18px;line-height:1.4;margin-bottom:21px}.pair{margin-bottom:22px}.pair:last-child{margin-bottom:0}.pair-head{display:flex;align-items:baseline;justify-content:space-between;gap:14px;margin-bottom:7px}.pair-head strong{font-size:29px;line-height:1.15}.swatch{width:10px;height:10px;display:inline-block;border-radius:50%;margin-right:7px}.red{color:var(--red)}.white{color:var(--white)}.track{height:13px;background:#e8e8f1;border-radius:3px;overflow:hidden}.fill{height:100%;background:var(--red)}.fill.white-fill{background:var(--white)}.subline{font-size:16px;color:var(--muted);margin:6px 0 0}.answer-note{background:#e5e4f4;border-left:4px solid #6a5a9b;padding:17px 21px;margin:0 0 35px;border-radius:0 8px 8px 0}.answer-note p{margin:0}.section{padding:32px 0;border-top:1px solid var(--line)}.section-heading{display:flex;justify-content:space-between;align-items:baseline;gap:20px}.section-heading p{margin:0;color:var(--muted);font-size:16px}.two-col{display:grid;grid-template-columns:1.6fr 1fr;gap:32px}.tablewrap{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:17px;font-variant-numeric:tabular-nums}th,td{text-align:right;padding:12px 14px;border-bottom:1px solid var(--line);vertical-align:top}th{font-weight:650;background:#e9e9f3}th:first-child,td:first-child{text-align:left}caption{text-align:left;color:var(--muted);font-size:16px;padding-bottom:11px}td small{font-size:16px;color:var(--muted);display:block}strong{font-weight:650}.evidence-table th,.evidence-table td{padding:14px}.evidence-mobile{display:none}.context{padding:18px 21px;background:#fff;border-radius:8px}.context p:last-child{margin-bottom:0}.context h3{font-size:20px}.distribution{padding:22px 24px 15px;background:#fff;border-radius:10px}.dist-heading{display:grid;grid-template-columns:48px 1fr 1fr;gap:19px;margin-bottom:12px;font-size:17px;font-weight:650}.dist-row{display:grid;grid-template-columns:48px 1fr 1fr;gap:19px;align-items:center;padding:8px 0;border-top:1px solid #eeeeF5}.score{font-weight:650}.dcell{display:flex;align-items:center;gap:12px}.dtrack{height:14px;flex:1;background:#eeeef5;border-radius:2px;overflow:hidden}.dbar{height:100%;background:var(--red)}.dbar.w{background:var(--white)}.dlabel{width:76px;white-space:nowrap;font-size:17px;font-variant-numeric:tabular-nums}.dist-row.low{background:#f6f5fa;margin-left:-8px;margin-right:-8px;padding-left:8px;padding-right:8px}.chart-note{font-size:16px;color:var(--muted);margin:13px 0 0}.bullets{padding-left:22px;max-width:74ch}.bullets li{padding:4px 0}.hold-box{display:grid;grid-template-columns:190px 1fr;gap:25px;background:var(--holdbg);padding:25px;border-radius:10px}.hold-mark{font-size:27px;line-height:1.2;font-weight:700;color:var(--hold)}.hold-mark span{display:block;font-size:16px;font-weight:400;margin-top:10px}.hold-box p{margin-top:0}.hold-box p:last-child{margin-bottom:0}.plan-metrics{display:flex;flex-wrap:wrap;gap:12px 28px;padding:22px 0 12px}.plan-metrics span{display:block;font-size:16px;color:var(--muted)}.plan-metrics strong{font-size:23px}.action-links{display:flex;flex-wrap:wrap;gap:12px;margin-top:20px}.button{display:inline-block;border-radius:6px;padding:10px 16px;background:#51419a;color:#fff;text-decoration:none;border:1px solid #51419a;font:inherit}.button.secondary{background:white;color:#51419a}.fine{font-size:16px;color:var(--muted)}details{border:1px solid var(--line);border-radius:8px;background:#fff;margin:15px 0}summary{cursor:pointer;font-weight:650;padding:17px 20px}details>.inside{padding:0 20px 20px}details p{margin-top:.5em}code{font-family:Consolas,monospace;font-size:16px;overflow-wrap:anywhere}.hash-list{display:grid;gap:15px}.hash-list p{margin:0}.hash-list code{display:block;color:#414458}.footer{padding-top:25px;border-top:1px solid var(--line);font-size:16px;color:var(--muted)}.footer p{margin:0 0 12px}.back{font-size:16px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px 24px}.form-grid label{display:block;font-weight:600}.form-grid input,.form-grid select,.form-grid textarea{width:100%;font:400 17px/1.4 "Segoe UI",Arial,sans-serif;border:1px solid #9a9eb3;border-radius:5px;padding:10px;margin-top:7px;background:#fff;color:var(--ink)}.form-grid textarea{min-height:95px;resize:vertical}.wide{grid-column:1/-1}.form-status{padding:16px 20px;border:2px solid #ad8c3f;background:var(--holdbg);border-radius:6px;margin:25px 0}.success{background:#e2f3ef;border-color:#437769}.screen-only{display:block}
@media(max-width:740px){main{padding:18px 20px 45px}.topline{align-items:flex-start;flex-direction:column;gap:5px;padding-bottom:15px}.hero{display:block;padding:28px 0 25px}.hero h1{font-size:34px;max-width:100%}.lede{font-size:18px}.comparison{margin-top:25px;padding:22px}.answer-note{margin-bottom:25px;padding:15px 17px}.section{padding:27px 0}.section-heading{display:block}.section-heading p{margin-bottom:17px}.two-col{display:block}.context{margin-top:20px}h2{font-size:25px}.evidence-table{display:none}.evidence-mobile{display:block}.evidence-mobile article{padding:17px 0;border-top:1px solid var(--line)}.evidence-mobile article:first-child{border-top:0;padding-top:0}.evidence-mobile h3{margin-bottom:9px}.record-summary{display:grid;grid-template-columns:1fr auto;gap:5px 16px;font-size:17px;margin:0}.record-summary dt{color:var(--muted)}.record-summary dd{margin:0;text-align:right;font-weight:600}.distribution{padding:18px 12px 14px}.dist-heading{grid-template-columns:35px 1fr 1fr;gap:10px;font-size:16px}.dist-row{grid-template-columns:35px 1fr 1fr;gap:10px;padding:9px 0}.dcell{display:block}.dtrack{height:9px;margin-top:5px}.dlabel{display:block;width:auto;font-size:17px;line-height:1.25}.dcell .dlabel{order:-1}.dist-row.low{margin-left:-4px;margin-right:-4px;padding-left:4px;padding-right:4px}.hold-box{display:block;padding:21px}.hold-mark{font-size:25px;margin-bottom:20px}.hold-mark span{margin-top:5px}.plan-metrics{gap:14px 25px}.action-links{display:block}.action-links a{display:block;margin-bottom:10px;text-align:center}.tablewrap{margin-left:-5px;margin-right:-5px}th,td{padding:10px 8px;font-size:16px}.form-grid{display:block}.form-grid label{margin-bottom:20px}details>.inside{padding:0 15px 18px}summary{padding:16px 15px}.hash-list code{font-size:16px}.wide{grid-column:auto}}
@media(prefers-reduced-motion:reduce){html{scroll-behavior:auto}}@media print{body{background:#fff}main{padding:0;max-width:none}.topline a,.action-links,.screen-only{display:none}details{break-inside:avoid}details>.inside{display:block}.section{break-inside:avoid}a{color:inherit}h1{font-size:32px}.hero{gap:25px}form{break-inside:auto}}
'''
paired=''.join(f'''<div class="pair"><div class="pair-head"><span class="{key}"><i class="swatch" style="background:var(--{key})"></i>{s['label']}</span><strong>{fmt(s['rate'])}%</strong></div><div class="track" aria-hidden="true"><div class="fill {'white-fill' if key=='white' else ''}" style="width:{s['rate']}%"></div></div><p class="subline">{integer(s['low'])} / {integer(s['n'])} dòng nguồn</p></div>''' for key,s in stats.items())
summary_rows=''.join(f"<tr><th scope='row' class='{key}'>{s['label']}</th><td>{integer(s['n'])}</td><td>{integer(s['low'])}</td><td><strong>{fmt(s['rate'],2)}%</strong></td></tr>" for key,s in stats.items())
mobile_rows=''.join(f"<article><h3 class='{key}'>{s['label']}</h3><dl class='record-summary'><dt>Dòng gốc / mẫu số</dt><dd>{integer(s['n'])}</dd><dt>Dòng có điểm ≤5</dt><dd>{integer(s['low'])}</dd><dt>Tỷ lệ theo tệp gốc</dt><dd>{fmt(s['rate'],2)}%</dd></dl></article>" for key,s in stats.items())
distrows=''
for q in range(11):
    cells=''
    for key,s in stats.items():
        pct=s['counts'][q]/s['n']*100
        cells+=f"<div class='dcell'><span class='dlabel'>{fmt(pct)}%</span><div class='dtrack' aria-hidden='true'><div class='dbar {'w' if key=='white' else ''}' style='width:{pct/50*100}%'></div></div></div>"
    distrows+=f"<div class='dist-row {'low' if q<=5 else ''}'><span class='score'>{q}</span>{cells}</div>"
distribution_table=''.join(f"<tr><th scope='row'>{q}</th><td>{r['counts'][q]}</td><td>{fmt(r['counts'][q]/r['n']*100,2)}%</td><td>{integer(w['counts'][q])}</td><td>{fmt(w['counts'][q]/w['n']*100,2)}%</td></tr>" for q in range(11))
duplicate_table=''.join(f"<tr><th scope='row'>{s['label']}</th><td>{integer(s['unique'])}</td><td>{integer(s['duplicate_groups'])}</td><td>{integer(s['excess'])}</td></tr>" for s in stats.values())
hashhtml=''.join(f"<p><strong>{esc(m['file'])}</strong> · {integer(m['bytes'])} byte<code>{m['sha256']}</code></p>" for m in manifest)

REPORT=f'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Đọc hai tệp Wine Quality · Tỷ lệ điểm ≤5</title><meta name="description" content="Báo cáo mô tả hai tệp gốc Wine Quality, giữ nguyên dòng trùng, có nguồn và gói dựng lại ngoại tuyến."><style>{CSS}</style></head><body><main id="top" data-essential>
<header class="topline"><strong>Wine Quality / Phiếu đọc dữ liệu</strong><a href="#source">Nguồn &amp; cách tính</a></header>
<section class="hero" aria-labelledby="headline"><div><span class="tag">Hai tệp mẫu lịch sử • UCI</span><h1 id="headline">Tệp đỏ có tỷ lệ điểm ≤5 cao hơn {fmt(gap)} điểm phần trăm.</h1><p class="lede">Trong các dòng nguồn, tỷ lệ này là <strong>{fmt(r['rate'])}% ở đỏ</strong> và <strong>{fmt(w['rate'])}% ở trắng</strong>. Đây là chênh lệch mô tả của hai tệp đã giữ lại.</p></div><figure class="comparison" style="margin-left:0;margin-right:0" aria-labelledby="pairtitle"><h2 id="pairtitle">Dòng có điểm ≤5 trong mỗi tệp</h2>{paired}<figcaption class="chart-note">Mỗi thanh đầy tương ứng 100% số dòng của chính tệp đó.</figcaption></figure></section>
<aside class="answer-note"><p><strong>Cách dùng kết quả:</strong> nếu chỉ cần phân luồng theo quy tắc giả định này, tệp đỏ có tỷ trọng vào luồng ≤5 cao hơn. Ngưỡng ≤5 do bài tập đặt ra; <strong>không phải tiêu chuẩn lỗi hay chuẩn thương mại</strong>. Không đủ cơ sở để kết luận loại rượu nào “tốt hơn” toàn diện.</p></aside>
<section class="section" aria-labelledby="denom"><h2 id="denom">Đếm trên toàn bộ dòng gốc</h2><div class="two-col"><div><div class="tablewrap evidence-table"><table><caption>Tử số và mẫu số, không gồm tiêu đề; giữ mọi dòng trùng.</caption><thead><tr><th scope="col">Tệp</th><th scope="col">Dòng gốc<br>/ mẫu số</th><th scope="col">Điểm ≤5<br>/ tử số</th><th scope="col">Tỷ lệ</th></tr></thead><tbody>{summary_rows}</tbody></table></div><div class="evidence-mobile">{mobile_rows}<p class="fine">Không gồm dòng tiêu đề; giữ mọi dòng trùng.</p></div><p class="fine">Công thức: số dòng có <code>quality ≤ 5</code> ÷ số bản ghi dữ liệu trong cùng tệp × 100. Chênh lệch dùng tỷ lệ chưa làm tròn; “điểm phần trăm” là phép trừ hai tỷ lệ.</p></div><aside class="context"><h3>Độ chắc chắn nằm ở đâu?</h3><p>Phép đếm này bao phủ trọn hai tệp được giữ lại. Có <strong>0 điểm thiếu, 0 điểm không hợp lệ</strong> trong từng tệp; không có dòng nào bị loại khỏi mẫu số.</p><p>Sự chắc chắn về phép đếm không tạo ra tính đại diện cho quần thể rượu hoặc thị trường hiện tại.</p></aside></div></section>
<section class="section" aria-labelledby="dist"><div class="section-heading"><h2 id="dist">Nhìn đủ thang điểm, từ 0 đến 10</h2><p>Tỷ lệ trong từng tệp</p></div><p>Điểm là thang thứ bậc. Cả hai tệp tập trung ở 5–6; tệp trắng có tỷ trọng ở điểm 6 cao hơn. Các mức không xuất hiện vẫn được giữ trên trục.</p><div class="distribution" role="group" aria-label="Phân bố tỷ lệ theo điểm, đỏ và trắng"><div class="dist-heading"><span>Điểm</span><span class="red">Rượu đỏ</span><span class="white">Rượu trắng</span></div>{distrows}<p class="chart-note">Nền nhạt đánh dấu điểm 0–5. Hai cột thanh dùng cùng thang 0–50%; số in cạnh thanh là tỷ lệ quan sát, đã làm tròn 1 chữ số.</p></div><details><summary>Xem số dòng và tỷ lệ ở từng điểm</summary><div class="inside"><div class="tablewrap"><table><caption>Đỏ: mẫu số {integer(r['n'])}; trắng: mẫu số {integer(w['n'])}. Dòng tổng dùng dữ liệu chưa làm tròn.</caption><thead><tr><th scope="col">Điểm</th><th scope="col">Đỏ: dòng</th><th scope="col">Đỏ: %</th><th scope="col">Trắng: dòng</th><th scope="col">Trắng: %</th></tr></thead><tbody>{distribution_table}<tr><th scope="row">Tổng</th><td>{integer(r['n'])}</td><td>100,00%</td><td>{integer(w['n'])}</td><td>100,00%</td></tr></tbody></table></div></div></details><ul class="bullets"><li><strong>Tỷ lệ và khối lượng là hai câu hỏi khác nhau.</strong> Tệp trắng có {integer(w['low'])} dòng ≤5, nhiều hơn {integer(r['low'])} dòng của tệp đỏ, vì tổng số dòng lớn hơn. Điều này không mâu thuẫn với tỷ lệ thấp hơn.</li><li><strong>Một ngưỡng cắt không kể hết phân bố.</strong> Điểm 7–10 chiếm {fmt(sum(r['counts'][q] for q in range(7,11))/r['n']*100)}% ở đỏ và {fmt(sum(w['counts'][q] for q in range(7,11))/w['n']*100)}% ở trắng; có rất ít dòng ở hai đầu thang.</li></ul></section>
<section class="section" aria-labelledby="grain"><h2 id="grain">Một dòng là một bản ghi, chưa phải một chai riêng biệt</h2><p>Hai tệp mô tả mẫu Vinho Verde của Bồ Đào Nha. Nguồn không cấp mã chai hoặc mã mẫu vật lý duy nhất. <code>source_file + source_data_row</code> chỉ định vị bản ghi trong bản chụp nguồn: hàng dữ liệu bắt đầu từ 1 sau tiêu đề.</p><details><summary>Dòng trùng được kiểm tra và giữ lại như thế nào?</summary><div class="inside"><p>So sánh cả 12 giá trị đã đọc của mỗi bản ghi trong cùng tệp. Một “nhóm trùng” có ít nhất hai bản ghi giống nhau ở toàn bộ cột. “Dòng dư lặp” là tổng số bản ghi vượt quá lần xuất hiện đầu tiên của mỗi nhóm; đây là cách đếm, không phải kết luận lỗi.</p><div class="tablewrap"><table><thead><tr><th scope="col">Tệp</th><th scope="col">Bản ghi phân biệt</th><th scope="col">Nhóm trùng</th><th scope="col">Dòng dư lặp</th></tr></thead><tbody>{duplicate_table}</tbody></table></div><p>Đỏ: {integer(r['unique'])} + {integer(r['excess'])} = {integer(r['n'])}; trắng: {integer(w['unique'])} + {integer(w['excess'])} = {integer(w['n'])}. Mọi bản ghi vẫn tham gia tính tỷ lệ. Nguồn chưa cho biết vì sao các dòng giống nhau; không mặc định là lỗi nhập hoặc cùng một chai.</p></div></details><p class="fine">Không có trường thời gian, nhà sản xuất, lô, giá hoặc chi phí. Báo cáo không suy ra nguyên nhân, hương vị, biến động thị trường hay khuyến nghị mua/bán.</p></section>
<section class="section" aria-labelledby="next"><h2 id="next">Chuẩn bị một kiểm tra hồ sơ nhỏ</h2><div class="hold-box"><div class="hold-mark">HOLD<span>Chưa được bắt đầu</span></div><div><p><strong>Đề xuất:</strong> kiểm tra dữ liệu nhập và xuất xứ của 40 dòng trên máy tính, gồm 20 dòng dữ liệu đầu tiên của mỗi tệp. Nguồn đủ để tạo danh sách; đây là lựa chọn thuận tiện, không ngẫu nhiên, không đại diện và không dùng để đánh giá hiệu quả.</p><p>Trước khi kiểm tra, cần xác nhận bản chụp nguồn, xuất xứ, phạm vi, người được giao thật sự sẵn sàng và quyền thực hiện. Hiện chưa có nhân sự hay phê duyệt thật. Đây không phải thử nếm hoặc xác nhận chất lượng rượu.</p></div></div><div class="plan-metrics"><div><strong>40 hồ sơ</strong><span>20 đỏ + 20 trắng</span></div><div><strong>120 phút công</strong><span>40 × 3 phút giả định</span></div><div><strong>Khoảng 1 giờ</strong><span>Chỉ khi 2 người làm song song</span></div></div><p>Giả định hai người, mỗi người 20 hồ sơ. Tốc độ 3 phút/hồ sơ là giả định để chuẩn bị; thời gian thực tế chưa biết. Chưa phân công tên người nào.</p><div class="action-links"><a class="button" href="record-form.html">Mở phiếu cho một hồ sơ</a><a class="button secondary" href="review-worklist-40.csv" download>Tải danh sách 40 dòng</a></div><p class="fine">Phiếu có thể ghi giá trị gốc còn trống, <code>unknown</code> hoặc <code>not done</code>. Khi thiếu điều kiện: HOLD. Đủ điều kiện được ghi trên phiếu: chỉ READY FOR REVIEW; trạng thái này chưa cấp quyền bắt đầu.</p></section>
<section class="section" id="source" aria-labelledby="sourcetitle"><h2 id="sourcetitle">Nguồn, quy tắc đọc và giới hạn</h2><p>Nguồn: Cortez, Cerdeira, Almeida, Matos &amp; Reis (2009), <em>Wine Quality</em>, UCI Machine Learning Repository. Bản chụp được thu thập ngày 15/10/2026 UTC theo hồ sơ xuất xứ của gói; đây không phải ngày lấy mẫu.</p><p><a href="https://doi.org/10.24432/C56S3T">DOI bộ dữ liệu</a> · <a href="https://archive.ics.uci.edu/dataset/186/wine+quality">Trang UCI</a> · <a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>. Các liên kết này chỉ là dẫn nguồn; báo cáo và tệp đính kèm đọc được ngoại tuyến.</p><details><summary>Cách đọc, kiểm tra và tính lại</summary><div class="inside"><ul class="bullets"><li>Đọc CSV UTF-8, dấu phân cách chấm phẩy; giữ thứ tự và 12 cột. Dấu thập phân trong dữ liệu là dấu chấm. Loại đỏ/trắng lấy từ tên tệp, không phải cột dữ liệu.</li><li>Không sửa byte tệp nguồn; không khử trùng, lấy mẫu hay gán thêm đơn vị cho các cột. Điểm hợp lệ phải là số nguyên hữu hạn trong 0–10; điểm rỗng là thiếu, các giá trị khác quy tắc là không hợp lệ. Mẫu số luôn gồm mọi bản ghi.</li><li>Trong bản chụp này không có điểm thiếu hoặc không hợp lệ. Nếu gặp chúng ở dữ liệu khác, phải báo riêng; không diễn giải các giá trị đó như đã xác nhận ≤5. Bộ dựng sẽ dừng nếu dấu SHA-256 không khớp bản chụp.</li><li><code>quality</code> là điểm cảm quan có thứ bậc; từ điển nguồn mô tả trung vị của ít nhất ba đánh giá chuyên gia. Báo cáo dùng tỷ lệ và phân bố, không coi khoảng cách điểm là một đại lượng vật lý liên tục.</li><li>Số trình bày dùng dấu phẩy thập phân; facts.csv giữ số chưa làm tròn. Sai khác cộng tỷ lệ hiển thị có thể do làm tròn.</li></ul><p><a href="facts.csv" download>Tải facts.csv</a> · <a href="README.md">Hướng dẫn gói &amp; dựng lại</a> · <a href="build.py">Mã nguồn tạo báo cáo</a></p></div></details><details><summary>Nhận dạng bản chụp và tệp nguyên gốc</summary><div class="inside"><p>Dấu SHA-256 được tính trên byte đã giữ lại và đối chiếu trước khi dựng. Hai tệp CSV được sao chép nguyên byte từ đầu vào được giao.</p><div class="hash-list">{hashhtml}</div><p><a href="source/winequality-red.csv" download>Tệp đỏ nguyên gốc</a> · <a href="source/winequality-white.csv" download>Tệp trắng nguyên gốc</a> · <a href="source/winequality.names">Từ điển nguồn</a> · <a href="source/LICENSE-CC-BY-4.0.txt">Giấy phép lưu trong gói</a> · <a href="SOURCE.md">Hồ sơ xuất xứ</a></p></div></details><p class="fine">Bài báo nguồn: P. Cortez và cộng sự, “Modeling wine preferences by data mining from physicochemical properties”, <em>Decision Support Systems</em> 47(4), 547–553 (2009), <a href="https://doi.org/10.1016/j.dss.2009.05.016">DOI bài báo</a>. Báo cáo và danh sách kiểm tra là phân tích dẫn xuất; không hàm ý tác giả dữ liệu tán thành kết luận.</p></section>
<footer class="footer"><p>Quan sát đã đếm: tỷ lệ và phân bố trong hai tệp. Diễn giải có giới hạn: khối lượng phân luồng theo một ngưỡng giả định. Chưa biết: tính đại diện, quan hệ giữa các bản ghi trùng và thời gian kiểm tra thực tế.</p><a class="back" href="#top">Về đầu báo cáo</a></footer></main></body></html>'''
(ROOT/'report.html').write_text(REPORT,encoding='utf-8')

form_fields=[
('source_file','Tệp nguồn','text'),('source_data_row','Vị trí dòng dữ liệu (từ 1 sau tiêu đề)','text'),
('original_value','Giá trị gốc cần ghi lại (có thể để trống, unknown, not done)','textarea'),
('source_snapshot_confirmation','Xác nhận đúng bản chụp nguồn','select'),('provenance_confirmation','Xác nhận xuất xứ hồ sơ','select'),
('scope','Phạm vi kiểm tra được đề xuất','textarea'),('scope_confirmation','Xác nhận phạm vi','select'),
('assignee','Một người được giao (chưa có thì để trống)','text'),('assignee_readiness','Xác nhận người được giao thật sự sẵn sàng','select'),
('permission_confirmation','Xác nhận quyền thực hiện','select'),('permission_reference','Bằng chứng/đầu mối xác nhận quyền (nếu có)','text'),
('review_execution','Tình trạng thực hiện nguyên văn','text'),('reason','Lý do trạng thái và điều chưa biết','textarea'),('next_action','Hành động tiếp theo','textarea')]
fieldshtml=''
for name,label,kind in form_fields:
    if kind=='select': control=f'<select id="{name}" name="{name}"><option value="">Để trống / chưa ghi</option><option value="unknown">unknown</option><option value="not done">not done</option><option value="confirmed">Đã xác nhận</option><option value="not confirmed">Chưa xác nhận</option></select>'
    elif kind=='textarea': control=f'<textarea id="{name}" name="{name}"></textarea>'
    else: control=f'<input id="{name}" name="{name}" type="text" value="{"not done" if name=="review_execution" else ""}" autocomplete="off">'
    fieldshtml+=f'<label class="{"wide" if kind=="textarea" else ""}" for="{name}">{label}{control}</label>'
FORM=f'''<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Phiếu một hồ sơ · Wine Quality</title><style>{CSS}</style></head><body><main data-essential><header class="topline"><strong>Phiếu mới / Một hồ sơ</strong><a href="report.html">Về báo cáo</a></header><section class="section"><h1>Ghi một hồ sơ và một người được giao</h1><p>Đây là phiếu trống để chuẩn bị công việc. Không có dữ liệu người hoặc phê duyệt thật được điền sẵn. Giá trị gốc được xuất đúng như đã nhập, kể cả rỗng, <code>unknown</code>, <code>not done</code>; không tự đổi chúng thành “đã xác nhận”.</p><div class="form-status" id="state" role="status" aria-live="polite"><strong id="state-label">HOLD</strong><p id="state-reason">Thiếu hoặc chưa xác nhận điều kiện. Chưa được bắt đầu kiểm tra.</p></div><form id="record"><div class="form-grid">{fieldshtml}</div><div class="action-links"><button type="button" class="button" id="download">Xuất phiếu JSON</button><button type="reset" class="button secondary">Xóa để ghi hồ sơ mới</button></div></form><p id="download-status" role="status" aria-live="polite"></p><noscript><p>JavaScript đang tắt: hãy ghi phiếu bằng bản CSV hoặc in trang. Trạng thái mặc định vẫn là HOLD.</p></noscript></section><section class="section"><h2>Cách kiểm tra trước khi giao</h2><ol class="bullets"><li>Ghi đúng <code>source_file + source_data_row</code>. Đối chiếu tên tệp và vị trí dòng với nguồn, không coi đây là mã chai hoặc người.</li><li>Kiểm tra bản chụp nguồn, xuất xứ, phạm vi, người và sự sẵn sàng, quyền thực hiện; ghi chứng cứ hoặc đầu mối xác nhận. Thiếu hoặc chưa xác nhận mục nào thì giữ <strong>HOLD</strong>, ghi lý do và việc cần bổ sung.</li><li>Chỉ khi đủ điều kiện trên phiếu, trạng thái có thể là <strong>READY FOR REVIEW</strong>. Đây là trạng thái sẵn sàng để người có thẩm quyền xem xét hồ sơ; <strong>chưa phải cho phép bắt đầu</strong>.</li></ol><p>Trình hỗ trợ trạng thái chỉ kiểm tra phần đã điền trên phiếu; không xác minh sự thật, chứng cứ hoặc thẩm quyền. Người nhận phải đọc lại. Không lưu tự động; xuất JSON trước khi đóng trang. Tệp được lưu cục bộ, không gửi đi.</p><p><a href="record-template.csv" download>Tải mẫu CSV trống</a> · <a href="FORM-GUIDE.md">Hướng dẫn điền và kiểm tra thủ công</a></p></section></main><script>
const form=document.getElementById('record');
const fields=['source_snapshot_confirmation','provenance_confirmation','scope_confirmation','assignee_readiness','permission_confirmation'];
function read(){{return Object.fromEntries(new FormData(form).entries());}}
function gate(d){{const missing=[];if(!['winequality-red.csv','winequality-white.csv'].includes(d.source_file))missing.push('tệp nguồn hợp lệ');const upper=d.source_file==='winequality-red.csv'?1599:4898;if(!/^\\d+$/.test(d.source_data_row)||Number(d.source_data_row)<1||Number(d.source_data_row)>upper)missing.push('vị trí dòng nguồn');for(const key of fields)if(d[key]!=='confirmed')missing.push(key);for(const key of ['scope','assignee','permission_reference'])if(!d[key].trim()||['unknown','not done'].includes(d[key].trim().toLowerCase()))missing.push(key);return missing;}}
function update(){{const missing=gate(read());document.getElementById('state-label').textContent=missing.length?'HOLD':'READY FOR REVIEW';document.getElementById('state-reason').textContent=missing.length?'Thiếu hoặc chưa xác nhận: '+missing.map(k=>({{'source_snapshot_confirmation':'bản chụp nguồn','provenance_confirmation':'xuất xứ','scope_confirmation':'phạm vi','assignee_readiness':'sự sẵn sàng','permission_confirmation':'quyền thực hiện','scope':'nội dung phạm vi','assignee':'người được giao','permission_reference':'bằng chứng quyền'}}[k]||k)).join(', ')+'. Chưa được bắt đầu kiểm tra.':'Đủ mục khai báo trên phiếu để chuyển xem xét. Trạng thái này chưa cấp quyền bắt đầu; người nhận phải kiểm tra chứng cứ và thẩm quyền.';document.getElementById('state').classList.toggle('success',!missing.length);}}
form.addEventListener('input',update);form.addEventListener('change',update);form.addEventListener('reset',()=>setTimeout(()=>{{update();document.getElementById('download-status').textContent='Đã mở phiếu trống mới; chưa lưu.';}},0));
document.getElementById('download').addEventListener('click',()=>{{const raw=read(),missing=gate(raw),payload={{schema:'wine-record-note.v1',raw_values:raw,status:missing.length?'HOLD':'READY FOR REVIEW',missing_conditions:missing,execution_authorized_by_this_form:false}};const url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{{type:'application/json;charset=utf-8'}}));const a=document.createElement('a');a.href=url;a.download='wine-record-note.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);document.getElementById('download-status').textContent='Đã tạo tệp JSON để lưu cục bộ. Kiểm tra tệp tải xuống trước khi đóng trang.';}});update();
</script></body></html>'''
(ROOT/'record-form.html').write_text(FORM,encoding='utf-8')

# An editable vector companion: HTML remains the primary responsive reading surface.
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="900" height="670" viewBox="0 0 900 670" role="img" aria-labelledby="title desc"><title id="title">Phân bố điểm Wine Quality theo tệp gốc</title><desc id="desc">Hai cột thanh dùng chung thang 0 đến 50 phần trăm; số liệu nằm trong facts.csv.</desc><rect width="900" height="670" fill="white"/><g font-family="Segoe UI,Arial,sans-serif" font-size="18" fill="#222538"><text x="30" y="35" font-size="25">Phân bố điểm trong từng tệp gốc</text><text x="30" y="70">Điểm</text><text x="125" y="70" fill="#74395f">Rượu đỏ · n = 1.599</text><text x="515" y="70" fill="#956000">Rượu trắng · n = 4.898</text>']
for q in range(11):
    y=100+q*45
    svg.append(f'<text x="45" y="{y+17}">{q}</text>')
    for key,x,col in [('red',125,'#74395f'),('white',515,'#956000')]:
        pct=stats[key]['counts'][q]/stats[key]['n']*100
        svg.append(f'<rect x="{x}" y="{y}" width="270" height="20" fill="#eeeef5"/><rect x="{x}" y="{y}" width="{pct/50*270:.6f}" height="20" fill="{col}"/><text x="{x+285}" y="{y+17}">{fmt(pct)}%</text>')
svg.append('<text x="30" y="640" font-size="16">Thang thanh 0–50%. Ngưỡng ≤5 là quy tắc bài tập; giữ nguyên dòng trùng.</text></g></svg>')
(ROOT/'distribution.svg').write_text(''.join(svg),encoding='utf-8')

guide='''# Phiếu một hồ sơ: hướng dẫn ngắn

Mở record-form.html bằng trình duyệt ngoại tuyến; không cần máy chủ. Hoặc dùng record-template.csv và ghi trạng thái thủ công. Phiếu cho đúng một bản ghi, đúng một người được giao. Không điền nhân sự hay phê duyệt khi chưa có thật.

1. Ghi `source_file` đúng tên tệp và `source_data_row` là vị trí dữ liệu từ 1 sau tiêu đề. Đối chiếu với file nguyên gốc. Đây là định vị dòng, không phải mã chai hay người.
2. Chép giá trị gốc nguyên văn; để trống nếu nguồn trống. Không thay rỗng/unknown/not done bằng confirmed. Xuất JSON giữ chuỗi nhập gốc, không cắt khoảng trắng hay đổi kiểu. Mẫu CSV cũng giữ ô trống; review_execution bắt đầu là not done.
3. Ghi nguồn/bản chụp, xuất xứ, nội dung và xác nhận phạm vi, một người được giao, sự sẵn sàng, quyền và bằng chứng/đầu mối quyền. Mỗi mục chưa có xác nhận phải để trống hoặc ghi unknown/not done/chưa xác nhận phù hợp. Ghi lý do và hành động tiếp theo.
4. Thiếu hoặc chưa xác nhận bất kỳ điều kiện nào: HOLD. Đủ điều kiện trên hồ sơ: chỉ READY FOR REVIEW, chưa phải cho phép bắt đầu. Người nhận tự kiểm tra tính thật của bằng chứng và thẩm quyền; bộ hỗ trợ không làm được điều đó.
5. Bấm Xuất phiếu JSON để lưu cục bộ. Không lưu tự động; đóng trang có thể mất dữ liệu chưa xuất. Không có gửi mạng. Có thể in phiếu. Nếu JavaScript tắt, dùng mẫu CSV hoặc giấy và tự áp dụng quy tắc trạng thái.

Danh sách 40 dòng: 20 dòng đầu mỗi tệp, giữ toàn bộ cột và định vị nguồn. Assignee để trống, các xác nhận unknown, trạng thái HOLD. Đây là danh sách thuận tiện, không ngẫu nhiên, không đại diện. Hai người ×20 hồ sơ ×3 phút/hồ sơ =120 phút công; khoảng60 phút chỉ khi hai người thật sự sẵn sàng song song. Tất cả là đề xuất/giả định, không có phê duyệt hay công việc đã thực hiện.
'''
(ROOT/'FORM-GUIDE.md').write_text(guide,encoding='utf-8')
readme='''# Wine Quality — gói báo cáo ngoại tuyến

Mở `report.html` bằng trình duyệt. Nội dung, biểu đồ, bảng, nguồn và biểu mẫu không cần mạng. Liên kết DOI/UCI/CC chỉ là dẫn nguồn tùy chọn. Ngôn ngữ: tiếng Việt. Chữ dùng font hệ thống, không gọi font/CDN ngoài.

## Dựng lại từ đầu vào đã giữ

Yêu cầu: Python 3.12 trở lên, chỉ thư viện chuẩn; không cần cài gói hoặc tải mạng. Từ chính thư mục `practical`, chạy nguyên công thức:

```text
python -B build.py
```

`python` là lệnh trỏ tới Python có sẵn của người nhận. Trong môi trường bài thử Windows, cùng mã và đối số `-B build.py` được thực thi bằng launcher Python UTF-8 đã được cấp trong RUNTIME.md; launcher không là phụ thuộc của gói. Chạy từ bất kỳ vị trí nào cũng được vì mã lấy thư mục theo vị trí build.py; công thức ở trên được thiết kế cho thư mục gói. Không dùng đường dẫn cá nhân trong mã dựng, không có cài đặt hoặc mạng. Build sẽ dừng nếu thiếu tệp nguồn hoặc SHA-256 khác bản chụp được giao.

Đầu ra dựng lại: report.html, facts.csv, source-manifest.json, review-worklist-40.csv, record-template.csv, record-form.html, distribution.svg, FORM-GUIDE.md và README.md. Nguồn trong source/ và SOURCE.md được giữ nguyên, không sửa bởi build. `distribution.svg` là hình vector có chữ chỉnh sửa được; report.html dùng bố cục thanh HTML đáp ứng để chữ không co nhỏ trên điện thoại.

## Tệp và cách đọc

- facts.csv: mỗi dòng một chỉ tiêu/tệp; value giữ giá trị chưa làm tròn, denominator là số dòng gốc khi có ý nghĩa. quality_score_0…10 có số dòng và tỷ lệ cho đủ thang, kể cả điểm không xuất hiện. Tỷ lệ tính theo %; chênh lệch tính theo điểm phần trăm. Các dòng hypothetical_plan được ghi là giả định.
- source/: hai CSV gốc, từ điển, archive gốc và giấy phép nguyên byte. SOURCE.md ghi nguồn/DOI/giấy phép; source-manifest.json có byte và SHA-256. Tên tệp xác định loại rượu; tệp không có cột wine type.
- review-worklist-40.csv: 20 dòng đầu mỗi tệp, nhận dạng source_file + source_data_row, mọi giá trị nguồn giữ nguyên; chưa có phân công và phê duyệt. Không phải mẫu đại diện.
- record-form.html + record-template.csv + FORM-GUIDE.md: phiếu mới cho một hồ sơ/một người, giữ giá trị trống/unknown/not done; xuất JSON cục bộ. Không có lưu tự động hoặc gửi mạng.

## Quy tắc ảnh hưởng kết quả

Đọc UTF-8, CSV chấm phẩy; một record do trình đọc CSV trả về là một dòng dữ liệu, tiêu đề không tính. Kiểm tra đúng 12 cột. Giữ thứ tự và mọi dòng trùng. quality hợp lệ là số nguyên hữu hạn 0–10; rỗng là thiếu, khác quy tắc là không hợp lệ. Mẫu số luôn là tất cả bản ghi trong tệp, không loại thiếu/không hợp lệ. Bản chụp này có 0 thiếu/0 không hợp lệ ở từng tệp. Tử số chỉ gồm điểm hợp lệ ≤5. Dòng trùng so sánh toàn bộ 12 giá trị đã đọc theo dạng chuỗi; không chuyển số rồi hợp nhất. Kiểm tra tổng phân bố và missing/invalid bằng mẫu số; unique+duplicate_excess bằng số dòng gốc. Không khử trùng, không gán mã chai, không suy ra nhân quả.

Hai tỷ lệ mô tả trọn bản chụp nguồn, không là ước lượng có thiết kế lấy mẫu cho quần thể. Không giả định độc lập của dòng hay dùng khoảng tin cậy để ngụ ý đại diện. quality là thứ bậc; không dùng trung bình như thước đo khoảng cách chất lượng. Ngưỡng ≤5 là giả định bài tập, không là giới hạn lỗi hay tiêu chuẩn thương mại. Không có cơ sở từ tệp để suy ra thời gian, nhà sản xuất/lô, giá, chi phí hoặc tư vấn mua/bán.

## Ghi công

Cortez, P., Cerdeira, A., Almeida, F., Matos, T., Reis, J. (2009). Wine Quality [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C56S3T . CC BY 4.0 theo hồ sơ nguồn, giấy phép lưu cục bộ. Bài báo: Modeling wine preferences by data mining from physicochemical properties, Decision Support Systems 47(4), 547–553, https://doi.org/10.1016/j.dss.2009.05.016 . CSV nguyên trạng; HTML, facts, worklist và SVG là sản phẩm dẫn xuất, không được tác giả nguồn chứng thực.
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')
print(json.dumps({'status':'built','red':{'n':r['n'],'low':r['low'],'rate':r['rate']},'white':{'n':w['n'],'low':w['low'],'rate':w['rate']},'gap_percentage_points':gap,'worklist_records':len(worklist),'source_hashes_verified':len(manifest),'facts_records':len(facts)},ensure_ascii=False))

