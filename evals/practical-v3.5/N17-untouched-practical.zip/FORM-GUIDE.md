# Phiếu một hồ sơ: hướng dẫn ngắn

Mở record-form.html bằng trình duyệt ngoại tuyến; không cần máy chủ. Hoặc dùng record-template.csv và ghi trạng thái thủ công. Phiếu cho đúng một bản ghi, đúng một người được giao. Không điền nhân sự hay phê duyệt khi chưa có thật.

1. Ghi `source_file` đúng tên tệp và `source_data_row` là vị trí dữ liệu từ 1 sau tiêu đề. Đối chiếu với file nguyên gốc. Đây là định vị dòng, không phải mã chai hay người.
2. Chép giá trị gốc nguyên văn; để trống nếu nguồn trống. Không thay rỗng/unknown/not done bằng confirmed. Xuất JSON giữ chuỗi nhập gốc, không cắt khoảng trắng hay đổi kiểu. Mẫu CSV cũng giữ ô trống; review_execution bắt đầu là not done.
3. Ghi nguồn/bản chụp, xuất xứ, nội dung và xác nhận phạm vi, một người được giao, sự sẵn sàng, quyền và bằng chứng/đầu mối quyền. Mỗi mục chưa có xác nhận phải để trống hoặc ghi unknown/not done/chưa xác nhận phù hợp. Ghi lý do và hành động tiếp theo.
4. Thiếu hoặc chưa xác nhận bất kỳ điều kiện nào: HOLD. Đủ điều kiện trên hồ sơ: chỉ READY FOR REVIEW, chưa phải cho phép bắt đầu. Người nhận tự kiểm tra tính thật của bằng chứng và thẩm quyền; bộ hỗ trợ không làm được điều đó.
5. Bấm Xuất phiếu JSON để lưu cục bộ. Không lưu tự động; đóng trang có thể mất dữ liệu chưa xuất. Không có gửi mạng. Có thể in phiếu. Nếu JavaScript tắt, dùng mẫu CSV hoặc giấy và tự áp dụng quy tắc trạng thái.

Danh sách 40 dòng: 20 dòng đầu mỗi tệp, giữ toàn bộ cột và định vị nguồn. Assignee để trống, các xác nhận unknown, trạng thái HOLD. Đây là danh sách thuận tiện, không ngẫu nhiên, không đại diện. Hai người ×20 hồ sơ ×3 phút/hồ sơ =120 phút công; khoảng60 phút chỉ khi hai người thật sự sẵn sàng song song. Tất cả là đề xuất/giả định, không có phê duyệt hay công việc đã thực hiện.
