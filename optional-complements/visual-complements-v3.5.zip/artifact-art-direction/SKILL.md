---
name: artifact-art-direction
description: "Art-direct and build professional documents, proposals, slide decks, workbooks and PDFs for a specific audience and use. Choose content hierarchy, visual system and native format, then inspect the rendered artifact and revise it; use for substantial creation or quality improvement beyond copy editing."
metadata:
  version: "1.0.0"
---

# Artifact art direction

Make the result worth reading and using in its real setting: a buyer compares a proposal, a manager scans a brief, a presenter tells a story, or an operator changes workbook inputs. Use the format's native authoring skill for mechanics. Frontend/UI taste methods can contribute ideas; they do not establish Word pagination, slide composition, spreadsheet behavior or PDF output quality.

## Start from the actual reading and doing task

Inspect the brief, source facts, existing file and supplied design references. Identify the intended reader, relationship, decision/task, viewing setting and editing/handoff needs. Read the existing artifact or rendered pages before critiquing it. Preserve a requested template, brand and document purpose; do not replace a narrow refinement with a redesign.

Choose the appropriate form from that use:
- Editable prose and a document that will change: Word/Docs.
- A spoken argument or sequence shown to a room: slides.
- A recurring calculation, comparison or operational input task: workbook.
- Stable distribution, print or a specific form: PDF, usually exported from an editable source.
- A concise forwardable observation: an email or one-page note may serve better than an elaborate deck.

Where the user asks for a new direction, choose a coherent one and implement it. Compare alternatives only when their tradeoff changes the result. Record the selected direction in working notes: content order, type hierarchy, grid/spacing, color roles, imagery and the most important example/data display. Match the reference's useful properties rather than copying its decoration.

## Make expertise visible in the content

Put the result, decision or useful action where the reader naturally begins. Organize supporting reasons in the order that makes it assessable. Use sources, actual calculations, diagrams, examples and domain language to explain the work. A generic title, attractive cover and checklist cannot substitute for substance.

For a proposal, compose the installed offers, customer-research or sales-enablement methods when buyer evidence and scope matter. Keep the specific problem, recommended work, visible deliverable, acceptance, economics and next action connected. Use the actual authorized terms; examples are not the user's record.

Choose what the artifact should emphasize and what belongs in notes or an appendix. Preserve material exceptions and uncertainty near the claim they qualify. Keep the working file paths, implementation narration and self-assigned quality badges out of recipient-facing content.

## Author in the target format

Load the available native skill for the requested format and its required authoring references. Use connected Google tools only for a connected-file task; use local authoring for a local file. Discover actual dependencies with the workspace loader; on this Windows host, local-artifact-tools and the recorded workbench can supply tested rendering paths when needed. Follow current host instructions and the authoring tool's actual prerequisites; do not invent a renderer or assume a listed integration is connected.

Read only the relevant format reference:
- [Documents and proposals](references/documents.md): long-form logic, styles, tables and page flow.
- [Presentations](references/presentations.md): narrative sequence, slide composition and presenter/reader differences.
- [Workbooks](references/workbooks.md): task layout, inputs, formulas, charts and printable summaries.
- [PDF handoff](references/pdf.md): rendering, fixed-page legibility, forms and distribution.

Produce the editable/native artifact, not just an outline, critique or screenshot. When imagery materially improves the message, use the available image/design tools or appropriate supplied assets; choose a relevant subject and crop, inspect the image in place, and follow applicable asset rights. Generated imagery is illustration, not evidence of a real person, customer, facility or product.

## Review the actual result and revise

Inspect the rendered output at its intended reading scale. Read the first screen/page as the recipient, then follow the actual task: find the recommendation, compare the alternatives, change the workbook input, read the cited figure, or locate the next action. Check the whole output for layout defects; focus deeper attention on dense pages, tables/charts, important claims and changed regions.

Make specific revisions when the hierarchy, spacing, crop, structure, content or format gets in the way. Inspect the revised output after a material change. Keep editorial/visual review distinct from calculation and factual checks; use reliable-delivery for material numbers or multi-part handoffs.

Enough source material supports a concrete draft or artifact even if commercial acceptance remains unknown. Choose an appropriate bounded result and produce it. If a missing source prevents a specific final claim, revise that claim or mark the unresolved part without abandoning independent work.

## Handoff

Deliver the requested native artifact and a distribution copy when useful. State the concrete change, actual checks and any limitation that affects use. Do not call it professional merely because it rendered, spellcheck passed, hashes matched or a reviewer assigned a score. Explain quality through the work itself: clear supported argument, intentional composition, legible output and a successful relevant usage task.

