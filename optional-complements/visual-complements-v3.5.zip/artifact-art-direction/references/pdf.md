# PDF handoff

Use the native PDF skill for reading, authoring, filling and render. When PDF is an export of Word/slides/workbook, keep the editable source unless the request calls for PDF alone.

Choose page size/orientation from actual reading or print use. Make text selectable/searchable when the workflow permits. Preserve font support for Vietnamese and other required scripts. Include bookmarks/links for a long navigable document when supported and useful; do not invent accessibility compliance from a successful export.

Render all pages and inspect normal reading size. Check margins, text clipping, missing glyphs, broken table flow, image resolution/crops, contrast and numbering. Verify important links and source notes. Page text extraction is a content aid; it does not establish visual quality.

For an interactive form, inspect the actual field names/values and widget behavior in addition to the page appearance. Preserve signatures and existing form structure; do not flatten an interactive deliverable unless the user requests it or the selected workflow requires a static copy.

Use the recipient's likely reading environment. A forwardable short note can be better as plain email plus a PDF than as downloaded executable HTML. Keep any interactive artifact separate and explain the actual opening path without claiming universal client compatibility.

For a print-ready job, check the actual printer/publisher specifications: trim, bleed, color profile, image resolution, font embedding and export standard. Generic PDF rendering does not establish print preflight or PDF/X conformance. Deliver the supported result and identify a specific unmet specification only when relevant.

