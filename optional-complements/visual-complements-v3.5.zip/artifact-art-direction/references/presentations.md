# Presentations

Use the native presentations skill for creation/editing, templates and renders.

## Choose the narrative before the layout

Identify whether the deck supports live speech, asynchronous reading, a buyer decision or a working session. A live deck can let the speaker carry detail; a reading deck needs enough explanation in the slide body. Do not force both into identical density.

Write the sequence of claims or decisions before building slides. Let each slide carry a coherent unit of meaning, with a title that explains its point. Choose an opening that establishes the subject and stakes with actual context. End with the decision, useful action or recap the audience needs.

Choose the layout by the content: one central claim, a real comparison, a process, a timeline, an annotated specimen or evidence chart. Avoid filling every slide with the same card grid. Use visual grouping, alignment and whitespace to connect related elements. Keep a stable type/color/layout system while allowing the sequence enough variation to feel intentional.

## Evidence and imagery

Use charts for the actual comparison, with readable units, scales, periods and source notes. Preserve uncertainty and sample boundaries. Label diagrams as conceptual when they are. Include enough of the underlying artifact that the audience can inspect the claimed change.

Choose an image because it supports the subject, not as generic decoration. Art-direct its crop and placement. A generated customer/facility image cannot document actual experience. Use editable text and shapes for material claims and data where practical.

## Rendered review

Render every slide, inspect the overview for rhythm and the individual slides at normal presentation/readback size. Check text overflow, tiny labels, accidental overlaps, distorted images, crowded charts and weak contrast. Read the narrative aloud or follow the deck silently for the intended use.

Revise slides that take too much effort to understand or fail to support their title. Re-render the changed slides and inspect the resulting deck. A contact sheet helps find patterns but does not replace full-size inspection. Speaker notes can hold useful context; they must not be the only location of an essential asynchronous claim.

