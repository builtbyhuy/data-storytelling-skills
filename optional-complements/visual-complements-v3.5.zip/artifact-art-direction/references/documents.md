# Documents and proposals

Use with the native documents skill. For a supplied document, render/read first and preserve approved styles unless redesign is requested.

## Shape the reading path

The opening should establish the subject and the result or decision. Make headings an informative outline: a reader scanning them should understand the argument or work sequence. Put needed definitions beside their first use. Move supporting detail to an appendix only when the main reading path stays assessable.

Use actual Word/Docs paragraph styles for title, headings, body, captions and lists. Set a deliberate page size, margins, body measure and consistent spacing. Use page/section breaks for meaning rather than to compensate for awkward text. Keep headings with following content, avoid stranded lines, and repeat table headers across pages.

Tables are for comparisons, terms, findings or structured data. Give columns enough width for the longest necessary content; right-align comparable numeric values, identify units/currency/time periods, and avoid shrinking everything to fit. Split a wide table or use landscape where the task requires it. Do not paste a screenshot of prose or numbers that should be selectable/editable.

## Proposals

Establish the buyer's actual priority, the selected approach, what they receive, scope and acceptance, required inputs, authorized timing/price and next action. Integrate a relevant specimen or annotated before/after when it helps evaluation. Put credentials, evidence and limitations beside what they substantiate; do not turn synthetic work into client history.

Content depth follows the engagement. A short scoped service proposal can fit one or two pages; complex requirements need fuller treatment. Avoid a ceremonial cover and repetitive summary pages when they delay the useful material.

## Inspect and revise

Render the whole file and inspect each page. Check:
- The first page conveys the main point; no blank/orphan pages, clipping or unintended page breaks.
- Headings, captions, tables and figures stay with the text that explains them.
- Typography and spacing form a consistent hierarchy; quotations, footnotes and citations remain legible.
- Links and editable content work; source references and material terms remain intact.
- PDF export, if supplied, matches the document's intended reading path.

Fix the actual layout/content fault and render the changed result again. Text extraction cannot prove page composition.

