# Workbooks

Use the native spreadsheets skill for formulas, authoring, recalculation and render. Compose domain analysis and reliable-delivery for material business numbers.

## Design around a recurring task

Determine what the user enters, what the workbook derives, which comparison/decision it supports and what they hand to someone else. Make the main task easy to find. Separate source records, assumptions and calculated output where that improves clarity; do not create extra sheets merely to follow a template.

Use actual dates, units and currency labels. Make editable cells recognizable and formula/output cells distinct, using the existing workbook convention where supplied. Put input instructions beside the fields they affect. Preserve identifiers and leading zeros as text when appropriate.

Use tables/ranges that accommodate the intended data growth and support sorting/filtering. Avoid merged cells inside operational tables and structures that break copy/paste. Freeze headers where useful. Protect formulas only if authorized and useful; do not make ordinary user edits unexpectedly impossible.

## Calculation and presentation

Keep materially adjustable assumptions in labeled inputs. Use formulas for calculated values; preserve the required domain relationships and reconcile totals independently. Treat blanks, zero, unavailable values and error states according to the actual domain rather than making them look equally neat.

Show the decision-relevant outputs first with a usable detail path. Choose charts from the comparison the reader needs, with meaningful scales and visible units. Colors encode a consistent role or distinction; they should not replace explicit labels. Do not hide exceptions behind decorative status badges.

For RFQ or quote workflows, prefer the recipient's real spreadsheet/CSV format over making the operator retype data into an unrelated interface. If a new format is chosen, demonstrate the concrete work it removes or clarifies.

## Usage and rendered review

Open/render the result with the supported tool. Test a representative real or clearly synthetic input change and confirm dependent output changes appropriately. Check a material boundary/missing-input case, formula errors and independent reconciliation.

Inspect readable column widths, wrapping, number formats, chart labels and meaningful conditional formatting. Set useful print areas, repeat headers and fit-to-page only when a print/PDF copy is part of the task. Inspect that export as pages, not just the worksheet grid.

Deliver an editable workbook. A screenshot or PDF summary cannot replace it when the user needs recurring calculation.

