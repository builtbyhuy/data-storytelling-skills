# Local browser checks

- Identify the user's main action and a plausible error state before changing the UI.
- Run the actual app on loopback when authorized. Use project Playwright or the existing browser tools; do not bypass a tool restriction.
- Assert visible outcomes and retained or changed data, inspect desktop/mobile screenshots, and test keyboard focus through the flow.
- Run axe against the important rendered states when available. Inspect incomplete results and report manual screen-reader coverage separately.
- Prefer existing runtime and browsers. Do not change global settings or download duplicate runtimes.
- Stop temporary processes created for verification. Preserve source, screenshots and a rerunnable test command.

Known local kit: `C:/Users/user/Documents/Codex/2026-10-01/go/stack/coding/run.ps1 -Task test` (tests) or `-Task preview` (loopback preview until Ctrl+C). The kit reuses the bundled Node/Playwright and installed Microsoft Edge, with a project-local axe-core package.
